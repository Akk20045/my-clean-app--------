# Firestore Security Specification

## 1. Data Invariants

1. **Identity & Ownership Integrity**:
   - Every `building`, `tenant`, and `payment` document must have an immutable `ownerId` matching the creator's `request.auth.uid`.
   - Modifying `ownerId` or `id` post-creation is strictly forbidden.
   - Only the workspace owner or authorized users whose verified email is listed in `sharedEmails` may read or modify the records.

2. **Temporal Integrity**:
   - `createdAt` and `updatedAt` timestamps must match `request.time`.

3. **Multi-Account Collaboration Invariant**:
   - `sharedEmails` is an array bounded by `.size() <= 20` to prevent Denial of Wallet.
   - Any member attempting to write must have `request.auth.token.email_verified == true`.
   - A tenant cannot exist without a valid `buildingId` referencing a building owned/shared by the same workspace.
   - A payment cannot exist without a valid `tenantId`.

4. **Input Boundary Limits**:
   - All string lengths are strictly constrained (names <= 150 chars, notes <= 500 chars, IDs <= 128 chars).
   - Numerical amounts (e.g. `monthlyRent`, `amount`) must be non-negative numbers.

---

## 2. The "Dirty Dozen" Malicious Payloads

1. **Ghost Field Spoofing (Shadow Update)**:
   - Trying to inject `isAdmin: true` into building or tenant.
2. **Identity Hijack**:
   - Attempting to set `ownerId: "someone-else-uid"` on creation.
3. **Owner Field Mutation**:
   - Updating existing document to change `ownerId`.
4. **Unbounded Shared Emails (Denial of Wallet)**:
   - Setting `sharedEmails` with an array of 5,000 strings.
5. **Negative Rent / Payment Value Poisoning**:
   - Writing `monthlyRent: -5000` or `amount: -200`.
6. **String Overfill Overflow**:
   - Writing `name` with a 2MB string.
7. **Unverified Email Collaboration Bypass**:
   - User with unverified email attempting write access.
8. **Unauthorized Third-Party Access**:
   - Authenticated user whose email is NOT in `sharedEmails` and who is NOT the `ownerId` attempting to read or list.
9. **Blanket Query Scraping**:
   - Attempting to query `collection("buildings")` without filtering by owner/shared user.
10. **ID Path Variable Injection Attack**:
    - Querying with illegal characters in ID path (e.g. `../` or junk 10KB string).
11. **Direct Profile Privilege Escalation**:
    - Writing to other users' `/users/{userId}` documents.
12. **Tampering with Workspace Owner Email**:
    - A collaborator attempting to change the `ownerEmail` or `ownerId` of the workspace.
