import { TenantFinancialSnapshot } from '../types';
import {
  formatCurrency,
  formatMonthName,
  getPaymentMethodNameAr,
  getUnitTypeLabel,
  getUnitDisplayTag,
} from './formatters';

/**
 * Export to Excel (.xls HTML table format)
 * Using explicit UTF-8 and RTL HTML so MS Excel renders Arabic perfectly without scrambled characters.
 */
export function exportToExcel(
  snapshots: TenantFinancialSnapshot[],
  monthKey: string,
  currency: string,
  buildingFilterName?: string
): void {
  const monthName = formatMonthName(monthKey);
  const title = `سجل إيجارات العقارات — ${monthName}${buildingFilterName ? ` (${buildingFilterName})` : ''}`;

  const totalRent = snapshots.reduce((acc, s) => acc + s.monthlyRent, 0);
  const totalPaid = snapshots.reduce((acc, s) => acc + s.totalPaid, 0);
  const totalRemaining = snapshots.reduce((acc, s) => acc + s.balanceRemaining, 0);
  const totalDeposits = snapshots.reduce((acc, s) => acc + (s.tenant.securityDeposit || 0), 0);
  const rate = totalRent > 0 ? Math.round((totalPaid / totalRent) * 100) : 0;

  const htmlContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <!--[if gte mso 9]>
  <xml>
    <x:ExcelWorkbook>
      <x:ExcelWorksheets>
        <x:ExcelWorksheet>
          <x:Name>سجل الإيجارات</x:Name>
          <x:WorksheetOptions>
            <x:DisplayRightToLeft/>
          </x:WorksheetOptions>
        </x:ExcelWorksheet>
      </x:ExcelWorksheets>
    </x:ExcelWorkbook>
  </xml>
  <![endif]-->
  <style>
    body { font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; direction: rtl; }
    table { border-collapse: collapse; width: 100%; font-size: 13px; text-align: right; }
    th { background-color: #1E293B; color: #FFFFFF; font-weight: bold; padding: 10px; border: 1px solid #CBD5E1; }
    td { padding: 8px 10px; border: 1px solid #E2E8F0; }
    .header-title { font-size: 18px; font-weight: bold; text-align: center; background-color: #0F172A; color: #F59E0B; padding: 14px; }
    .kpi-row td { background-color: #F8FAFC; font-weight: bold; }
    .total-row td { background-color: #FEF3C7; font-weight: bold; color: #92400E; font-size: 14px; }
    .paid { color: #059669; font-weight: bold; }
    .partial { color: #D97706; font-weight: bold; }
    .unpaid { color: #DC2626; font-weight: bold; }
    .text-center { text-align: center; }
    .text-left { text-align: left; }
    .num { mso-number-format:"\\#\\,\\#\\#0\\.00"; text-align: left; }
  </style>
</head>
<body dir="rtl">
  <table>
    <tr>
      <td colspan="9" class="header-title">${title}</td>
    </tr>
    <tr>
      <td colspan="9" style="text-align: center; color: #64748B; padding: 6px;">تاريخ استخراج التقرير: ${new Date().toLocaleDateString('ar-JO')} | منصة تحصيل لإدارة العقارات</td>
    </tr>
    <tr class="kpi-row">
      <td colspan="2">إجمالي المتوقع: <strong>${formatCurrency(totalRent, currency)}</strong></td>
      <td colspan="2">المحصل: <strong style="color: #059669;">${formatCurrency(totalPaid, currency)} (${rate}%)</strong></td>
      <td colspan="2">المتبقي: <strong style="color: #DC2626;">${formatCurrency(totalRemaining, currency)}</strong></td>
      <td colspan="3">إجمالي الضمانات التجارية المحتجزة: <strong style="color: #0284C7;">${formatCurrency(totalDeposits, currency)}</strong></td>
    </tr>
    <tr><td colspan="9" style="height: 10px; background-color: #FFFFFF; border: none;"></td></tr>
    <thead>
      <tr>
        <th>العمارة / المجمع</th>
        <th>رقم الوحدة</th>
        <th>نوع العقار</th>
        <th>اسم المستأجر</th>
        <th>رقم الهاتف</th>
        <th style="text-align: left;">الإيجار الكامل (${currency})</th>
        <th style="text-align: left;">المدفوع (${currency})</th>
        <th style="text-align: left;">المتبقي (${currency})</th>
        <th>حالة السداد</th>
      </tr>
    </thead>
    <tbody>
      ${snapshots
        .map((s, idx) => {
          const typeLabel = getUnitTypeLabel(s.tenant.unitType, s.tenant.customUnitType);
          const unitTag = getUnitDisplayTag(s.tenant.unitNumber, s.tenant.unitType, s.tenant.customUnitType);

          const statusClass = s.status === 'paid' ? 'paid' : s.status === 'partial' ? 'partial' : 'unpaid';
          const statusLabel =
            s.status === 'paid'
              ? 'مسدد بالكامل'
              : s.status === 'partial'
              ? `جزئي (متبقي ${s.balanceRemaining})`
              : 'غير مسدد';

          const rowBg = idx % 2 === 0 ? '#FFFFFF' : '#F8FAFC';

          return `
      <tr style="background-color: ${rowBg};">
        <td>${s.buildingName}</td>
        <td><strong>${unitTag}</strong></td>
        <td>${typeLabel}</td>
        <td><strong>${s.tenant.name}</strong></td>
        <td style="text-align: left; font-family: monospace;" dir="ltr">${s.tenant.phone}</td>
        <td class="num">${s.monthlyRent.toLocaleString()}</td>
        <td class="num" style="color: #059669; font-weight: bold;">${s.totalPaid.toLocaleString()}</td>
        <td class="num" style="${s.balanceRemaining > 0 ? 'color: #DC2626; font-weight: bold;' : ''}">${s.balanceRemaining.toLocaleString()}</td>
        <td class="${statusClass}">${statusLabel}</td>
      </tr>`;
        })
        .join('')}
    </tbody>
    <tfoot>
      <tr class="total-row">
        <td>الإجمالي العام</td>
        <td>${snapshots.length} وحدات</td>
        <td colspan="3">نسبة التحصيل: ${rate}%</td>
        <td class="num">${totalRent.toLocaleString()}</td>
        <td class="num" style="color: #059669;">${totalPaid.toLocaleString()}</td>
        <td class="num" style="color: #DC2626;">${totalRemaining.toLocaleString()}</td>
        <td>${totalRemaining === 0 ? 'مكتمل التحصيل' : 'مطلوب متابعة'}</td>
      </tr>
    </tfoot>
  </table>
</body>
</html>`;

  const blob = new Blob(['\uFEFF' + htmlContent], { type: 'application/vnd.ms-excel;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `سجل_إيجارات_${monthName.replace(/\s+/g, '_')}.xls`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Export to Word (.doc format with RTL Arabic formatting)
 */
export function exportToWord(
  snapshots: TenantFinancialSnapshot[],
  monthKey: string,
  currency: string,
  buildingFilterName?: string
): void {
  const monthName = formatMonthName(monthKey);
  const title = `كشف حساب إيجارات العقارات — ${monthName}`;
  const totalRent = snapshots.reduce((acc, s) => acc + s.monthlyRent, 0);
  const totalPaid = snapshots.reduce((acc, s) => acc + s.totalPaid, 0);
  const totalRemaining = snapshots.reduce((acc, s) => acc + s.balanceRemaining, 0);
  const totalDeposits = snapshots.reduce((acc, s) => acc + (s.tenant.securityDeposit || 0), 0);
  const rate = totalRent > 0 ? Math.round((totalPaid / totalRent) * 100) : 0;

  const wordHtml = `
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
  <meta charset='utf-8'>
  <title>${title}</title>
  <style>
    body {
      font-family: 'Cairo', 'Arial', sans-serif;
      direction: rtl;
      text-align: right;
      color: #1E293B;
      padding: 20px;
    }
    h1 {
      color: #0F172A;
      font-size: 22px;
      text-align: center;
      border-bottom: 2px solid #D97706;
      padding-bottom: 8px;
      margin-bottom: 4px;
    }
    .subtitle {
      text-align: center;
      color: #64748B;
      font-size: 13px;
      margin-bottom: 20px;
    }
    .kpi-box {
      border: 1px solid #CBD5E1;
      background-color: #F8FAFC;
      padding: 12px;
      margin-bottom: 20px;
      border-radius: 6px;
    }
    .kpi-table {
      width: 100%;
      border-collapse: collapse;
      text-align: center;
    }
    .kpi-table td {
      padding: 8px;
      border: 1px solid #E2E8F0;
    }
    table.data-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
      margin-top: 15px;
    }
    table.data-table th {
      background-color: #1E293B;
      color: #FFFFFF;
      padding: 8px;
      border: 1px solid #475569;
      font-weight: bold;
    }
    table.data-table td {
      padding: 8px;
      border: 1px solid #CBD5E1;
    }
    .footer-note {
      margin-top: 30px;
      font-size: 12px;
      color: #64748B;
      border-top: 1px dashed #CBD5E1;
      padding-top: 10px;
      display: flex;
      justify-content: space-between;
    }
    .status-paid { color: #059669; font-weight: bold; }
    .status-partial { color: #D97706; font-weight: bold; }
    .status-unpaid { color: #DC2626; font-weight: bold; }
  </style>
</head>
<body dir="rtl">
  <h1>${title}</h1>
  <div class="subtitle">
    ${buildingFilterName ? `نطاق التقرير: ${buildingFilterName} | ` : ''}تاريخ الإصدار: ${new Date().toLocaleDateString('ar-JO')} | المنظومة: منصة تحصيل
  </div>

  <div class="kpi-box">
    <table class="kpi-table">
      <tr>
        <td>إجمالي الإيجار المستحق: <br/><strong>${formatCurrency(totalRent, currency)}</strong></td>
        <td style="color: #059669;">إجمالي المحصل: <br/><strong>${formatCurrency(totalPaid, currency)} (${rate}%)</strong></td>
        <td style="color: #DC2626;">المتبقي غير المحصل: <br/><strong>${formatCurrency(totalRemaining, currency)}</strong></td>
        <td style="color: #0284C7;">مجموع الضمانات المحتجزة: <br/><strong>${formatCurrency(totalDeposits, currency)}</strong></td>
      </tr>
    </table>
  </div>

  <table class="data-table">
    <thead>
      <tr>
        <th>العمارة</th>
        <th>الوحدة</th>
        <th>المستأجر</th>
        <th>الهاتف</th>
        <th>الإيجار (${currency})</th>
        <th>المدفوع (${currency})</th>
        <th>المتبقي (${currency})</th>
        <th>الحالة</th>
      </tr>
    </thead>
    <tbody>
      ${snapshots
        .map((s, i) => `
      <tr style="background-color: ${i % 2 === 0 ? '#FFFFFF' : '#F8FAFC'};">
        <td>${s.buildingName}</td>
        <td><strong>${getUnitDisplayTag(s.tenant.unitNumber, s.tenant.unitType, s.tenant.customUnitType)}</strong></td>
        <td>${s.tenant.name}</td>
        <td dir="ltr" style="text-align: left;">${s.tenant.phone}</td>
        <td style="text-align: left;">${s.monthlyRent.toLocaleString()}</td>
        <td style="text-align: left; color: #059669; font-weight: bold;">${s.totalPaid.toLocaleString()}</td>
        <td style="text-align: left; ${s.balanceRemaining > 0 ? 'color: #DC2626; font-weight: bold;' : ''}">${s.balanceRemaining.toLocaleString()}</td>
        <td class="${s.status === 'paid' ? 'status-paid' : s.status === 'partial' ? 'status-partial' : 'status-unpaid'}">
          ${s.status === 'paid' ? 'مسدد بالكامل' : s.status === 'partial' ? `جزئي (متبقي ${s.balanceRemaining})` : 'غير مسدد'}
        </td>
      </tr>`)
        .join('')}
      <tr style="background-color: #FEF3C7; font-weight: bold;">
        <td colspan="4">المجموع الكلي (${snapshots.length} عقارات)</td>
        <td style="text-align: left;">${totalRent.toLocaleString()} ${currency}</td>
        <td style="text-align: left; color: #059669;">${totalPaid.toLocaleString()} ${currency}</td>
        <td style="text-align: left; color: #DC2626;">${totalRemaining.toLocaleString()} ${currency}</td>
        <td>تحصيل: ${rate}%</td>
      </tr>
    </tbody>
  </table>

  <div style="margin-top: 40px; display: flex; justify-content: space-between;">
    <div>
      <p><strong>توقيع المؤجر / المالك:</strong> ......................................</p>
    </div>
    <div>
      <p><strong>تاريخ الاعتماد:</strong> ..... / ..... / ${new Date().getFullYear()}</p>
    </div>
  </div>
</body>
</html>`;

  const blob = new Blob(['\uFEFF' + wordHtml], { type: 'application/msword;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `تقرير_إيجارات_${monthName.replace(/\s+/g, '_')}.doc`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
