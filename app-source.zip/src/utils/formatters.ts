import { MonthStatus, PaymentMethod, UnitType } from '../types';

export const MONTH_NAMES_AR: { [key: number]: { levantine: string; standard: string; en: string } } = {
  1: { levantine: 'كانون الثاني', standard: 'يناير', en: 'January' },
  2: { levantine: 'شباط', standard: 'فبراير', en: 'February' },
  3: { levantine: 'آذار', standard: 'مارس', en: 'March' },
  4: { levantine: 'نيسان', standard: 'أبريل', en: 'April' },
  5: { levantine: 'أيار', standard: 'مايو', en: 'May' },
  6: { levantine: 'حزيران', standard: 'يونيو', en: 'June' },
  7: { levantine: 'تموز', standard: 'يوليو', en: 'July' },
  8: { levantine: 'آب', standard: 'أغسطس', en: 'August' },
  9: { levantine: 'أيلول', standard: 'سبتمبر', en: 'September' },
  10: { levantine: 'تشرين الأول', standard: 'أكتوبر', en: 'October' },
  11: { levantine: 'تشرين الثاني', standard: 'نوفمبر', en: 'November' },
  12: { levantine: 'كانون الأول', standard: 'ديسمبر', en: 'December' },
};

/**
 * Format monthKey (e.g. "2026-09") into Arabic display string (e.g. "أيلول 2026")
 */
export function formatMonthName(monthKey: string, preferLevantine: boolean = true): string {
  const [yearStr, monthStr] = monthKey.split('-');
  const year = parseInt(yearStr, 10);
  const month = parseInt(monthStr, 10);

  const entry = MONTH_NAMES_AR[month];
  if (!entry) return monthKey;

  const monthName = preferLevantine ? entry.levantine : entry.standard;
  return `${monthName} ${year}`;
}

export function formatMonthEn(monthKey: string): string {
  const [yearStr, monthStr] = monthKey.split('-');
  const year = parseInt(yearStr, 10);
  const month = parseInt(monthStr, 10);

  const entry = MONTH_NAMES_AR[month];
  if (!entry) return monthKey;

  return `${entry.en} ${year}`;
}

/**
 * Formats a currency amount nicely
 */
export function formatCurrency(amount: number, currency: string = 'JOD'): string {
  const formatted = new Intl.NumberFormat('en-US', {
    maximumFractionDigits: 0,
    minimumFractionDigits: 0,
  }).format(amount);

  return `${formatted} ${currency}`;
}

/**
 * Shift monthKey by delta months
 */
export function shiftMonthKey(monthKey: string, delta: number): string {
  const [yearStr, monthStr] = monthKey.split('-');
  let year = parseInt(yearStr, 10);
  let month = parseInt(monthStr, 10) + delta;

  while (month < 1) {
    month += 12;
    year -= 1;
  }
  while (month > 12) {
    month -= 12;
    year += 1;
  }

  const mm = month.toString().padStart(2, '0');
  return `${year}-${mm}`;
}

/**
 * Generate surrounding months for carousel: [month - 2, month - 1, current, month + 1, month + 2]
 */
export function getSurroundingMonths(currentMonthKey: string, countEachSide: number = 2): string[] {
  const result: string[] = [];
  for (let i = -countEachSide; i <= countEachSide; i++) {
    result.push(shiftMonthKey(currentMonthKey, i));
  }
  return result;
}

/**
 * Generate clean receipt number
 */
export function generateReceiptNumber(tenantId: string, monthKey: string): string {
  const rand = Math.floor(1000 + Math.random() * 9000);
  const cleanMonth = monthKey.replace('-', '');
  return `RCP-${cleanMonth}-${rand}`;
}

/**
 * Convert Arabic/Indic digits (٠-٩) to Western (0-9)
 */
export function convertArabicToEnglishDigits(str: string): string {
  const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return str.replace(/[٠-٩]/g, (w) => arabicDigits.indexOf(w).toString());
}

/**
 * Normalize phone number for direct phone dial (tel: protocol)
 */
export function sanitizePhoneForCall(phone: string): string {
  if (!phone) return '';
  let cleaned = convertArabicToEnglishDigits(phone).trim();
  // Remove all non-digits except +
  cleaned = cleaned.replace(/[^\d+]/g, '');
  if (!cleaned.startsWith('+') && !cleaned.startsWith('00') && !cleaned.startsWith('0')) {
    // If entered as 79XXXXXXX or 96279XXXXXXX
    if (cleaned.startsWith('7') && cleaned.length === 9) {
      cleaned = '0' + cleaned;
    } else if (cleaned.startsWith('962')) {
      cleaned = '+' + cleaned;
    }
  }
  return cleaned;
}

/**
 * Clean phone number for WhatsApp wa.me link (digits only with international country code)
 */
export function sanitizePhoneForWhatsApp(phone: string): string {
  if (!phone) return '';
  let cleaned = convertArabicToEnglishDigits(phone).trim();
  
  // Remove spaces, dashes, parentheses, dots, slashes
  cleaned = cleaned.replace(/[\s\-\(\)\.\/\+]/g, '');

  // Remove leading 00 (international prefix)
  if (cleaned.startsWith('00')) {
    cleaned = cleaned.substring(2);
  }

  // If user pasted Jordan local number like 079XXXXXXX or 078XXXXXXX or 077XXXXXXX
  if (cleaned.startsWith('07') && cleaned.length === 10) {
    cleaned = '962' + cleaned.substring(1);
  } 
  // If user typed 79XXXXXXX (9 digits) without leading 0
  else if ((cleaned.startsWith('79') || cleaned.startsWith('78') || cleaned.startsWith('77')) && cleaned.length === 9) {
    cleaned = '962' + cleaned;
  }
  // If user typed 96207XXXXXXX (accidental double prefix)
  else if (cleaned.startsWith('96207') && cleaned.length === 13) {
    cleaned = '962' + cleaned.substring(4);
  }

  return cleaned;
}

/**
 * Generate WhatsApp reminder or receipt URL with safe phone validation
 */
export function generateWhatsAppLink(
  phone: string,
  tenantName: string,
  unitTag: string,
  buildingName: string,
  monthKey: string,
  status: MonthStatus,
  monthlyRent: number,
  paidSoFar: number,
  balanceRemaining: number,
  currency: string = 'JOD'
): string {
  const cleanPhone = sanitizePhoneForWhatsApp(phone);
  const monthName = formatMonthName(monthKey);

  let message = '';
  if (status === 'unpaid') {
    message = `السلام عليكم ورحمة الله وبركاته،\nالأخ الفاضل ${tenantName} المحترم،\nنود تذكيركم بلطف باستحقاق إيجار شهر (${monthName}) عن (${buildingName} — ${unitTag})، بمبلغ قدره ${formatCurrency(monthlyRent, currency)}.\nشاكرين لكم حسن تعاونكم وطيب تعاملكم.`;
  } else if (status === 'partial') {
    message = `السلام عليكم ورحمة الله وبركاته،\nالأخ الفاضل ${tenantName} المحترم،\nنشكركم على سداد الدفعة السابقة (${formatCurrency(paidSoFar, currency)}) عن إيجار شهر (${monthName}) لـ (${buildingName} — ${unitTag}). نود إعلامكم بأن الرصيد المتبقي للاستكمال هو ${formatCurrency(balanceRemaining, currency)}.\nمع خالص التقدير.`;
  } else {
    message = `السلام عليكم ورحمة الله وبركاته،\nالأخ الفاضل ${tenantName} المحترم،\nتم استلام وتسجيل كامل إيجار شهر (${monthName}) عن (${buildingName} — ${unitTag}) بمبلغ ${formatCurrency(monthlyRent, currency)} بنجاح، والحساب مسدد بالكامل.\nبارك الله لكم وشاكرين التزامكم الدائم.`;
  }

  // If no phone or invalid length, fallback to WhatsApp web share
  if (!cleanPhone || cleanPhone.length < 5) {
    return `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;
  }

  return `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(message)}`;
}

export function getPaymentMethodNameAr(method: PaymentMethod): string {
  switch (method) {
    case 'cash':
      return 'نقداً (كاش)';
    case 'cliq':
      return 'كليك (CliQ)';
    case 'bank_transfer':
      return 'تحويل بنكي';
    case 'cheque':
      return 'شيك مصرفي';
    default:
      return method;
  }
}

/**
 * Get Arabic human-friendly label for unit types (including 'other' with custom name)
 */
export function getUnitTypeLabel(type: UnitType = 'apartment', customType?: string): string {
  switch (type) {
    case 'apartment':
      return 'شقة سكنية';
    case 'commercial_shop':
      return 'محل تجاري';
    case 'office':
      return 'مكتب أعمال';
    case 'penthouse':
      return 'بنتهاوس';
    case 'villa':
      return 'فيلا مستقلة';
    case 'other':
      return customType?.trim() || 'وحدة أخرى';
    default:
      return customType?.trim() || (typeof type === 'string' && type ? type : 'وحدة عقارية');
  }
}

/**
 * Formats unit display name: if unitNumber is provided, returns it; otherwise returns unit type label
 */
export function getUnitDisplayTag(
  unitNumber?: string,
  unitType: UnitType = 'apartment',
  customType?: string
): string {
  if (unitNumber && unitNumber.trim()) {
    return unitNumber.trim();
  }
  return getUnitTypeLabel(unitType, customType);
}
