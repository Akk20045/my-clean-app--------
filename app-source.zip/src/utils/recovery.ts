export interface PotentialBackup {
  key: string;
  type: 'buildings' | 'tenants' | 'payments' | 'unknown';
  count: number;
  preview: string;
  rawJson: string;
}

export function scanLocalStorageForBackups(): PotentialBackup[] {
  const backups: PotentialBackup[] = [];
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key) continue;

      // Skip current active v2 keys if they are empty
      const value = localStorage.getItem(key);
      if (!value) continue;

      try {
        const parsed = JSON.parse(value);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Check what kind of data it contains
          let type: 'buildings' | 'tenants' | 'payments' | 'unknown' = 'unknown';
          let preview = '';

          const firstItem = parsed[0];
          if (firstItem && typeof firstItem === 'object') {
            if ('location' in firstItem || ('name' in firstItem && !('buildingId' in firstItem) && !('tenantId' in firstItem))) {
              type = 'buildings';
              preview = parsed.map((b: any) => b.name).slice(0, 3).join('، ');
            } else if ('buildingId' in firstItem && 'monthlyRent' in firstItem) {
              type = 'tenants';
              preview = parsed.map((t: any) => t.name).slice(0, 3).join('، ');
            } else if ('tenantId' in firstItem && 'monthKey' in firstItem && 'amount' in firstItem) {
              type = 'payments';
              preview = parsed.map((p: any) => `${p.amount} JOD`).slice(0, 3).join('، ');
            }
          }

          // If it matches some keyword or structure, add it as potential backup
          const isBackupKey = key.includes('building') || key.includes('tenant') || key.includes('payment') || key.includes('aura') || key.includes('rent') || key.includes('backup') || key.includes('تحصيل');
          if (isBackupKey || type !== 'unknown') {
            backups.push({
              key,
              type,
              count: parsed.length,
              preview: preview || 'بيانات غير مصنفة',
              rawJson: value,
            });
          }
        }
      } catch {
        // Not a JSON array, skip
      }
    }
  } catch (e) {
    console.error('Error scanning localStorage', e);
  }
  return backups;
}
