import { INITIAL_BUILDINGS, INITIAL_PAYMENTS, INITIAL_TENANTS } from '../data/seedData';
import { Building, FontFamily, PaymentRecord, Tenant, TenantFinancialSnapshot, ThemeMode } from '../types';
import { formatCurrency, formatMonthName, getPaymentMethodNameAr } from './formatters';

const STORAGE_KEYS = {
  BUILDINGS: 'aurarent_buildings_v2',
  TENANTS: 'aurarent_tenants_v2',
  PAYMENTS: 'aurarent_payments_v2',
  CURRENCY: 'aurarent_currency_v2',
  ACTIVE_MONTH: 'aurarent_active_month_v2',
  THEME: 'aurarent_theme_v2',
  FONT: 'aurarent_font_v2',
};

export function loadBuildings(): Building[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BUILDINGS);
    if (!raw) {
      // Start empty by default as requested: "اول اشي خلي كل اشي فاضي من اسامي عمارات ومبالغ"
      return [];
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load buildings', e);
    return [];
  }
}

export function saveBuildings(buildings: Building[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.BUILDINGS, JSON.stringify(buildings));
  } catch (e) {
    console.error('Failed to save buildings', e);
  }
}

export function loadTenants(): Tenant[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TENANTS);
    if (!raw) {
      return [];
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load tenants', e);
    return [];
  }
}

export function saveTenants(tenants: Tenant[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.TENANTS, JSON.stringify(tenants));
  } catch (e) {
    console.error('Failed to save tenants', e);
  }
}

export function loadPayments(): PaymentRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PAYMENTS);
    if (!raw) {
      return [];
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load payments', e);
    return [];
  }
}

export function savePayments(payments: PaymentRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
  } catch (e) {
    console.error('Failed to save payments', e);
  }
}

export function loadCurrency(): string {
  try {
    return localStorage.getItem(STORAGE_KEYS.CURRENCY) || 'JOD';
  } catch {
    return 'JOD';
  }
}

export function saveCurrency(currency: string): void {
  try {
    localStorage.setItem(STORAGE_KEYS.CURRENCY, currency);
  } catch (e) {
    console.error('Failed to save currency', e);
  }
}

export function loadActiveMonth(): string {
  try {
    const now = new Date();
    const currentY = now.getFullYear();
    const currentM = (now.getMonth() + 1).toString().padStart(2, '0');
    return localStorage.getItem(STORAGE_KEYS.ACTIVE_MONTH) || `${currentY}-${currentM}`;
  } catch {
    return '2026-09';
  }
}

export function saveActiveMonth(monthKey: string): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_MONTH, monthKey);
  } catch (e) {
    console.error('Failed to save active month', e);
  }
}

const VALID_THEMES: ThemeMode[] = [
  'light',
  'light-blue',
  'cream',
  'lavender',
  'mint-light',
  'rose-gold',
  'dark',
  'cool',
  'navy',
  'graphite',
  'nordic',
  'carbon',
  'amber',
  'emerald',
  'crimson',
  'amethyst',
  'bronze',
  'sapphire',
  'cyberpunk',
  'matrix',
  'solar',
  'electric-violet',
  'mocha',
  'olive',
  'ocean',
  'sunset',
];
const VALID_FONTS: FontFamily[] = ['readex', 'cairo', 'tajawal', 'jakarta', 'almarai', 'noto', 'alexandria', 'ibm', 'amiri', 'changa'];

export function loadTheme(): ThemeMode {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.THEME) as ThemeMode;
    return saved && VALID_THEMES.includes(saved) ? saved : 'dark';
  } catch {
    return 'dark';
  }
}

export function saveTheme(theme: ThemeMode): void {
  try {
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  } catch (e) {
    console.error('Failed to save theme', e);
  }
}

export function loadFont(): FontFamily {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.FONT) as FontFamily;
    return saved && VALID_FONTS.includes(saved) ? saved : 'readex';
  } catch {
    return 'readex';
  }
}

export function saveFont(font: FontFamily): void {
  try {
    localStorage.setItem(STORAGE_KEYS.FONT, font);
  } catch (e) {
    console.error('Failed to save font', e);
  }
}

export function clearAllData(): { buildings: Building[]; tenants: Tenant[]; payments: PaymentRecord[] } {
  localStorage.setItem(STORAGE_KEYS.BUILDINGS, JSON.stringify([]));
  localStorage.setItem(STORAGE_KEYS.TENANTS, JSON.stringify([]));
  localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify([]));
  return {
    buildings: [],
    tenants: [],
    payments: [],
  };
}

export function loadDemoData(): { buildings: Building[]; tenants: Tenant[]; payments: PaymentRecord[] } {
  localStorage.setItem(STORAGE_KEYS.BUILDINGS, JSON.stringify(INITIAL_BUILDINGS));
  localStorage.setItem(STORAGE_KEYS.TENANTS, JSON.stringify(INITIAL_TENANTS));
  localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(INITIAL_PAYMENTS));
  return {
    buildings: INITIAL_BUILDINGS,
    tenants: INITIAL_TENANTS,
    payments: INITIAL_PAYMENTS,
  };
}

export function getTenantSnapshot(
  tenant: Tenant,
  monthKey: string,
  payments: PaymentRecord[],
  buildings: Building[]
): TenantFinancialSnapshot {
  const building = buildings.find((b) => b.id === tenant.buildingId);
  const buildingName = building ? building.name : 'مبنى غير محدد';

  const monthPayments = payments.filter((p) => p.tenantId === tenant.id && p.monthKey === monthKey);
  const totalPaid = monthPayments.reduce((acc, curr) => acc + curr.amount, 0);
  const monthlyRent = tenant.monthlyRent;
  const balanceRemaining = Math.max(0, monthlyRent - totalPaid);
  const percentagePaid = monthlyRent > 0 ? Math.min(100, Math.round((totalPaid / monthlyRent) * 100)) : 100;

  let status: 'paid' | 'partial' | 'unpaid' = 'unpaid';
  if (totalPaid >= monthlyRent && monthlyRent > 0) {
    status = 'paid';
  } else if (totalPaid > 0) {
    status = 'partial';
  }

  return {
    tenant,
    buildingName,
    monthKey,
    monthlyRent,
    totalPaid,
    balanceRemaining,
    percentagePaid,
    status,
    payments: monthPayments,
  };
}

/**
 * Export Excel/CSV spreadsheet format with UTF-8 BOM so Excel displays Arabic properly
 */
export function exportToExcelCSV(snapshots: TenantFinancialSnapshot[], monthKey: string, currency: string): void {
  const monthName = formatMonthName(monthKey);
  const headers = [
    'العمارة / المجمع',
    'رقم الوحدة',
    'نوع العقار',
    'اسم المستأجر',
    'رقم الهاتف',
    `الإيجار الشهري (${currency})`,
    `المدفوع (${currency})`,
    `المتبقي (${currency})`,
    'نسبة السداد %',
    'حالة السداد',
    `ضمان المحل / التأمين (${currency})`,
  ];

  const rows = snapshots.map((s) => [
    `"${s.buildingName}"`,
    `"${s.tenant.unitNumber}"`,
    `"${s.tenant.unitType === 'commercial_shop' ? 'محل تجاري' : s.tenant.unitType === 'office' ? 'مكتب' : 'سكني'}"`,
    `"${s.tenant.name}"`,
    `"${s.tenant.phone}"`,
    s.monthlyRent,
    s.totalPaid,
    s.balanceRemaining,
    `${s.percentagePaid}%`,
    `"${s.status === 'paid' ? 'مسدد بالكامل' : s.status === 'partial' ? 'دفعة جزئية' : 'غير مسدد'}"`,
    s.tenant.securityDeposit || 0,
  ]);

  // Add Summary Total Row (Excel style)
  const totalRent = snapshots.reduce((acc, c) => acc + c.monthlyRent, 0);
  const totalPaid = snapshots.reduce((acc, c) => acc + c.totalPaid, 0);
  const totalRemaining = snapshots.reduce((acc, c) => acc + c.balanceRemaining, 0);
  const totalDeposits = snapshots.reduce((acc, c) => acc + (c.tenant.securityDeposit || 0), 0);
  const overallRate = totalRent > 0 ? Math.round((totalPaid / totalRent) * 100) : 0;

  rows.push([
    '"الإجمالي العام"',
    `"${snapshots.length} وحدات"`,
    '""',
    '""',
    '""',
    totalRent,
    totalPaid,
    totalRemaining,
    `"${overallRate}%"`,
    '""',
    totalDeposits,
  ]);

  const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `سجل_إيجارات_${monthName.replace(/\s+/g, '_')}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Full JSON Backup export
 */
export function exportDataAsJSON(): void {
  const data = {
    app: 'تحصيل',
    version: '2.0',
    exportDate: new Date().toISOString(),
    buildings: loadBuildings(),
    tenants: loadTenants(),
    payments: loadPayments(),
  };

  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `نسخة_احتياطية_تحصيل_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}
