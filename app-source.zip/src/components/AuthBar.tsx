import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { LogIn, LogOut, Send, RefreshCw, WifiOff, Inbox } from 'lucide-react';
import { ThemeMode } from '../types';

interface AuthBarProps {
  theme: ThemeMode;
  onOpenShareModal: () => void;
  pendingReceivedCount?: number;
  isOnline?: boolean;
}

export const AuthBar: React.FC<AuthBarProps> = ({
  theme,
  onOpenShareModal,
  pendingReceivedCount = 0,
  isOnline = true,
}) => {
  const { user, isLoading, signIn, signOut } = useAuth();
  const [authError, setAuthError] = useState<string | null>(null);

  const handleLogin = async () => {
    setAuthError(null);
    try {
      await signIn();
    } catch (e: any) {
      setAuthError(e?.message || 'فشل تسجيل الدخول بحساب Google');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-neutral-700/50 bg-neutral-800/40 text-xs text-neutral-400">
        <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-500" />
        <span>جاري التحقق...</span>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex items-center gap-2 flex-wrap">
        {!isOnline && (
          <div
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl border text-[11px] font-semibold ${
              theme === 'dark'
                ? 'bg-amber-950/40 border-amber-500/40 text-amber-300'
                : 'bg-amber-50 border-amber-300 text-amber-900'
            }`}
          >
            <WifiOff className="w-3.5 h-3.5 text-amber-400" />
            <span>أوفلاين (حفظ محلي)</span>
          </div>
        )}
        <button
          onClick={handleLogin}
          disabled={!isOnline}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl font-bold text-xs shadow-xs transition-all active:scale-95 cursor-pointer ${
            !isOnline
              ? 'opacity-50 cursor-not-allowed bg-neutral-800 text-neutral-400 border border-neutral-700'
              : 'bg-white hover:bg-neutral-100 text-neutral-900 border border-neutral-300'
          }`}
          title="تسجيل الدخول بحساب Google لحفظ واستعادة بياناتك"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span>تسجيل الدخول بحساب Google</span>
        </button>
        {authError && <span className="text-[10px] text-rose-400 font-medium">{authError}</span>}
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2 flex-wrap">
      {/* Offline Status Badge */}
      {!isOnline && (
        <div
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl border text-[11px] font-semibold ${
            theme === 'dark'
              ? 'bg-amber-950/40 border-amber-500/40 text-amber-300'
              : 'bg-amber-50 border-amber-300 text-amber-900'
          }`}
          title="وضع العمل دون إنترنت: الحفظ محلي بالكامل وتتم المزامنة تلقائياً عند استعادة الاتصال"
        >
          <WifiOff className="w-3.5 h-3.5 text-amber-400" />
          <span>أوفلاين</span>
        </div>
      )}

      {/* Share / Send Updates Button */}
      <button
        onClick={onOpenShareModal}
        disabled={!isOnline}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all active:scale-95 cursor-pointer relative ${
          !isOnline
            ? 'opacity-60 cursor-not-allowed bg-neutral-800 text-neutral-400 border-neutral-700'
            : theme === 'dark'
            ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 hover:bg-amber-500/25'
            : 'bg-amber-100 border-amber-300 text-amber-900 hover:bg-amber-200'
        }`}
        title={!isOnline ? 'مشاركة التحديثات تتطلب اتصالاً بالإنترنت' : 'مشاركة وإرسال التحديثات لشركائك'}
      >
        <Send className="w-3.5 h-3.5 text-amber-400" />
        <span>مشاركة التحديثات</span>
        {pendingReceivedCount > 0 && (
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
          </span>
        )}
      </button>

      {/* User Info & Sign Out */}
      <div
        className={`flex items-center gap-2 p-1 pl-2.5 rounded-xl border ${
          theme === 'dark' ? 'bg-[#151C28] border-neutral-700' : 'bg-neutral-100 border-neutral-300'
        }`}
      >
        {user.photoURL ? (
          <img
            src={user.photoURL}
            alt={user.displayName || 'User'}
            className="w-6 h-6 rounded-full border border-amber-400"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="w-6 h-6 rounded-full bg-amber-500 text-neutral-950 font-bold text-xs flex items-center justify-center">
            {(user.displayName || user.email || 'U')[0].toUpperCase()}
          </div>
        )}
        <span
          className="text-xs font-semibold max-w-[120px] truncate hidden md:inline"
          title={user.email || ''}
        >
          {user.displayName || user.email?.split('@')[0]}
        </span>
        <button
          onClick={signOut}
          className="p-1 text-neutral-400 hover:text-rose-400 rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer"
          title="تسجيل الخروج"
        >
          <LogOut className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
