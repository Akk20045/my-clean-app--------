import React, { useEffect, useState } from 'react';
import { WifiOff, Wifi, CheckCircle2, ShieldCheck, RefreshCw, X } from 'lucide-react';
import { ThemeMode } from '../types';

interface OfflineBannerProps {
  isOnline: boolean;
  wasOffline: boolean;
  onClearWasOffline: () => void;
  onManualSync?: () => void;
  isSyncing?: boolean;
  theme: ThemeMode;
}

export const OfflineBanner: React.FC<OfflineBannerProps> = ({
  isOnline,
  wasOffline,
  onClearWasOffline,
  onManualSync,
  isSyncing = false,
  theme,
}) => {
  const [showReconnectedToast, setShowReconnectedToast] = useState(false);
  const [isDismissedOffline, setIsDismissedOffline] = useState(false);

  // When connection recovers, show a success toast for 6 seconds
  useEffect(() => {
    if (wasOffline && isOnline) {
      setShowReconnectedToast(true);
      const timer = setTimeout(() => {
        setShowReconnectedToast(false);
        onClearWasOffline();
      }, 6000);
      return () => clearTimeout(timer);
    }
  }, [wasOffline, isOnline, onClearWasOffline]);

  // Reset dismissal if goes offline again
  useEffect(() => {
    if (!isOnline) {
      setIsDismissedOffline(false);
    }
  }, [isOnline]);

  return (
    <>
      {/* 1. Offline Alert Banner */}
      {!isOnline && !isDismissedOffline && (
        <div
          className={`w-full border-b transition-all px-4 py-2.5 ${
            theme === 'dark'
              ? 'bg-amber-950/80 border-amber-500/40 text-amber-200'
              : 'bg-amber-50 border-amber-300 text-amber-900'
          }`}
          role="status"
          aria-live="polite"
        >
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs md:text-sm">
            <div className="flex items-center gap-2.5">
              <span className="relative flex h-3 w-3 shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500"></span>
              </span>
              <div className="flex items-center gap-1.5 font-bold">
                <WifiOff className="w-4 h-4 text-amber-400 shrink-0" />
                <span>الوضع غير المتصل (أوفلاين كامل):</span>
              </div>
              <span className="hidden sm:inline opacity-90">
                يمكنك إضافة وتعديل وحذف العمارات والمستأجرين والدفعات وإصدار السندات وحساب التقارير بحرية تامة دون إنترنت. تُحفظ بياناتك محلياً 100%.
              </span>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300">
                <ShieldCheck className="w-3.5 h-3.5" />
                حفظ محلي آمن 100%
              </span>
              <button
                onClick={() => setIsDismissedOffline(true)}
                className="p-1 rounded-md hover:bg-amber-500/20 text-amber-400 hover:text-amber-200 transition-colors cursor-pointer"
                title="إخفاء التنبيه"
                aria-label="إخفاء التنبيه"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. Reconnected Success Toast */}
      {showReconnectedToast && (
        <div className="fixed bottom-5 left-5 z-50 animate-bounce duration-1000 max-w-md">
          <div
            className={`flex items-center justify-between gap-3 px-4 py-3 rounded-2xl shadow-2xl border backdrop-blur-md ${
              theme === 'dark'
                ? 'bg-emerald-950/95 border-emerald-500/40 text-emerald-100'
                : 'bg-emerald-50 border-emerald-300 text-emerald-900 shadow-emerald-500/10'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 shrink-0">
                <Wifi className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold flex items-center gap-1.5 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  تمت استعادة الاتصال بالإنترنت!
                </h4>
                <p className="text-[11px] opacity-80 mt-0.5">
                  بياناتك محفوظة محلياً وتعمل بكفاءة تامة.
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowReconnectedToast(false)}
              className="p-1 rounded-lg text-emerald-400 hover:text-emerald-200 transition cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </>
  );
};
