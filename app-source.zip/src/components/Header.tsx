import React, { useState, useRef, useEffect } from 'react';
import {
  LayoutGrid,
  Table2,
  Plus,
  Sun,
  Moon,
  Type,
  FileSpreadsheet,
  FileText,
  Printer,
  ChevronDown,
  SlidersHorizontal,
} from 'lucide-react';
import { FontFamily, ThemeMode, ViewMode } from '../types';
import { AuthBar } from './AuthBar';
import { ThemeToggleList } from './ThemeToggleList';
import { isDarkTheme, getThemeConfig } from '../utils/theme';

interface HeaderProps {
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  currency: string;
  onCurrencyChange: (currency: string) => void;
  theme: ThemeMode;
  onToggleTheme?: () => void;
  onThemeChange: (theme: ThemeMode) => void;
  font: FontFamily;
  onFontChange: (font: FontFamily) => void;
  onOpenAddBuildingModal: () => void;
  onOpenAddModal: () => void;
  onOpenBulkEditModal?: () => void;
  onExportExcel: () => void;
  onExportWord: () => void;
  onOpenPdfReport: () => void;
  onExportJSON: () => void;
  onLoadDemoData: () => void;
  onClearAll: () => void;
  tenantsCount: number;
  buildingsCount: number;
  onOpenShareModal: () => void;
  pendingReceivedCount?: number;
  isOnline?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  viewMode,
  onViewModeChange,
  currency,
  onCurrencyChange,
  theme,
  onToggleTheme,
  onThemeChange,
  font,
  onFontChange,
  onOpenAddBuildingModal,
  onOpenAddModal,
  onOpenBulkEditModal,
  onExportExcel,
  onExportWord,
  onOpenPdfReport,
  tenantsCount,
  onOpenShareModal,
  pendingReceivedCount = 0,
  isOnline = true,
}) => {
  const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const isDark = isDarkTheme(theme);
  const themeConfig = getThemeConfig(theme);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsExportMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header
      className={`border-b transition-colors px-4 lg:px-8 py-3.5 ${themeConfig.bgHeader} ${themeConfig.borderCard} ${themeConfig.textColor}`}
    >
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Zone 1: Pure Brand Name (No icon next to it as requested) */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
          <div className="flex items-baseline gap-2">
            <h1 className="text-2xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-l from-amber-400 via-amber-500 to-amber-200">
              تحصيل
            </h1>
            <span
              className={`text-xs font-semibold ${
                isDark ? 'text-neutral-400' : 'text-neutral-500'
              }`}
            >
              إدارة وتحصيل الإيجارات
            </span>
          </div>

          {/* Mobile view toggle */}
          <div
            className={`flex md:hidden items-center p-1 rounded-xl border ${themeConfig.bgSubCard} ${themeConfig.borderCard}`}
          >
            <button
              onClick={() => onViewModeChange('cards')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'cards'
                  ? 'bg-amber-500 text-neutral-950 font-bold'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
              title="عرض الصناديق (Boxes)"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => onViewModeChange('table')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-amber-500 text-neutral-950 font-bold'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
              title="عرض جدول إكسل (Excel Table)"
            >
              <Table2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Zone 2: System View Switcher (Cards / Boxes vs Excel-like Table) */}
        <div
          className={`hidden md:flex items-center gap-1 p-1 rounded-xl border ${themeConfig.bgSubCard} ${themeConfig.borderCard}`}
        >
          <button
            onClick={() => onViewModeChange('cards')}
            className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              viewMode === 'cards'
                ? isDark
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-xs'
                  : 'bg-white text-amber-800 border border-amber-300 shadow-xs font-bold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>نظام الصناديق (Boxes)</span>
          </button>

          <button
            onClick={() => onViewModeChange('table')}
            className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              viewMode === 'table'
                ? isDark
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-xs'
                  : 'bg-white text-amber-800 border border-amber-300 shadow-xs font-bold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Table2 className="w-3.5 h-3.5" />
            <span>جدول شبيه بإكسل (Table Ledger)</span>
          </button>
        </div>

        {/* Zone 3: Controls (Font, Theme, Currency, Export Dropdown, Add Buttons) */}
        <div className="flex items-center gap-2 w-full md:w-auto justify-end flex-wrap">

          {/* Cloud Auth & Updates Sharing */}
          <AuthBar
            theme={theme}
            onOpenShareModal={onOpenShareModal}
            pendingReceivedCount={pendingReceivedCount}
            isOnline={isOnline}
          />

          {/* Font Selector */}
          <div className="flex items-center gap-1">
            <Type className="w-3.5 h-3.5 text-neutral-400 hidden sm:inline" />
            <select
              value={font}
              onChange={(e) => onFontChange(e.target.value as FontFamily)}
              className={`py-1.5 px-2.5 rounded-xl border text-xs font-semibold outline-none transition-colors cursor-pointer ${themeConfig.bgSubCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
              title="اختر نوع الخط المفضل"
            >
              <option value="readex">خط ريديكس (Readex Pro)</option>
              <option value="cairo">خط كايرو (Cairo)</option>
              <option value="tajawal">خط تجوال (Tajawal)</option>
              <option value="almarai">خط المراعي (Almarai)</option>
              <option value="noto">خط نوتو (Noto Sans Arabic)</option>
              <option value="alexandria">خط الإسكندرية (Alexandria)</option>
              <option value="ibm">خط آي بي إم (IBM Plex Sans)</option>
              <option value="amiri">خط أميري (Amiri)</option>
              <option value="changa">خط تشانجا (Changa)</option>
              <option value="jakarta">خط جاكارتا (Jakarta Sans)</option>
            </select>
          </div>

          {/* Currency Selector */}
          <select
            value={currency}
            onChange={(e) => onCurrencyChange(e.target.value)}
            className={`py-1.5 px-2.5 rounded-xl border text-xs font-bold font-mono outline-none transition-colors cursor-pointer ${themeConfig.bgSubCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
            title="تغيير العملة"
          >
            <option value="JOD">JOD (دينار)</option>
            <option value="USD">USD ($)</option>
            <option value="SAR">SAR (ريال)</option>
            <option value="AED">AED (درهم)</option>
          </select>

          {/* Rich Theme Toggle List Dropdown */}
          <ThemeToggleList
            currentTheme={theme}
            onThemeChange={onThemeChange}
          />

          {/* Multi-Format Export Dropdown Menu (Excel, Word, PDF) */}
          {tenantsCount > 0 && (
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setIsExportMenuOpen(!isExportMenuOpen)}
                className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                  isDark
                    ? 'bg-neutral-800/90 border-neutral-700 text-neutral-200 hover:border-amber-500/50'
                    : 'bg-neutral-100 border-neutral-300 text-neutral-800 hover:bg-neutral-200'
                }`}
                title="خيارات تصدير التقارير (إكسل، وورد، PDF)"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-amber-500" />
                <span>تصدير تقرير</span>
                <ChevronDown className="w-3 h-3 text-neutral-400" />
              </button>

              {isExportMenuOpen && (
                <div
                  className={`absolute start-0 mt-2 w-52 max-w-[calc(100vw-2rem)] rounded-2xl border shadow-2xl py-2 z-50 text-xs animate-in fade-in zoom-in-95 duration-150 ${
                    isDark
                      ? 'bg-[#151C28] border-neutral-700 text-white'
                      : 'bg-white border-neutral-200 text-neutral-900 shadow-xl'
                  }`}
                >
                  <div className="px-3 py-1.5 text-[10px] text-neutral-400 font-bold border-b border-neutral-700/40">
                    اختر صيغة التصدير
                  </div>

                  <button
                    onClick={() => {
                      setIsExportMenuOpen(false);
                      onExportExcel();
                    }}
                    className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 text-right font-medium transition-colors cursor-pointer ${
                      isDark ? 'hover:bg-emerald-950/40 hover:text-emerald-300' : 'hover:bg-emerald-50 hover:text-emerald-800'
                    }`}
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-500" />
                    <div>
                      <span className="font-bold block">تصدير إكسل (Excel .xls)</span>
                      <span className="text-[10px] text-neutral-400">ملف جداول منسق بالكامل</span>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      setIsExportMenuOpen(false);
                      onExportWord();
                    }}
                    className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 text-right font-medium transition-colors cursor-pointer ${
                      isDark ? 'hover:bg-sky-950/40 hover:text-sky-300' : 'hover:bg-sky-50 hover:text-sky-800'
                    }`}
                  >
                    <FileText className="w-4 h-4 text-sky-500" />
                    <div>
                      <span className="font-bold block">تصدير وورد (Word .doc)</span>
                      <span className="text-[10px] text-neutral-400">مستند رسمي مع خانات التوقيع</span>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      setIsExportMenuOpen(false);
                      onOpenPdfReport();
                    }}
                    className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 text-right font-medium transition-colors cursor-pointer ${
                      isDark ? 'hover:bg-amber-950/40 hover:text-amber-300' : 'hover:bg-amber-50 hover:text-amber-800'
                    }`}
                  >
                    <Printer className="w-4 h-4 text-amber-500" />
                    <div>
                      <span className="font-bold block">طباعة / حفظ PDF</span>
                      <span className="text-[10px] text-neutral-400">معاينة وطباعة فورية</span>
                    </div>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Bulk Edit Units / Change Types Option from the top */}
          {tenantsCount > 0 && onOpenBulkEditModal && (
            <button
              onClick={onOpenBulkEditModal}
              className={`flex items-center gap-1.5 py-2 px-3 rounded-xl border text-xs font-bold transition-all active:scale-95 whitespace-nowrap cursor-pointer ${
                isDark
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 hover:bg-amber-500/25'
                  : 'bg-amber-100/70 border-amber-300 text-amber-900 hover:bg-amber-100'
              }`}
              title="تحديد الوحدات وتغيير نوعها دفعة واحدة (محل تجاري، شقة سكنية، أو أخرى)"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-amber-500" />
              <span>تعديل نوع الوحدات</span>
            </button>
          )}

          {/* Add Building Button */}
          <button
            onClick={onOpenAddBuildingModal}
            className={`flex items-center gap-1.5 py-2 px-3 rounded-xl border text-xs font-bold transition-all active:scale-95 whitespace-nowrap cursor-pointer ${
              isDark
                ? 'bg-[#182130] hover:bg-[#202C40] text-amber-300 border-amber-500/40'
                : 'bg-amber-50 hover:bg-amber-100 text-amber-800 border-amber-300'
            }`}
            title="إضافة عمارة أو مجمع عقاري جديد"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ إضافة عمارة</span>
          </button>

          {/* Add Tenant/Apartment Button */}
          <button
            onClick={onOpenAddModal}
            className="flex items-center gap-2 py-2 px-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-extrabold text-xs shadow-md transition-all active:scale-95 whitespace-nowrap cursor-pointer"
            title="إضافة شقة ومستأجر تابعة لعمارة"
          >
            <Plus className="w-4 h-4" />
            <span>+ إضافة شقة ومستأجر</span>
          </button>
        </div>
      </div>
    </header>
  );
};
