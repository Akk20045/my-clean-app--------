import React, { useState } from 'react';
import {
  Send,
  Inbox,
  UserCheck,
  CheckCircle2,
  AlertCircle,
  Clock,
  Building2,
  Users,
  CreditCard,
  Trash2,
  X,
  Mail,
  ShieldCheck,
  FileText,
  ArrowRight,
} from 'lucide-react';
import { Building, PaymentRecord, Tenant, ThemeMode } from '../types';
import { useAuth } from '../context/AuthContext';
import {
  sendPortfolioUpdateToAccount,
  markSharedUpdateApplied,
  deleteSharedUpdate,
  SharedUpdatePackage,
} from '../firebase/firestoreService';

interface ShareUpdatesModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: ThemeMode;
  currentBuildings: Building[];
  currentTenants: Tenant[];
  currentPayments: PaymentRecord[];
  incomingUpdates: SharedUpdatePackage[];
  onApplyUpdate: (pkg: SharedUpdatePackage) => Promise<void>;
}

export const ShareUpdatesModal: React.FC<ShareUpdatesModalProps> = ({
  isOpen,
  onClose,
  theme,
  currentBuildings,
  currentTenants,
  currentPayments,
  incomingUpdates,
  onApplyUpdate,
}) => {
  const { user, signIn } = useAuth();
  const [activeTab, setActiveTab] = useState<'send' | 'received'>('send');
  const [recipientEmail, setRecipientEmail] = useState('');
  const [note, setNote] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState<string | null>(null);
  const [sendError, setSendError] = useState<string | null>(null);
  const [applyingId, setApplyingId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    setSendError(null);
    setSendSuccess(null);

    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      setSendError('يتطلب إرسال التحديثات السحابية اتصالاً بالإنترنت. يمكنك إدارة وتعديل كافة العقارات محلياً بأمان.');
      return;
    }

    if (!user) {
      await signIn();
      return;
    }

    const cleanEmail = recipientEmail.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      setSendError('يرجى كتابة بريد إلكتروني صحيح لحساب Google المستلم');
      return;
    }

    if (cleanEmail === user.email?.toLowerCase()) {
      setSendError('لا يمكنك إرسال التحديث لنفس البريد الإلكتروني المسجل به حالياً');
      return;
    }

    try {
      setIsSending(true);
      await sendPortfolioUpdateToAccount(
        user.uid,
        user.email || '',
        cleanEmail,
        note,
        currentBuildings,
        currentTenants,
        currentPayments
      );
      setSendSuccess(`تم إرسال التحديث بنجاح إلى (${cleanEmail})! سيتمكن من تطبيقها فوراً على جهازه.`);
      setRecipientEmail('');
      setNote('');
    } catch (err: any) {
      setSendError(err?.message || 'فشل إرسال التحديث إلى هذا الحساب');
    } finally {
      setIsSending(false);
    }
  };

  const handleApply = async (pkg: SharedUpdatePackage) => {
    try {
      setApplyingId(pkg.id);
      await onApplyUpdate(pkg);
      await markSharedUpdateApplied(pkg.id);
    } catch (err) {
      console.error('Failed to apply update', err);
    } finally {
      setApplyingId(null);
    }
  };

  const handleDelete = async (pkgId: string) => {
    try {
      await deleteSharedUpdate(pkgId);
    } catch (err) {
      console.error('Failed to delete update', err);
    }
  };

  const pendingUpdates = incomingUpdates.filter((u) => u.status === 'pending');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className={`w-full max-w-xl rounded-2xl border shadow-2xl p-6 relative transition-all ${
          theme === 'dark'
            ? 'bg-[#0E131E] border-neutral-700/70 text-white'
            : 'bg-white border-neutral-200 text-neutral-900'
        }`}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-1.5 rounded-lg text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="mb-4">
          <h3 className="text-lg font-black tracking-tight flex items-center gap-2">
            <span>مشاركة التحديثات المستقلة</span>
          </h3>
          <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
            شارك بياناتك لمرة واحدة مع شريكك لتطبق على حسابه وتلفونه، ويبقى كل شخص مستقلاً تماماً في تعديلاته
            دون التأثير على حساب الآخر.
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-neutral-700/50 mb-5">
          <button
            onClick={() => setActiveTab('send')}
            className={`flex items-center gap-2 pb-2.5 px-4 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'send'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Send className="w-4 h-4" />
            <span>إرسال آخر التحديثات لشخص / حساب</span>
          </button>

          <button
            onClick={() => setActiveTab('received')}
            className={`flex items-center gap-2 pb-2.5 px-4 text-xs font-bold border-b-2 transition-colors cursor-pointer relative ${
              activeTab === 'received'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Inbox className="w-4 h-4" />
            <span>التحديثات المستلمة</span>
            {pendingUpdates.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-amber-500 text-neutral-950 font-bold text-[10px]">
                {pendingUpdates.length}
              </span>
            )}
          </button>
        </div>

        {/* TAB 1: SEND UPDATES */}
        {activeTab === 'send' && (
          <div>
            {!user ? (
              <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-500/10 text-xs text-amber-200 mb-4 flex items-center justify-between">
                <span>سجل الدخول بحساب Google أولاً لتتمكن من إرسال التحديثات.</span>
                <button
                  onClick={() => signIn()}
                  className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs cursor-pointer"
                >
                  تسجيل الدخول
                </button>
              </div>
            ) : (
              <form onSubmit={handleSend} className="space-y-4">
                {/* Recipient Email */}
                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                    البريد الإلكتروني لحساب المستلم (Google Account):
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-neutral-400 absolute right-3 top-3" />
                    <input
                      type="email"
                      required
                      value={recipientEmail}
                      onChange={(e) => setRecipientEmail(e.target.value)}
                      placeholder="partner@gmail.com"
                      className={`w-full pr-9 pl-3 py-2.5 rounded-xl border text-xs outline-none transition-colors ${
                        theme === 'dark'
                          ? 'bg-[#151C28] border-neutral-700 focus:border-amber-400 text-white placeholder-neutral-500'
                          : 'bg-neutral-50 border-neutral-300 focus:border-amber-500 text-neutral-900 placeholder-neutral-400'
                      }`}
                    />
                  </div>
                </div>

                {/* Optional Note */}
                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                    ملاحظة أو رسالة للشريك (اختياري):
                  </label>
                  <input
                    type="text"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="مثال: تحديث دفعات شهر سبتمبر أو العمارة الجديدة"
                    className={`w-full px-3 py-2.5 rounded-xl border text-xs outline-none transition-colors ${
                      theme === 'dark'
                        ? 'bg-[#151C28] border-neutral-700 focus:border-amber-400 text-white placeholder-neutral-500'
                        : 'bg-neutral-50 border-neutral-300 focus:border-amber-500 text-neutral-900 placeholder-neutral-400'
                    }`}
                  />
                </div>

                {/* Snapshot Summary Preview */}
                <div
                  className={`p-3 rounded-xl border ${
                    theme === 'dark' ? 'bg-[#141B27] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
                  }`}
                >
                  <span className="text-[11px] font-bold text-neutral-400 block mb-2">
                    البيانات التي سيتم إرسالها في هذا التحديث:
                  </span>
                  <div className="grid grid-cols-3 gap-2 text-center text-xs">
                    <div className="p-2 rounded-lg bg-neutral-800/40 border border-neutral-700/40">
                      <span className="font-black text-amber-400 block text-sm">
                        {currentBuildings.length}
                      </span>
                      <span className="text-[10px] text-neutral-400">عمارات ومجمعات</span>
                    </div>
                    <div className="p-2 rounded-lg bg-neutral-800/40 border border-neutral-700/40">
                      <span className="font-black text-amber-400 block text-sm">
                        {currentTenants.length}
                      </span>
                      <span className="text-[10px] text-neutral-400">شقق ومستأجرين</span>
                    </div>
                    <div className="p-2 rounded-lg bg-neutral-800/40 border border-neutral-700/40">
                      <span className="font-black text-amber-400 block text-sm">
                        {currentPayments.length}
                      </span>
                      <span className="text-[10px] text-neutral-400">دفعات مسجلة</span>
                    </div>
                  </div>
                </div>

                {/* Important reassurance clause */}
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[11px] flex items-start gap-2">
                  <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
                  <span>
                    <strong>ضمان الاستقلالية:</strong> المستلم سيحصل على نسخته الخاصة؛ وإذا عدل مبلغ دفعة، أو حذف عقار،
                    أو غير أي شيء، <strong>لن يتأثر حسابك إطلاقاً</strong>، ولن تنبعث له أي دفعات مستقبلية تسجلها أنت إلا
                    إذا اخترت إرسالها له مجدداً.
                  </span>
                </div>

                {/* Feedback */}
                {sendSuccess && (
                  <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                    <span>{sendSuccess}</span>
                  </div>
                )}

                {sendError && (
                  <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                    <span>{sendError}</span>
                  </div>
                )}

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={isSending || !recipientEmail.trim()}
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-bold text-xs shadow-md transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSending ? 'جاري إرسال التحديث...' : 'إرسال آخر التحديثات لهذا الحساب 📤'}</span>
                </button>
              </form>
            )}
          </div>
        )}

        {/* TAB 2: RECEIVED UPDATES */}
        {activeTab === 'received' && (
          <div>
            {!user ? (
              <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-500/10 text-xs text-amber-200 mb-4 flex items-center justify-between">
                <span>سجل الدخول بحساب Google لعرض التحديثات التي أرسلها الشركاء لك.</span>
                <button
                  onClick={() => signIn()}
                  className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs cursor-pointer"
                >
                  تسجيل الدخول
                </button>
              </div>
            ) : incomingUpdates.length === 0 ? (
              <div className="py-12 text-center text-neutral-400">
                <Inbox className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p className="text-xs font-semibold">لا توجد تحديثات مستلمة جديدة حالياً.</p>
                <p className="text-[11px] text-neutral-500 mt-1">
                  عندما يرسل لك شخص آخر تحديثاً أو نسخة من عقاراته، ستظهر هنا لتطبيقها بنقرة واحدة.
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                {incomingUpdates.map((pkg) => {
                  const isPending = pkg.status === 'pending';
                  const dateStr = new Date(pkg.createdAt).toLocaleDateString('ar-EG', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  });

                  return (
                    <div
                      key={pkg.id}
                      className={`p-4 rounded-xl border transition-all ${
                        isPending
                          ? theme === 'dark'
                            ? 'bg-[#151C28] border-amber-500/40 shadow-xs'
                            : 'bg-amber-50/50 border-amber-300'
                          : theme === 'dark'
                          ? 'bg-[#111620] border-neutral-800 opacity-75'
                          : 'bg-neutral-50 border-neutral-200 opacity-75'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs text-amber-400">{pkg.senderEmail}</span>
                            {isPending ? (
                              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                                تحديث جديد
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-400 text-[10px]">
                                تم تطبيقه مسبقاً
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-neutral-400 flex items-center gap-1 mt-0.5">
                            <Clock className="w-3 h-3" />
                            <span>{dateStr}</span>
                          </span>
                        </div>

                        <button
                          onClick={() => handleDelete(pkg.id)}
                          className="p-1 rounded-lg text-neutral-400 hover:text-rose-400 transition cursor-pointer"
                          title="حذف هذا التحديث من القائمة"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {pkg.note && (
                        <p className="text-xs bg-black/20 p-2 rounded-lg mb-3 text-neutral-300 leading-relaxed">
                          "{pkg.note}"
                        </p>
                      )}

                      <div className="flex items-center justify-between gap-2 mt-3 pt-2.5 border-t border-neutral-700/40 text-xs">
                        <span className="text-neutral-400 text-[11px]">
                          يحتوي على: {pkg.buildingsCount} عمارات • {pkg.tenantsCount} شقق • {pkg.paymentsCount} دفعة
                        </span>

                        <button
                          onClick={() => handleApply(pkg)}
                          disabled={applyingId === pkg.id}
                          className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all active:scale-95 cursor-pointer disabled:opacity-50 flex items-center gap-1"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{applyingId === pkg.id ? 'جاري التطبيق...' : 'تطبيق على حسابي لمرة واحدة'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Footer */}
        <div className="mt-5 pt-3 border-t border-neutral-700/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
