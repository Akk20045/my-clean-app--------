import React from 'react';
import {
  Phone,
  MessageCircle,
  PlusCircle,
  History,
  Shield,
  Building2,
  Store,
  Home,
  Briefcase,
  Pencil,
  Trash2,
  Sparkles,
} from 'lucide-react';
import { TenantFinancialSnapshot, ThemeMode, UnitType } from '../types';
import {
  formatCurrency,
  generateWhatsAppLink,
  sanitizePhoneForCall,
  getUnitTypeLabel,
  getUnitDisplayTag,
} from '../utils/formatters';
import { isDarkTheme, getThemeConfig } from '../utils/theme';

interface TenantCardProps {
  snapshot: TenantFinancialSnapshot;
  currency: string;
  onRecordPayment: (tenantId: string) => void;
  onViewHistory: (tenantId: string) => void;
  onEditTenant: (tenantId: string) => void;
  onDeleteTenant?: (tenantId: string) => void;
  theme: ThemeMode;
}

export const TenantCard: React.FC<TenantCardProps> = ({
  snapshot,
  currency,
  onRecordPayment,
  onViewHistory,
  onEditTenant,
  onDeleteTenant,
  theme,
}) => {
  const isDark = isDarkTheme(theme);
  const themeConfig = getThemeConfig(theme);

  const {
    tenant,
    buildingName,
    monthlyRent,
    totalPaid,
    balanceRemaining,
    percentagePaid,
    status,
    monthKey,
  } = snapshot;

  const getUnitTypeIcon = (type: UnitType) => {
    switch (type) {
      case 'commercial_shop':
        return <Store className="w-4 h-4 text-sky-500" />;
      case 'office':
        return <Briefcase className="w-4 h-4 text-indigo-500" />;
      case 'penthouse':
        return <Building2 className="w-4 h-4 text-amber-500" />;
      case 'villa':
        return <Home className="w-4 h-4 text-purple-500" />;
      case 'other':
        return <Sparkles className="w-4 h-4 text-amber-400" />;
      case 'apartment':
      default:
        return <Home className="w-4 h-4 text-neutral-400" />;
    }
  };

  const getStatusBadge = () => {
    switch (status) {
      case 'paid':
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-600 dark:text-emerald-400 shadow-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs">مسدد بالكامل</span>
          </div>
        );
      case 'partial':
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-700 dark:text-amber-300 shadow-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            <span className="text-xs">
              دفعة جزئية (متبقي {formatCurrency(balanceRemaining, currency)})
            </span>
          </div>
        );
      case 'unpaid':
      default:
        return (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/15 border border-rose-500/40 text-rose-700 dark:text-rose-300 shadow-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            <span className="text-xs">غير مسدد</span>
          </div>
        );
    }
  };

  const getProgressBarColor = () => {
    if (percentagePaid >= 100) return 'from-emerald-500 to-teal-400';
    if (percentagePaid > 0) return 'from-amber-500 to-amber-400';
    return 'from-rose-500 to-rose-400';
  };

  const unitTag = getUnitDisplayTag(tenant.unitNumber, tenant.unitType, tenant.customUnitType);
  const typeLabel = getUnitTypeLabel(tenant.unitType, tenant.customUnitType);

  const whatsappUrl = generateWhatsAppLink(
    tenant.phone,
    tenant.name,
    unitTag,
    buildingName,
    monthKey,
    status,
    monthlyRent,
    totalPaid,
    balanceRemaining,
    currency
  );

  const dialPhone = sanitizePhoneForCall(tenant.phone);

  return (
    <div
      className={`group relative flex flex-col justify-between p-5 rounded-2xl border shadow-md transition-all duration-200 hover:-translate-y-0.5 ${themeConfig.bgCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
    >
      {/* 1. Header: Building Name & Unit Tag + Status Badge */}
      <div>
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="space-y-0.5">
            <div className={`flex items-center gap-1.5 text-xs font-medium ${themeConfig.subTextColor}`}>
              {getUnitTypeIcon(tenant.unitType)}
              <span className="truncate max-w-[190px]">{buildingName}</span>
            </div>
            <h3 className="text-base font-extrabold tracking-tight flex items-center gap-2 flex-wrap">
              <span>{tenant.unitNumber?.trim() ? tenant.unitNumber : tenant.name}</span>
              <span
                className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
                  tenant.unitType === 'commercial_shop'
                    ? 'bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/30'
                    : tenant.unitType === 'office'
                    ? 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/30'
                    : tenant.unitType === 'penthouse'
                    ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30'
                    : tenant.unitType === 'villa'
                    ? 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/30'
                    : tenant.unitType === 'other'
                    ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30'
                    : 'bg-neutral-500/10 text-neutral-600 dark:text-neutral-400 border-neutral-500/20'
                }`}
              >
                {typeLabel}
              </span>
            </h3>
          </div>
          <div>{getStatusBadge()}</div>
        </div>

        {/* 2. Tenant Contact: Name + 1-Tap Call & WhatsApp */}
        <div
          className={`py-3 border-y mb-4 flex items-center justify-between gap-3 ${themeConfig.borderCard} ${themeConfig.bgSubCard} -mx-5 px-5`}
        >
          <div className="min-w-0">
            <div className="text-sm font-bold truncate">{tenant.name}</div>
            <div className={`text-xs tabular-nums font-mono mt-0.5 ${themeConfig.subTextColor}`} dir="ltr">
              {tenant.phone || '—'}
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {/* Call button */}
            {dialPhone ? (
              <a
                href={`tel:${dialPhone}`}
                className={`p-2 rounded-xl border transition-colors cursor-pointer ${themeConfig.bgCard} ${themeConfig.borderCard} hover:border-amber-500/60`}
                title={`اتصال هاتفياً: ${tenant.phone}`}
              >
                <Phone className="w-4 h-4" />
              </a>
            ) : (
              <button
                disabled
                className="p-2 rounded-xl border border-neutral-500/20 text-neutral-400 opacity-50 cursor-not-allowed"
                title="لا يوجد رقم هاتف مضاف"
              >
                <Phone className="w-4 h-4" />
              </button>
            )}

            {/* WhatsApp button */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 transition-colors cursor-pointer"
              title="مراسلة إشعار الإيجار عبر واتساب"
            >
              <MessageCircle className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* 3. Financial Snapshot (For Selected Month) */}
        <div className="space-y-3 mb-4">
          <div
            className={`grid grid-cols-3 gap-2 text-center p-3 rounded-xl border ${themeConfig.bgSubCard} ${themeConfig.borderCard}`}
          >
            <div>
              <span className={`block text-[11px] ${themeConfig.subTextColor}`}>الإيجار الكامل</span>
              <span className="text-sm font-bold tabular-nums font-mono">
                {formatCurrency(monthlyRent, currency)}
              </span>
            </div>
            <div>
              <span className={`block text-[11px] ${themeConfig.subTextColor}`}>المدفوع</span>
              <span className="text-sm font-bold text-emerald-600 dark:text-emerald-400 tabular-nums font-mono">
                {formatCurrency(totalPaid, currency)}
              </span>
            </div>
            <div>
              <span className={`block text-[11px] ${themeConfig.subTextColor}`}>المتبقي</span>
              <span
                className={`text-sm font-bold tabular-nums font-mono ${
                  balanceRemaining > 0 ? 'text-rose-600 dark:text-rose-400 font-extrabold' : themeConfig.subTextColor
                }`}
              >
                {formatCurrency(balanceRemaining, currency)}
              </span>
            </div>
          </div>

          {/* Visual Mini-Progress Bar */}
          <div className="space-y-1">
            <div className={`flex items-center justify-between text-[11px] font-medium ${themeConfig.subTextColor}`}>
              <span>نسبة السداد:</span>
              <span className="tabular-nums font-bold">{percentagePaid}%</span>
            </div>
            <div
              className={`w-full h-2 rounded-full overflow-hidden border ${themeConfig.bgSubCard} ${themeConfig.borderCard}`}
            >
              <div
                className={`h-full bg-gradient-to-r ${getProgressBarColor()} transition-all duration-500 rounded-full`}
                style={{ width: `${percentagePaid}%` }}
              />
            </div>
          </div>
        </div>

        {/* 4. Commercial Deposit Badge (if applicable) */}
        {tenant.securityDeposit > 0 && (
          <div className="mb-4 flex items-center justify-between px-3 py-2 rounded-xl bg-sky-500/10 border border-sky-500/30 text-xs">
            <div className="flex items-center gap-1.5 text-sky-600 dark:text-sky-400 font-semibold">
              <Shield className="w-3.5 h-3.5 shrink-0" />
              <span>
                ضمان المحل:{' '}
                <strong className="font-mono tabular-nums">
                  {formatCurrency(tenant.securityDeposit, currency)}
                </strong>
              </span>
            </div>
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-700 dark:text-sky-300">
              محتجز
            </span>
          </div>
        )}
      </div>

      {/* 5. Quick Actions: Record Payment, History, Edit, and Delete */}
      <div
        className={`pt-3 border-t flex items-center gap-2 ${themeConfig.borderCard}`}
      >
        <button
          onClick={() => onRecordPayment(tenant.id)}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 hover:from-amber-400 to-amber-600 hover:to-amber-500 text-neutral-950 font-bold text-xs shadow-md transition-all active:scale-[0.98] cursor-pointer"
        >
          <PlusCircle className="w-4 h-4" />
          <span>تسجيل دفعة</span>
        </button>

        <button
          onClick={() => onViewHistory(tenant.id)}
          className={`p-2.5 rounded-xl border transition-colors cursor-pointer ${themeConfig.bgSubCard} ${themeConfig.borderCard} hover:border-amber-500/60`}
          title="عرض سجل الدفعات السابقة"
        >
          <History className="w-4 h-4" />
        </button>

        <button
          onClick={() => onEditTenant(tenant.id)}
          className={`p-2.5 rounded-xl border transition-colors cursor-pointer ${themeConfig.bgSubCard} ${themeConfig.borderCard} hover:border-amber-500/60`}
          title="تعديل بيانات الشقة والإيجار والمستأجر"
        >
          <Pencil className="w-4 h-4" />
        </button>

        {onDeleteTenant && (
          <button
            onClick={() => onDeleteTenant(tenant.id)}
            className="p-2.5 rounded-xl border border-rose-500/30 text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
            title="حذف الشقة / المستأجر"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
