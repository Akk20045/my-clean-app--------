import React from 'react';
import { Wallet, CheckCircle2, Clock, ShieldCheck } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';
import { ThemeMode } from '../types';
import { isDarkTheme, getThemeConfig } from '../utils/theme';

interface FinancialOverviewProps {
  totalExpectedRent: number;
  totalCollected: number;
  totalRemaining: number;
  totalSecurityDeposits: number;
  currency: string;
  paidCount: number;
  partialCount: number;
  unpaidCount: number;
  totalTenants: number;
  theme: ThemeMode;
}

export const FinancialOverview: React.FC<FinancialOverviewProps> = ({
  totalExpectedRent,
  totalCollected,
  totalRemaining,
  totalSecurityDeposits,
  currency,
  paidCount,
  partialCount,
  unpaidCount,
  totalTenants,
  theme,
}) => {
  const isDark = isDarkTheme(theme);
  const themeConfig = getThemeConfig(theme);
  const collectionRate = totalExpectedRent > 0 ? Math.round((totalCollected / totalExpectedRent) * 100) : 0;

  if (totalTenants === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      {/* 4 Executive KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        {/* Card 1: Total Expected Rent */}
        <div
          className={`p-5 rounded-2xl border shadow-md transition-all ${themeConfig.bgCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
        >
          <div className={`flex items-center justify-between mb-2 ${themeConfig.subTextColor}`}>
            <span className="text-xs font-semibold tracking-wide">إجمالي الإيجارات المستحقة</span>
            <div
              className={`p-2 rounded-xl ${themeConfig.bgSubCard} ${themeConfig.borderCard} border`}
            >
              <Wallet className="w-4 h-4 text-amber-500" />
            </div>
          </div>
          <div className="text-2xl md:text-3xl font-extrabold tracking-tight tabular-nums font-mono">
            {formatCurrency(totalExpectedRent, currency)}
          </div>
          <p className={`mt-1 text-xs ${themeConfig.subTextColor}`}>
            عن جميع الوحدات ({totalTenants} وحدة)
          </p>
        </div>

        {/* Card 2: Total Collected */}
        <div
          className={`p-5 rounded-2xl border shadow-md transition-all ${themeConfig.bgCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold tracking-wide text-emerald-600 dark:text-emerald-400">المحصل حتى الآن</span>
            <div className="p-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-500">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl md:text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 tracking-tight tabular-nums font-mono">
            {formatCurrency(totalCollected, currency)}
          </div>
          <div className={`mt-2 flex items-center justify-between text-xs ${themeConfig.subTextColor}`}>
            <span>
              نسبة التحصيل: <strong className="text-emerald-600 dark:text-emerald-400 font-bold">{collectionRate}%</strong>
            </span>
            <span className="text-[11px]">{paidCount} وحدة مسددة</span>
          </div>
          <div
            className={`w-full h-1.5 rounded-full overflow-hidden mt-1.5 ${themeConfig.bgSubCard}`}
          >
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500 rounded-full"
              style={{ width: `${collectionRate}%` }}
            />
          </div>
        </div>

        {/* Card 3: Total Remaining */}
        <div
          className={`p-5 rounded-2xl border shadow-md transition-all ${themeConfig.bgCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold tracking-wide text-amber-600 dark:text-amber-400">المتبقي للتحصيل</span>
            <div className="p-2 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-500">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl md:text-3xl font-extrabold text-amber-600 dark:text-amber-400 tracking-tight tabular-nums font-mono">
            {formatCurrency(totalRemaining, currency)}
          </div>
          <p className={`mt-1 text-xs ${themeConfig.subTextColor}`}>
            على {partialCount + unpaidCount} وحدات متأخرة أو جزئية
          </p>
        </div>

        {/* Card 4: Held Commercial Deposits */}
        <div
          className={`p-5 rounded-2xl border shadow-md transition-all ${themeConfig.bgCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold tracking-wide text-sky-600 dark:text-sky-400">الضمانات التجارية المحتجزة</span>
            <div className="p-2 rounded-xl bg-sky-500/15 border border-sky-500/30 text-sky-500">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl md:text-3xl font-extrabold text-sky-600 dark:text-sky-400 tracking-tight tabular-nums font-mono">
            {formatCurrency(totalSecurityDeposits, currency)}
          </div>
          <p className={`mt-1 text-xs ${themeConfig.subTextColor}`}>
            ودائع وكفالات عقود تجارية ومحلات
          </p>
        </div>
      </div>

      {/* Quick Status Bar */}
      <div
        className={`flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 rounded-xl border text-xs ${themeConfig.bgCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
      >
        <div className="flex items-center gap-4 flex-wrap">
          <span className="font-bold">ملخص حالة السداد:</span>
          <span className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block shadow-sm" />
            مسدد بالكامل: {paidCount}
          </span>
          <span className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400 font-semibold">
            <span className="w-2 h-2 rounded-full bg-amber-500 inline-block shadow-sm" />
            دفعة جزئية: {partialCount}
          </span>
          <span className="flex items-center gap-1.5 text-rose-600 dark:text-rose-400 font-semibold">
            <span className="w-2 h-2 rounded-full bg-rose-500 inline-block shadow-sm" />
            غير مسدد: {unpaidCount}
          </span>
        </div>
        <div className={`${themeConfig.subTextColor} hidden sm:block`}>
          إجمالي الوحدات: {totalTenants}
        </div>
      </div>
    </div>
  );
};
