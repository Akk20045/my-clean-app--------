import React, { useState } from 'react';
import { X, Building2, Check } from 'lucide-react';
import { Building, ThemeMode } from '../types';

interface AddBuildingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveBuilding: (building: Building) => void;
  theme: ThemeMode;
}

export const AddBuildingModal: React.FC<AddBuildingModalProps> = ({
  isOpen,
  onClose,
  onSaveBuilding,
  theme,
}) => {
  // Hooks MUST be called unconditionally at top of component
  const [name, setName] = useState<string>('');
  const [location, setLocation] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newBuilding: Building = {
      id: `b-${Date.now()}`,
      name: name.trim(),
      location: location.trim() || 'الموقع غير محدد',
      notes: notes.trim() || undefined,
    };

    onSaveBuilding(newBuilding);
    setName('');
    setLocation('');
    setNotes('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`relative w-full sm:max-w-md border-t sm:border sm:rounded-2xl rounded-t-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col transition-colors ${
          theme === 'dark'
            ? 'bg-[#151C28] border-neutral-700/80 text-white'
            : 'bg-white border-neutral-300 text-neutral-900'
        }`}
      >
        {/* Header */}
        <div
          className={`flex items-center justify-between px-6 py-4 border-b ${
            theme === 'dark' ? 'bg-[#121824] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-semibold text-amber-500">إدارة الأصول العقارية</span>
              <h3 className="text-base font-extrabold tracking-tight">إضافة عمارة أو مجمع جديد</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-700 dark:hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs overflow-y-auto flex-1">
          <div className="space-y-1.5">
            <label className="block font-bold text-neutral-700 dark:text-neutral-300">
              اسم العمارة أو المجمع العقاري <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              autoFocus
              placeholder="مثال: عمارة الياسمين، برج الأندلس، مجمع الوكالات"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className={`w-full py-2.5 px-3 rounded-xl border text-sm font-semibold outline-none transition-all ${
                theme === 'dark'
                  ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                  : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
              }`}
            />
          </div>

          <div className="space-y-1.5">
            <label className="block font-semibold text-neutral-600 dark:text-neutral-400">
              الموقع / العنوان (اختياري)
            </label>
            <input
              type="text"
              placeholder="مثال: عمان، الدوار الرابع - قرب السفارات"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className={`w-full py-2.5 px-3 rounded-xl border outline-none transition-all ${
                theme === 'dark'
                  ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                  : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
              }`}
            />
          </div>

          <div className="space-y-1.5">
            <label className="block font-semibold text-neutral-600 dark:text-neutral-400">
              ملاحظات أو مواصفات العمارة (اختياري)
            </label>
            <input
              type="text"
              placeholder="مثال: 8 شقق سكنية، مجهزة بمصعد ومواقف خاصة"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className={`w-full py-2.5 px-3 rounded-xl border outline-none transition-all ${
                theme === 'dark'
                  ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                  : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
              }`}
            />
          </div>

          <div
            className={`pt-3 flex items-center justify-end gap-3 border-t ${
              theme === 'dark' ? 'border-neutral-800' : 'border-neutral-200'
            }`}
          >
            <button
              type="button"
              onClick={onClose}
              className={`px-4 py-2.5 rounded-xl border font-semibold cursor-pointer ${
                theme === 'dark'
                  ? 'border-neutral-700 text-neutral-300 hover:bg-neutral-800'
                  : 'border-neutral-300 text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-bold shadow-lg transition-all active:scale-95 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>حفظ العمارة</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
