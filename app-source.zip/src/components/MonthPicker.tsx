import React, { useState } from 'react';
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  RotateCcw,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import { MONTH_NAMES_AR, formatMonthEn, formatMonthName, shiftMonthKey } from '../utils/formatters';
import { ThemeMode } from '../types';
import { isDarkTheme, getThemeConfig } from '../utils/theme';

interface MonthPickerProps {
  activeMonthKey: string;
  onMonthChange: (monthKey: string) => void;
  theme: ThemeMode;
}

export const MonthPicker: React.FC<MonthPickerProps> = ({
  activeMonthKey,
  onMonthChange,
  theme,
}) => {
  const isDark = isDarkTheme(theme);
  const themeConfig = getThemeConfig(theme);
  const [isPickerModalOpen, setIsPickerModalOpen] = useState<boolean>(false);

  const [yearStr, monthStr] = activeMonthKey.split('-');
  const currentYear = parseInt(yearStr, 10);
  const currentMonth = parseInt(monthStr, 10);

  const [selectedYearInModal, setSelectedYearInModal] = useState<number>(currentYear);

  const now = new Date();
  const realCurrentMonthKey = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}`;

  const handlePrevMonth = () => {
    onMonthChange(shiftMonthKey(activeMonthKey, -1));
  };

  const handleNextMonth = () => {
    onMonthChange(shiftMonthKey(activeMonthKey, 1));
  };

  const handlePrevYear = () => {
    onMonthChange(`${currentYear - 1}-${monthStr}`);
  };

  const handleNextYear = () => {
    onMonthChange(`${currentYear + 1}-${monthStr}`);
  };

  const handleSelectMonthYear = (m: number, y: number) => {
    const mm = m.toString().padStart(2, '0');
    onMonthChange(`${y}-${mm}`);
    setIsPickerModalOpen(false);
  };

  // Surrounding 5 months for quick bar
  const monthsBar = [-2, -1, 0, 1, 2].map((delta) => shiftMonthKey(activeMonthKey, delta));

  return (
    <>
      <div
        className={`sticky top-0 z-30 px-4 py-3 border-b transition-colors ${themeConfig.bgHeader} ${themeConfig.borderCard} ${themeConfig.textColor} backdrop-blur-md`}
      >
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Left: Active month & year display + quick selector button */}
          <div className="flex items-center justify-between w-full md:w-auto gap-3">
            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  setSelectedYearInModal(currentYear);
                  setIsPickerModalOpen(true);
                }}
                className={`p-2 rounded-xl border transition-all flex items-center gap-2 active:scale-95 ${
                  isDark
                    ? 'bg-amber-500/10 border-amber-500/30 text-amber-400 hover:bg-amber-500/20'
                    : 'bg-amber-50 border-amber-300 text-amber-700 hover:bg-amber-100'
                }`}
                title="اضغط لتحديد أي شهر وسنة مباشرة"
              >
                <Calendar className="w-5 h-5" />
                <span className="text-xs font-bold hidden sm:inline">اختر الشهر والسنة</span>
              </button>

              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-semibold text-neutral-400">
                    سجل إيجارات:
                  </span>
                  {activeMonthKey === realCurrentMonthKey && (
                    <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-emerald-500/15 text-emerald-500 border border-emerald-500/30">
                      الشهر الحالي
                    </span>
                  )}
                </div>
                <h2 className="text-lg md:text-xl font-black tracking-tight flex items-baseline gap-2">
                  <span>{formatMonthName(activeMonthKey)}</span>
                  <span className="text-xs text-neutral-400 font-normal">
                    ({formatMonthEn(activeMonthKey)})
                  </span>
                </h2>
              </div>
            </div>

            {/* Quick jump to current real month */}
            {activeMonthKey !== realCurrentMonthKey && (
              <button
                onClick={() => onMonthChange(realCurrentMonthKey)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl border transition-all active:scale-95 ${
                  isDark
                    ? 'bg-amber-500/10 text-amber-300 border-amber-500/30 hover:bg-amber-500/20'
                    : 'bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-200'
                }`}
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>الشهر الحالي</span>
              </button>
            )}
          </div>

          {/* Center / Month & Year Carousel Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2 w-full md:w-auto justify-center overflow-x-auto pb-1 md:pb-0">
            {/* Year backwards */}
            <button
              onClick={handlePrevYear}
              className={`p-2 rounded-xl border text-xs font-bold flex items-center gap-1 transition-colors active:scale-95 shrink-0 ${themeConfig.bgSubCard} ${themeConfig.borderCard}`}
              title="السنة السابقة"
            >
              <ChevronsRight className="w-4 h-4" />
              <span className="hidden sm:inline font-mono">{currentYear - 1}</span>
            </button>

            {/* Month backwards */}
            <button
              onClick={handlePrevMonth}
              className={`p-2 rounded-xl border text-xs font-bold transition-colors active:scale-95 shrink-0 ${themeConfig.bgSubCard} ${themeConfig.borderCard}`}
              title="الشهر السابق"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {/* Direct Carousel bar */}
            <div
              className={`flex items-center gap-1 p-1 rounded-2xl border ${themeConfig.bgSubCard} ${themeConfig.borderCard}`}
            >
              {monthsBar.map((mKey) => {
                const isSelected = mKey === activeMonthKey;
                return (
                  <button
                    key={mKey}
                    onClick={() => onMonthChange(mKey)}
                    className={`px-3 sm:px-4 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap transition-all ${
                      isSelected
                        ? isDark
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm font-bold'
                          : 'bg-white text-amber-800 border border-amber-400 shadow-sm font-bold'
                        : isDark
                        ? 'text-neutral-400 hover:text-neutral-200 hover:bg-[#18202F]'
                        : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-200'
                    }`}
                  >
                    {formatMonthName(mKey)}
                  </button>
                );
              })}
            </div>

            {/* Month forward */}
            <button
              onClick={handleNextMonth}
              className={`p-2 rounded-xl border text-xs font-bold transition-colors active:scale-95 shrink-0 ${
                isDark
                  ? 'bg-[#151C28] border-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-800'
                  : 'bg-neutral-100 border-neutral-200 text-neutral-700 hover:bg-neutral-200'
              }`}
              title="الشهر التالي"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            {/* Year forward */}
            <button
              onClick={handleNextYear}
              className={`p-2 rounded-xl border text-xs font-bold flex items-center gap-1 transition-colors active:scale-95 shrink-0 ${
                isDark
                  ? 'bg-[#151C28] border-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-800'
                  : 'bg-neutral-100 border-neutral-200 text-neutral-700 hover:bg-neutral-200'
              }`}
              title="السنة التالية"
            >
              <span className="hidden sm:inline font-mono">{currentYear + 1}</span>
              <ChevronsLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Month & Year Selection Modal Picker */}
      {isPickerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div
            className={`w-full max-w-md rounded-2xl border shadow-2xl p-6 space-y-5 ${
              isDark
                ? 'bg-[#151C28] border-neutral-700 text-white'
                : 'bg-white border-neutral-200 text-neutral-900'
            }`}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b pb-3 border-neutral-700/50">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-amber-500" />
                <h3 className="text-base font-bold">اختيار الشهر والسنة</h3>
              </div>
              <button
                onClick={() => setIsPickerModalOpen(false)}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Year Selector */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-neutral-400 block">السنة المستهدفة</label>
              <div className="flex items-center justify-between gap-2 p-1.5 rounded-xl border border-neutral-700/60 bg-black/10">
                <button
                  type="button"
                  onClick={() => setSelectedYearInModal((y) => y - 1)}
                  className="p-2 rounded-lg hover:bg-neutral-700/40 text-neutral-300"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
                <span className="font-mono text-xl font-bold tracking-wider">{selectedYearInModal}</span>
                <button
                  type="button"
                  onClick={() => setSelectedYearInModal((y) => y + 1)}
                  className="p-2 rounded-lg hover:bg-neutral-700/40 text-neutral-300"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* 12 Months Grid */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-neutral-400 block">الشهر</label>
              <div className="grid grid-cols-3 gap-2">
                {Object.entries(MONTH_NAMES_AR).map(([mNum, item]) => {
                  const monthIndex = parseInt(mNum, 10);
                  const isCurrentTarget =
                    currentYear === selectedYearInModal && currentMonth === monthIndex;

                  return (
                    <button
                      key={mNum}
                      type="button"
                      onClick={() => handleSelectMonthYear(monthIndex, selectedYearInModal)}
                      className={`p-3 rounded-xl border text-xs font-bold transition-all text-center ${
                        isCurrentTarget
                          ? 'bg-amber-500 text-neutral-950 border-amber-400 font-extrabold shadow-md'
                          : isDark
                          ? 'bg-[#0F1520] border-neutral-800 text-neutral-300 hover:bg-amber-500/10 hover:text-amber-300 hover:border-amber-500/30'
                          : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-amber-50 hover:text-amber-800 hover:border-amber-400'
                      }`}
                    >
                      <div>{item.levantine}</div>
                      <div className="text-[10px] font-normal opacity-70 mt-0.5">{item.standard}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Footer */}
            <div className="pt-2 flex items-center justify-between border-t border-neutral-700/50 text-xs">
              <button
                type="button"
                onClick={() => {
                  onMonthChange(realCurrentMonthKey);
                  setIsPickerModalOpen(false);
                }}
                className="text-amber-500 hover:underline font-semibold"
              >
                العودة للشهر الحالي تلقائياً
              </button>
              <button
                type="button"
                onClick={() => setIsPickerModalOpen(false)}
                className="px-4 py-1.5 rounded-xl border border-neutral-600 font-semibold"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
