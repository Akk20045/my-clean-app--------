import React from 'react';
import { X, Printer, Share2, CheckCircle2, ShieldCheck, Building2 } from 'lucide-react';
import { PaymentRecord, TenantFinancialSnapshot, ThemeMode } from '../types';
import {
  formatCurrency,
  formatMonthName,
  getPaymentMethodNameAr,
  sanitizePhoneForWhatsApp,
  getUnitDisplayTag,
  getUnitTypeLabel,
} from '../utils/formatters';

interface ReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  payment: PaymentRecord | null;
  snapshot: TenantFinancialSnapshot | null;
  currency: string;
  theme: ThemeMode;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  isOpen,
  onClose,
  payment,
  snapshot,
  currency,
  theme,
}) => {
  if (!isOpen || !payment || !snapshot) return null;

  const { tenant, buildingName, monthlyRent } = snapshot;
  const monthName = formatMonthName(payment.monthKey);
  const remainingAfter = snapshot.balanceRemaining;

  const handlePrint = () => {
    window.print();
  };

  const handleWhatsAppShare = () => {
    const cleanPhone = sanitizePhoneForWhatsApp(tenant.phone);
    const text = `*سند قبض إيجار رسمي — سند رقم: ${payment.receiptNumber}*
العقار: ${buildingName} — ${tenant.unitNumber}
المستأجر: ${tenant.name}
عن شهر: ${monthName}
المبلغ المستلم: ${formatCurrency(payment.amount, currency)}
طريقة السداد: ${getPaymentMethodNameAr(payment.method)}
تاريخ الاستلام: ${payment.date}
${payment.referenceNumber ? `الرقم المرجعي: ${payment.referenceNumber}\n` : ''}الرصيد المتبقي للشهر: ${formatCurrency(remainingAfter, currency)}
حالة السداد: ${remainingAfter === 0 ? 'مسدد بالكامل بنجاح' : 'دفعة جزئية'}

شاكرين لكم حسن التعاون والالتزام.`;

    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-xl border rounded-3xl shadow-2xl overflow-hidden max-h-[95vh] flex flex-col transition-colors ${
          theme === 'dark'
            ? 'bg-[#151C28] border-neutral-700/80 text-white'
            : 'bg-white border-neutral-300 text-neutral-900'
        }`}
      >
        {/* Header Controls (no-print) */}
        <div
          className={`no-print flex items-center justify-between px-6 py-4 border-b ${
            theme === 'dark' ? 'border-neutral-800 bg-[#121824]' : 'border-neutral-200 bg-neutral-50'
          }`}
        >
          <div className="flex items-center gap-2 text-emerald-500 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4" />
            <span>سند قبض إلكتروني موثق</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-colors ${
                theme === 'dark'
                  ? 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border-neutral-700'
                  : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-800 border-neutral-300'
              }`}
              title="طباعة السند"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة</span>
            </button>

            <button
              onClick={handleWhatsAppShare}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-500 text-xs font-bold border border-emerald-500/30 transition-colors"
              title="إرسال السند عبر واتساب"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>إرسال واتساب</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-neutral-400 hover:text-neutral-700 dark:hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Paper Container */}
        <div className="p-6 md:p-8 overflow-y-auto space-y-6">
          <div
            className={`relative p-6 sm:p-8 rounded-2xl border-2 shadow-inner ${
              theme === 'dark'
                ? 'bg-[#0F1520] border-amber-500/30 text-white'
                : 'bg-neutral-50/70 border-amber-400 text-neutral-900'
            }`}
          >
            {/* Top Emblem */}
            <div
              className={`flex items-start justify-between border-b pb-5 ${
                theme === 'dark' ? 'border-neutral-800' : 'border-neutral-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-700/10 border border-amber-500/40 flex items-center justify-center text-amber-500 shadow-md">
                  <Building2 className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-xl font-extrabold tracking-tight">إيصال قبض إيجار</h4>
                  <p className="text-xs text-neutral-400 tracking-wider">RENT PAYMENT RECEIPT</p>
                </div>
              </div>

              <div className="text-left font-mono tabular-nums">
                <div className="text-xs text-neutral-400">رقم الإيصال:</div>
                <div className="text-sm font-bold text-amber-500 tracking-wider">
                  {payment.receiptNumber}
                </div>
                <div className="text-[11px] text-neutral-400 mt-0.5">{payment.date}</div>
              </div>
            </div>

            {/* Core Fields */}
            <div className="py-5 space-y-4 text-sm">
              <div
                className={`grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-xl border ${
                  theme === 'dark'
                    ? 'bg-[#141C2A] border-neutral-800'
                    : 'bg-white border-neutral-200 shadow-xs'
                }`}
              >
                <div>
                  <span className="text-xs text-neutral-400 block mb-0.5">استُلم من السيد / السادة:</span>
                  <span className="font-bold text-base">{tenant.name}</span>
                </div>
                <div>
                  <span className="text-xs text-neutral-400 block mb-0.5">عن العقار / الوحدة:</span>
                  <span className="font-semibold">
                    {buildingName} — {getUnitDisplayTag(tenant.unitNumber, tenant.unitType, tenant.customUnitType)}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div
                  className={`p-3 rounded-xl border ${
                    theme === 'dark' ? 'bg-[#121824] border-neutral-800' : 'bg-white border-neutral-200'
                  }`}
                >
                  <span className="text-xs text-neutral-400 block">شهر الاستحقاق</span>
                  <span className="font-bold text-amber-500 text-sm">{monthName}</span>
                </div>

                <div
                  className={`p-3 rounded-xl border ${
                    theme === 'dark' ? 'bg-[#121824] border-neutral-800' : 'bg-white border-neutral-200'
                  }`}
                >
                  <span className="text-xs text-neutral-400 block">طريقة السداد</span>
                  <span className="font-semibold text-sm">
                    {getPaymentMethodNameAr(payment.method)}
                  </span>
                </div>

                <div
                  className={`p-3 rounded-xl border col-span-2 sm:col-span-1 ${
                    theme === 'dark' ? 'bg-[#121824] border-neutral-800' : 'bg-white border-neutral-200'
                  }`}
                >
                  <span className="text-xs text-neutral-400 block">المرجع / الشيك</span>
                  <span className="font-mono text-xs">
                    {payment.referenceNumber || '—'}
                  </span>
                </div>
              </div>

              {/* Amount Highlight */}
              <div
                className={`p-4 rounded-xl border flex items-center justify-between ${
                  theme === 'dark'
                    ? 'bg-gradient-to-r from-emerald-950/40 via-[#15232F] to-[#121824] border-emerald-500/30'
                    : 'bg-emerald-50 border-emerald-300'
                }`}
              >
                <div>
                  <span className="text-xs text-emerald-600 dark:text-emerald-400 block font-bold">
                    المبلغ المستلم نقداً / قيداً
                  </span>
                  <span className="text-2xl sm:text-3xl font-extrabold text-emerald-600 dark:text-emerald-300 font-mono tabular-nums">
                    {formatCurrency(payment.amount, currency)}
                  </span>
                </div>
                <div className="text-left">
                  <span className="text-xs text-neutral-400 block">إجمالي إيجار الشهر</span>
                  <span className="text-sm font-bold font-mono tabular-nums">
                    {formatCurrency(monthlyRent, currency)}
                  </span>
                </div>
              </div>

              {payment.notes && (
                <div
                  className={`text-xs p-3 rounded-lg border ${
                    theme === 'dark'
                      ? 'bg-neutral-900/50 border-neutral-800 text-neutral-400'
                      : 'bg-neutral-100 border-neutral-200 text-neutral-700'
                  }`}
                >
                  <strong className="font-bold">ملاحظات:</strong> {payment.notes}
                </div>
              )}
            </div>

            {/* Official Stamp & Signoff */}
            <div
              className={`border-t pt-5 flex items-end justify-between text-xs text-neutral-400 ${
                theme === 'dark' ? 'border-neutral-800' : 'border-neutral-200'
              }`}
            >
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-amber-500" />
                <span>سند إلكتروني معتمد وموثق بالنظام</span>
              </div>
              <div className="text-left space-y-1">
                <div className="text-neutral-400">توقيع المستلم / المالك</div>
                <div className="font-serif italic text-amber-600 dark:text-amber-300 text-sm font-bold tracking-wider">
                  الإدارة العقارية
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div
          className={`no-print p-4 border-t flex items-center justify-end ${
            theme === 'dark' ? 'border-neutral-800 bg-[#121824]' : 'border-neutral-200 bg-neutral-50'
          }`}
        >
          <button
            onClick={onClose}
            className={`px-6 py-2 rounded-xl text-xs font-bold border transition-colors ${
              theme === 'dark'
                ? 'bg-neutral-800 hover:bg-neutral-700 text-white border-neutral-700'
                : 'bg-neutral-200 hover:bg-neutral-300 text-neutral-900 border-neutral-300'
            }`}
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
