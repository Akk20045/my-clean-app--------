import React from 'react';
import { Search, Filter, X } from 'lucide-react';
import { Building, FilterStatus, FilterUnitType, ThemeMode } from '../types';
import { isDarkTheme, getThemeConfig } from '../utils/theme';

interface FilterBarProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  statusFilter: FilterStatus;
  onStatusFilterChange: (status: FilterStatus) => void;
  unitTypeFilter: FilterUnitType;
  onUnitTypeFilterChange: (type: FilterUnitType) => void;
  selectedBuildingId: string;
  onBuildingSelect: (bId: string) => void;
  buildings: Building[];
  totalFilteredCount: number;
  theme: ThemeMode;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  searchQuery,
  onSearchChange,
  statusFilter,
  onStatusFilterChange,
  unitTypeFilter,
  onUnitTypeFilterChange,
  selectedBuildingId,
  onBuildingSelect,
  buildings,
  totalFilteredCount,
  theme,
}) => {
  const isDark = isDarkTheme(theme);
  const themeConfig = getThemeConfig(theme);

  const hasActiveFilters =
    searchQuery !== '' ||
    statusFilter !== 'all' ||
    unitTypeFilter !== 'all' ||
    selectedBuildingId !== 'all';

  const clearAllFilters = () => {
    onSearchChange('');
    onStatusFilterChange('all');
    onUnitTypeFilterChange('all');
    onBuildingSelect('all');
  };

  if (buildings.length === 0) {
    return null;
  }

  return (
    <div
      className={`p-4 rounded-2xl border space-y-3 shadow-md transition-colors ${themeConfig.bgCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
    >
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 pointer-events-none" />
          <input
            type="text"
            placeholder="بحث بالاسم، رقم الشقة أو المحل، أو اسم العمارة..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className={`w-full pr-10 pl-4 py-2.5 rounded-xl border text-xs placeholder:text-neutral-400 outline-none transition-all ${themeConfig.bgSubCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Building Filter Dropdown */}
        <div className="w-full md:w-60">
          <select
            value={selectedBuildingId}
            onChange={(e) => onBuildingSelect(e.target.value)}
            className={`w-full py-2.5 px-3 rounded-xl border text-xs outline-none transition-colors ${themeConfig.bgSubCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
          >
            <option value="all">جميع المباني والمجمعات ({buildings.length})</option>
            {buildings.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Filter Tabs */}
      <div
        className={`flex flex-wrap items-center justify-between gap-3 pt-2 border-t text-xs ${
          isDark ? 'border-neutral-800' : 'border-neutral-100'
        }`}
      >
        {/* Status Filters */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-neutral-400 font-semibold ml-1 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" />
            <span>الحالة:</span>
          </span>

          <button
            onClick={() => onStatusFilterChange('all')}
            className={`px-3 py-1 rounded-lg font-semibold transition-all ${
              statusFilter === 'all'
                ? isDark
                  ? 'bg-neutral-200 text-neutral-900 font-bold'
                  : 'bg-neutral-900 text-white font-bold'
                : isDark
                ? 'bg-[#0F1520] text-neutral-400 hover:text-white'
                : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
            }`}
          >
            الكل
          </button>

          <button
            onClick={() => onStatusFilterChange('paid')}
            className={`px-3 py-1 rounded-lg font-semibold transition-all flex items-center gap-1.5 ${
              statusFilter === 'paid'
                ? 'bg-emerald-500 text-neutral-950 font-bold'
                : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            <span>مسدد بالكامل</span>
          </button>

          <button
            onClick={() => onStatusFilterChange('partial')}
            className={`px-3 py-1 rounded-lg font-semibold transition-all flex items-center gap-1.5 ${
              statusFilter === 'partial'
                ? 'bg-amber-500 text-neutral-950 font-bold'
                : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            <span>دفعة جزئية</span>
          </button>

          <button
            onClick={() => onStatusFilterChange('unpaid')}
            className={`px-3 py-1 rounded-lg font-semibold transition-all flex items-center gap-1.5 ${
              statusFilter === 'unpaid'
                ? 'bg-rose-500 text-neutral-950 font-bold'
                : 'bg-rose-500/10 text-rose-600 dark:text-rose-400'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
            <span>غير مسدد</span>
          </button>
        </div>

        {/* Unit Type Filters */}
        <div className="flex items-center gap-2">
          <div
            className={`flex items-center gap-1 p-1 rounded-xl border ${
              isDark ? 'bg-[#0F1520] border-neutral-800' : 'bg-neutral-100 border-neutral-200'
            }`}
          >
            <button
              onClick={() => onUnitTypeFilterChange('all')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                unitTypeFilter === 'all'
                  ? 'bg-amber-500/20 text-amber-600 dark:text-amber-300 font-bold'
                  : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-white'
              }`}
            >
              الجميع
            </button>
            <button
              onClick={() => onUnitTypeFilterChange('residential')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                unitTypeFilter === 'residential'
                  ? 'bg-amber-500/20 text-amber-600 dark:text-amber-300 font-bold'
                  : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-white'
              }`}
            >
              سكني
            </button>
            <button
              onClick={() => onUnitTypeFilterChange('commercial')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                unitTypeFilter === 'commercial'
                  ? 'bg-sky-500/20 text-sky-600 dark:text-sky-300 font-bold'
                  : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-white'
              }`}
            >
              تجاري ومكاتب
            </button>
          </div>

          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              className="text-[11px] text-amber-600 dark:text-amber-400 hover:underline underline-offset-4 mr-2"
            >
              مسح التصفية ({totalFilteredCount} نتيجة)
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
