import React from 'react';
import { X, Printer, Download, FileSpreadsheet, FileText, Building2, CheckCircle2 } from 'lucide-react';
import { TenantFinancialSnapshot, ThemeMode } from '../types';
import { formatCurrency, formatMonthName, getUnitDisplayTag } from '../utils/formatters';
import { exportToExcel, exportToWord } from '../utils/exportUtils';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  snapshots: TenantFinancialSnapshot[];
  monthKey: string;
  currency: string;
  selectedBuildingName?: string;
  theme: ThemeMode;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  onClose,
  snapshots,
  monthKey,
  currency,
  selectedBuildingName,
  theme,
}) => {
  if (!isOpen) return null;

  const monthName = formatMonthName(monthKey);
  const totalRent = snapshots.reduce((acc, s) => acc + s.monthlyRent, 0);
  const totalPaid = snapshots.reduce((acc, s) => acc + s.totalPaid, 0);
  const totalRemaining = snapshots.reduce((acc, s) => acc + s.balanceRemaining, 0);
  const totalDeposits = snapshots.reduce((acc, s) => acc + (s.tenant.securityDeposit || 0), 0);
  const rate = totalRent > 0 ? Math.round((totalPaid / totalRent) * 100) : 0;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-4xl border rounded-2xl shadow-2xl overflow-hidden max-h-[95vh] flex flex-col transition-colors ${
          theme === 'dark'
            ? 'bg-[#151C28] border-neutral-700/80 text-white'
            : 'bg-white border-neutral-300 text-neutral-900'
        }`}
      >
        {/* Top Modal Controls (Hidden on Print) */}
        <div
          className={`print:hidden flex flex-wrap items-center justify-between px-6 py-4 border-b ${
            theme === 'dark' ? 'bg-[#121824] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500 border border-amber-500/20">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-semibold text-amber-500">مركز التقارير والتصدير</span>
              <h3 className="text-base font-extrabold tracking-tight">
                كشف حساب إيجارات — {monthName}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => exportToExcel(snapshots, monthKey, currency, selectedBuildingName)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-xs"
              title="تصدير كملف إكسل"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>إكسل (.xls)</span>
            </button>

            <button
              onClick={() => exportToWord(snapshots, monthKey, currency, selectedBuildingName)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-all shadow-xs"
              title="تصدير كملف وورد"
            >
              <FileText className="w-4 h-4" />
              <span>وورد (.doc)</span>
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 text-xs font-bold transition-all shadow-md"
              title="طباعة أو حفظ كملف PDF"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة / حفظ PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-neutral-400 hover:text-neutral-700 dark:hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Paper Document Sheet */}
        <div className="p-6 sm:p-8 overflow-y-auto bg-white text-neutral-900 printable-document">
          {/* Document Header */}
          <div className="border-b-2 border-neutral-900 pb-5 mb-6 flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h1 className="text-xl font-extrabold tracking-tight text-neutral-900">
                  كشف حساب تحصيل الإيجارات الشهري
                </h1>
              </div>
              <p className="text-xs text-neutral-600 font-medium">
                منصة تحصيل — نظام إدارة ومتابعة الإيجارات والعقارات
              </p>
            </div>

            <div className="text-left text-xs text-neutral-600 space-y-1">
              <div>
                <strong>شهر الاستحقاق:</strong>{' '}
                <span className="text-amber-700 font-bold">{monthName}</span>
              </div>
              <div>
                <strong>تاريخ الإصدار:</strong>{' '}
                {new Date().toLocaleDateString('ar-JO')}
              </div>
              {selectedBuildingName && (
                <div>
                  <strong>العمارة المحددة:</strong>{' '}
                  <span className="font-semibold">{selectedBuildingName}</span>
                </div>
              )}
            </div>
          </div>

          {/* Financial Summary KPIs */}
          <div className="grid grid-cols-4 gap-3 mb-6">
            <div className="p-3.5 rounded-xl border border-neutral-200 bg-neutral-50 text-center">
              <span className="block text-[11px] text-neutral-500 font-medium">الإيجار المطلوب</span>
              <span className="text-base font-extrabold font-mono tabular-nums text-neutral-900">
                {formatCurrency(totalRent, currency)}
              </span>
            </div>

            <div className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50 text-center">
              <span className="block text-[11px] text-emerald-700 font-medium">المحصل ({rate}%)</span>
              <span className="text-base font-extrabold font-mono tabular-nums text-emerald-700">
                {formatCurrency(totalPaid, currency)}
              </span>
            </div>

            <div className="p-3.5 rounded-xl border border-rose-200 bg-rose-50 text-center">
              <span className="block text-[11px] text-rose-700 font-medium">المتبقي المطلوب</span>
              <span className="text-base font-extrabold font-mono tabular-nums text-rose-700">
                {formatCurrency(totalRemaining, currency)}
              </span>
            </div>

            <div className="p-3.5 rounded-xl border border-sky-200 bg-sky-50 text-center">
              <span className="block text-[11px] text-sky-700 font-medium">الضمانات المحتجزة</span>
              <span className="text-base font-extrabold font-mono tabular-nums text-sky-700">
                {formatCurrency(totalDeposits, currency)}
              </span>
            </div>
          </div>

          {/* Detailed Table */}
          <div className="overflow-x-auto border border-neutral-300 rounded-xl mb-6">
            <table className="w-full text-right border-collapse text-xs">
              <thead>
                <tr className="bg-neutral-900 text-white border-b border-neutral-800">
                  <th className="py-2.5 px-3">العمارة</th>
                  <th className="py-2.5 px-3">الوحدة</th>
                  <th className="py-2.5 px-3">المستأجر</th>
                  <th className="py-2.5 px-3">الهاتف</th>
                  <th className="py-2.5 px-3 text-left">الإيجار ({currency})</th>
                  <th className="py-2.5 px-3 text-left">المدفوع ({currency})</th>
                  <th className="py-2.5 px-3 text-left">المتبقي ({currency})</th>
                  <th className="py-2.5 px-3 text-center">حالة السداد</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {snapshots.map((s, idx) => (
                  <tr key={s.tenant.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-neutral-50'}>
                    <td className="py-2 px-3 font-semibold">{s.buildingName}</td>
                    <td className="py-2 px-3 font-bold">
                      {getUnitDisplayTag(s.tenant.unitNumber, s.tenant.unitType, s.tenant.customUnitType)}
                    </td>
                    <td className="py-2 px-3">{s.tenant.name}</td>
                    <td className="py-2 px-3 font-mono text-left" dir="ltr">{s.tenant.phone}</td>
                    <td className="py-2 px-3 text-left font-mono font-bold">
                      {formatCurrency(s.monthlyRent, currency)}
                    </td>
                    <td className="py-2 px-3 text-left font-mono font-bold text-emerald-700">
                      {formatCurrency(s.totalPaid, currency)}
                    </td>
                    <td className="py-2 px-3 text-left font-mono font-bold">
                      <span className={s.balanceRemaining > 0 ? 'text-rose-700 font-extrabold' : 'text-neutral-400'}>
                        {formatCurrency(s.balanceRemaining, currency)}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                          s.status === 'paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : s.status === 'partial'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {s.status === 'paid'
                          ? 'مسدد'
                          : s.status === 'partial'
                          ? 'دفعة جزئية'
                          : 'غير مسدد'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-amber-50 font-bold border-t-2 border-amber-300 text-amber-950">
                  <td className="py-2.5 px-3" colSpan={4}>
                    المجموع العام ({snapshots.length} عقارات) — نسبة التحصيل: {rate}%
                  </td>
                  <td className="py-2.5 px-3 text-left font-mono font-extrabold">
                    {formatCurrency(totalRent, currency)}
                  </td>
                  <td className="py-2.5 px-3 text-left font-mono font-extrabold text-emerald-700">
                    {formatCurrency(totalPaid, currency)}
                  </td>
                  <td className="py-2.5 px-3 text-left font-mono font-extrabold text-rose-700">
                    {formatCurrency(totalRemaining, currency)}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    {totalRemaining === 0 ? 'مكتمل 100%' : 'قيد المتابعة'}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Signatures and Verification */}
          <div className="mt-10 pt-6 border-t border-neutral-300 grid grid-cols-2 gap-8 text-xs">
            <div>
              <p className="font-bold text-neutral-800 mb-6">اعتماد وتوقيع المالك / المؤجر:</p>
              <div className="border-b border-dashed border-neutral-400 w-48 mb-2"></div>
              <span className="text-neutral-500">التاريخ: ..... / ..... / {new Date().getFullYear()}</span>
            </div>

            <div className="text-left">
              <p className="font-bold text-neutral-800 mb-6">الختم أو الملاحظات:</p>
              <div className="border border-neutral-300 rounded-lg p-3 h-16 text-neutral-400">
                ملاحظات التدقيق المالي
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
