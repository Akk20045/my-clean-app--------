import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Send,
  Inbox,
  CheckCircle2,
  Trash2,
  X,
  AlertCircle,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import { Building, PaymentRecord, Tenant, ThemeMode } from '../types';
import {
  sendPortfolioUpdateToAccount,
  subscribeToIncomingUpdates,
  markSharedUpdateApplied,
  deleteSharedUpdate,
  SharedUpdatePackage,
} from '../firebase/firestoreService';

interface SharePortfolioModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: ThemeMode;
  buildings: Building[];
  tenants: Tenant[];
  payments: PaymentRecord[];
  onApplyUpdate: (incomingData: {
    buildings: Building[];
    tenants: Tenant[];
    payments: PaymentRecord[];
  }) => void;
}

export const SharePortfolioModal: React.FC<SharePortfolioModalProps> = ({
  isOpen,
  onClose,
  theme,
  buildings,
  tenants,
  payments,
  onApplyUpdate,
}) => {
  const { user, signIn } = useAuth();
  const [activeTab, setActiveTab] = useState<'send' | 'inbox'>('send');

  // Send state
  const [recipientEmail, setRecipientEmail] = useState('');
  const [updateNote, setUpdateNote] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sendSuccessMsg, setSendSuccessMsg] = useState<string | null>(null);
  const [sendErrorMsg, setSendErrorMsg] = useState<string | null>(null);

  // Saved partners
  const [recentPartners, setRecentPartners] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem('aurarent_recent_partners');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  // Incoming updates state
  const [incomingUpdates, setIncomingUpdates] = useState<SharedUpdatePackage[]>([]);
  const [applyingId, setApplyingId] = useState<string | null>(null);
  const [applySuccessMsg, setApplySuccessMsg] = useState<string | null>(null);

  // Subscribe to incoming updates for this user
  useEffect(() => {
    if (!isOpen || !user || !user.email) return;

    const unsub = subscribeToIncomingUpdates(user.email, (updates) => {
      setIncomingUpdates(updates);
    });

    return () => unsub();
  }, [isOpen, user?.email]);

  if (!isOpen) return null;

  const handleSend = async (targetEmail: string, noteText: string) => {
    setSendErrorMsg(null);
    setSendSuccessMsg(null);

    if (!user) {
      await signIn();
      return;
    }

    const cleanEmail = targetEmail.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      setSendErrorMsg('يرجى إدخال بريد Google صحيح');
      return;
    }

    if (cleanEmail === user.email?.toLowerCase()) {
      setSendErrorMsg('لا يمكنك إرسال التحديث لنفس حسابك');
      return;
    }

    try {
      setIsSending(true);
      await sendPortfolioUpdateToAccount(
        user.uid,
        user.email || '',
        cleanEmail,
        noteText,
        buildings,
        tenants,
        payments
      );

      // Save to recent partners
      const updatedPartners = Array.from(new Set([cleanEmail, ...recentPartners])).slice(0, 10);
      setRecentPartners(updatedPartners);
      try {
        localStorage.setItem('aurarent_recent_partners', JSON.stringify(updatedPartners));
      } catch (e) {
        console.warn('Storage partner save warning', e);
      }

      setSendSuccessMsg(`تم إرسال آخر التحديثات بنجاح إلى: ${cleanEmail}`);
      setRecipientEmail('');
      setUpdateNote('');
    } catch (err: any) {
      setSendErrorMsg(err?.message || 'حدث خطأ أثناء إرسال التحديث');
    } finally {
      setIsSending(false);
    }
  };

  const handleApply = async (update: SharedUpdatePackage) => {
    try {
      setApplyingId(update.id);
      onApplyUpdate({
        buildings: update.payload.buildings,
        tenants: update.payload.tenants,
        payments: update.payload.payments,
      });

      await markSharedUpdateApplied(update.id);
      setApplySuccessMsg(
        `تم تطبيق واستيراد التحديث بنجاح! بياناتك الآن مستقلة بالكامل ويمكنك تعديلها بحرية دون التأثير على حساب المرسل.`
      );
      setTimeout(() => setApplySuccessMsg(null), 8000);
    } catch (err: any) {
      console.error('Error applying update:', err);
    } finally {
      setApplyingId(null);
    }
  };

  const handleDeleteUpdate = async (updateId: string) => {
    try {
      await deleteSharedUpdate(updateId);
      setIncomingUpdates((prev) => prev.filter((u) => u.id !== updateId));
    } catch (err) {
      console.error('Error deleting update:', err);
    }
  };

  const removePartnerFromRecent = (email: string) => {
    const updated = recentPartners.filter((e) => e !== email);
    setRecentPartners(updated);
    localStorage.setItem('aurarent_recent_partners', JSON.stringify(updated));
  };

  const pendingCount = incomingUpdates.filter((u) => u.status === 'pending').length;

  const isDark = theme === 'dark';

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`w-full max-w-2xl max-h-[90vh] sm:max-h-[85vh] rounded-3xl border shadow-2xl p-4 sm:p-6 relative flex flex-col transition-all overflow-hidden ${
          isDark
            ? 'bg-[#0f1218] border-neutral-700 text-neutral-100'
            : 'bg-white border-neutral-300 text-neutral-900'
        }`}
        dir="rtl"
      >
        {/* Header - Fixed to top */}
        <div className={`flex items-center justify-between pb-3 border-b mb-4 shrink-0 ${
          isDark ? 'border-neutral-700/60' : 'border-neutral-200'
        }`}>
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-2xl ${
              isDark ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30' : 'bg-amber-100 text-amber-700 border border-amber-300'
            }`}>
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h2 className={`text-base sm:text-lg font-black tracking-tight ${
                isDark ? 'text-white' : 'text-neutral-900'
              }`}>
                مشاركة التحديثات بين الحسابات
              </h2>
              <p className={`text-xs ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                شارك بياناتك وقتما تريد، مع استقلالية تامة في التعديل لكل حساب
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`p-2 rounded-xl transition-colors cursor-pointer ${
              isDark
                ? 'text-neutral-400 hover:text-white hover:bg-neutral-800'
                : 'text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation - Fixed top */}
        <div className={`flex items-center gap-2 mb-4 border-b pb-3 shrink-0 ${
          isDark ? 'border-neutral-700/60' : 'border-neutral-200'
        }`}>
          <button
            onClick={() => setActiveTab('send')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'send'
                ? 'bg-amber-500 text-neutral-950 shadow-sm font-black'
                : isDark
                ? 'bg-neutral-800/80 text-neutral-300 hover:bg-neutral-800'
                : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>مشاركة آخر التحديثات (إرسال)</span>
          </button>

          <button
            onClick={() => setActiveTab('inbox')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer relative ${
              activeTab === 'inbox'
                ? 'bg-amber-500 text-neutral-950 shadow-sm font-black'
                : isDark
                ? 'bg-neutral-800/80 text-neutral-300 hover:bg-neutral-800'
                : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
            }`}
          >
            <Inbox className="w-3.5 h-3.5" />
            <span>التحديثات الواردة لحسابي</span>
            {pendingCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-black mr-1">
                {pendingCount} جديد
              </span>
            )}
          </button>
        </div>

        {/* Scrollable Body Container for all tab content */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1 pl-1">
          {/* Feedback messages */}
          {sendSuccessMsg && (
            <div className={`p-3 rounded-2xl text-xs flex items-center gap-2 ${
              isDark
                ? 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-300'
                : 'bg-emerald-50 border border-emerald-300 text-emerald-900 font-bold'
            }`}>
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500" />
              <span>{sendSuccessMsg}</span>
            </div>
          )}

          {sendErrorMsg && (
            <div className={`p-3 rounded-2xl text-xs flex items-center gap-2 ${
              isDark
                ? 'bg-rose-500/15 border border-rose-500/30 text-rose-300'
                : 'bg-rose-50 border border-rose-300 text-rose-900 font-bold'
            }`}>
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{sendErrorMsg}</span>
            </div>
          )}

          {applySuccessMsg && (
            <div className={`p-3.5 rounded-2xl text-xs flex items-start gap-2.5 ${
              isDark
                ? 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-300'
                : 'bg-emerald-50 border border-emerald-300 text-emerald-900 font-bold'
            }`}>
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500 mt-0.5" />
              <span className="leading-relaxed">{applySuccessMsg}</span>
            </div>
          )}

          {/* TAB 1: SEND LATEST UPDATES */}
          {activeTab === 'send' && (
            <div className="space-y-4">
              {/* Current Snapshot Box */}
              <div
                className={`p-3.5 rounded-2xl border ${
                  isDark
                    ? 'bg-[#151C28] border-neutral-700/60'
                    : 'bg-amber-50/60 border-amber-200'
                }`}
              >
                <div className="flex items-center justify-between text-xs font-bold mb-2.5">
                  <span className={isDark ? 'text-neutral-200' : 'text-neutral-800 font-extrabold'}>
                    البيانات الجاهزة للإرسال حالياً:
                  </span>
                  <span className={`${isDark ? 'text-amber-400' : 'text-amber-700'} font-bold text-[11px]`}>
                    نسختك الحالية الكاملة
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className={`p-2.5 rounded-xl border ${
                    isDark
                      ? 'bg-neutral-900/60 border-neutral-700/50'
                      : 'bg-white border-neutral-200 shadow-xs'
                  }`}>
                    <span className={`block text-lg font-black ${isDark ? 'text-amber-400' : 'text-amber-600'}`}>
                      {buildings.length}
                    </span>
                    <span className={`text-[11px] font-bold ${isDark ? 'text-neutral-400' : 'text-neutral-700'}`}>
                      عمارة ومجمع
                    </span>
                  </div>
                  <div className={`p-2.5 rounded-xl border ${
                    isDark
                      ? 'bg-neutral-900/60 border-neutral-700/50'
                      : 'bg-white border-neutral-200 shadow-xs'
                  }`}>
                    <span className={`block text-lg font-black ${isDark ? 'text-amber-400' : 'text-amber-600'}`}>
                      {tenants.length}
                    </span>
                    <span className={`text-[11px] font-bold ${isDark ? 'text-neutral-400' : 'text-neutral-700'}`}>
                      شقة ومستأجر
                    </span>
                  </div>
                  <div className={`p-2.5 rounded-xl border ${
                    isDark
                      ? 'bg-neutral-900/60 border-neutral-700/50'
                      : 'bg-white border-neutral-200 shadow-xs'
                  }`}>
                    <span className={`block text-lg font-black ${isDark ? 'text-amber-400' : 'text-amber-600'}`}>
                      {payments.length}
                    </span>
                    <span className={`text-[11px] font-bold ${isDark ? 'text-neutral-400' : 'text-neutral-700'}`}>
                      دفعة مسجلة
                    </span>
                  </div>
                </div>
              </div>

              {/* Send Form */}
              <div className="space-y-3">
                <div>
                  <label className={`block text-xs font-bold mb-1.5 ${
                    isDark ? 'text-neutral-200' : 'text-neutral-800'
                  }`}>
                    البريد الإلكتروني لحساب Google المستلم:
                  </label>
                  <input
                    type="email"
                    placeholder="مثال: partner@gmail.com"
                    value={recipientEmail}
                    onChange={(e) => setRecipientEmail(e.target.value)}
                    className={`w-full py-2.5 px-3.5 rounded-xl border text-xs font-semibold outline-none transition-all ${
                      isDark
                        ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500 placeholder-neutral-500'
                        : 'bg-neutral-50 border-neutral-300 text-neutral-900 focus:border-amber-600 focus:bg-white placeholder-neutral-400'
                    }`}
                  />
                </div>

                <div>
                  <label className={`block text-xs font-bold mb-1.5 ${
                    isDark ? 'text-neutral-200' : 'text-neutral-800'
                  }`}>
                    ملاحظة عن هذا التحديث (اختياري):
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: تحديث شهر سبتمبر بعد سداد الدفعات المالية الأخيرة"
                    value={updateNote}
                    onChange={(e) => setUpdateNote(e.target.value)}
                    className={`w-full py-2.5 px-3.5 rounded-xl border text-xs font-semibold outline-none transition-all ${
                      isDark
                        ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500 placeholder-neutral-500'
                        : 'bg-neutral-50 border-neutral-300 text-neutral-900 focus:border-amber-600 focus:bg-white placeholder-neutral-400'
                    }`}
                  />
                </div>

                <button
                  onClick={() => handleSend(recipientEmail, updateNote)}
                  disabled={isSending || !recipientEmail.trim()}
                  className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-xs sm:text-sm shadow-md transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSending ? 'جاري إرسال التحديث...' : 'إرسال آخر التحديثات لهذا الحساب 🚀'}</span>
                </button>
              </div>

              {/* Quick Share with Recent Partners */}
              {recentPartners.length > 0 && (
                <div className={`pt-3 border-t ${isDark ? 'border-neutral-700/60' : 'border-neutral-200'}`}>
                  <span className={`block text-xs font-bold mb-2 ${
                    isDark ? 'text-neutral-300' : 'text-neutral-800'
                  }`}>
                    شركاء قمت بالمشاركة معهم مسبقاً (إرسال فوري بنقرة واحدة):
                  </span>
                  <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                    {recentPartners.map((partnerEmail) => (
                      <div
                        key={partnerEmail}
                        className={`p-2.5 rounded-xl border flex items-center justify-between text-xs transition-colors ${
                          isDark
                            ? 'bg-[#151C28] border-neutral-700/50 text-neutral-200'
                            : 'bg-neutral-50 border-neutral-200 text-neutral-800'
                        }`}
                      >
                        <div className="flex items-center gap-2 font-mono text-[11px] font-bold">
                          <UserCheck className="w-3.5 h-3.5 text-amber-500" />
                          <span>{partnerEmail}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleSend(partnerEmail, 'مشاركة آخر التحديثات')}
                            disabled={isSending}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-all active:scale-95 ${
                              isDark
                                ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40'
                                : 'bg-amber-500 text-neutral-950 hover:bg-amber-400 font-extrabold'
                            }`}
                            title="إرسال نسختك الحالية لهذا الشريك الآن"
                          >
                            إرسال التحديثات الآن ⬆️
                          </button>
                          <button
                            onClick={() => removePartnerFromRecent(partnerEmail)}
                            className={`p-1 cursor-pointer transition-colors ${
                              isDark ? 'text-neutral-400 hover:text-rose-400' : 'text-neutral-500 hover:text-rose-600'
                            }`}
                            title="حذف من القائمة السريعة"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Independence Note */}
              <div className={`p-3.5 rounded-2xl border flex items-start gap-2.5 text-xs leading-relaxed ${
                isDark
                  ? 'bg-amber-500/10 border-amber-500/20 text-amber-300'
                  : 'bg-amber-50 border-amber-200 text-amber-900 font-medium'
              }`}>
                <ShieldCheck className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <span>
                  <strong>مبدأ الاستقلالية التامة:</strong> عندما ترسل التحديث، يطبّقه الشريك على حسابه لمرة واحدة.
                  إذا عدّل أو غيّر أي مبلغ أو حذف أي شيء، فلن يتأثر حسابك أبداً. ولن تصلك أو تصله أي تغييرات إلا
                  إذا اخترت أنت إرسال تحديث جديد.
                </span>
              </div>
            </div>
          )}

          {/* TAB 2: INCOMING UPDATES */}
          {activeTab === 'inbox' && (
            <div className="space-y-4">
              {!user ? (
                <div className="text-center p-8 space-y-3">
                  <p className={`text-xs ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                    يرجى تسجيل الدخول بحساب Google لعرض التحديثات المرسلة إليك.
                  </p>
                  <button
                    onClick={() => signIn()}
                    className="px-4 py-2 rounded-xl bg-amber-500 text-neutral-950 font-black text-xs"
                  >
                    تسجيل الدخول
                  </button>
                </div>
              ) : incomingUpdates.length === 0 ? (
                <div className={`text-center py-12 px-4 rounded-2xl border border-dashed space-y-2 ${
                  isDark ? 'border-neutral-700/60' : 'border-neutral-300 bg-neutral-50/50'
                }`}>
                  <Inbox className={`w-10 h-10 mx-auto ${isDark ? 'text-neutral-500' : 'text-neutral-400'}`} />
                  <h3 className={`text-sm font-bold ${isDark ? 'text-neutral-300' : 'text-neutral-800'}`}>
                    لا توجد تحديثات واردة حالياً
                  </h3>
                  <p className={`text-xs max-w-sm mx-auto ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                    عندما يقوم شريكك بإرسال تحديث لمحفظته العقارية إلى بريدك ({user.email})، ستظهر هنا فوراً
                    لتطبيقها بنقرة زر.
                  </p>
                </div>
              ) : (
                <div className="space-y-3 pr-1">
                  {incomingUpdates.map((update) => {
                    const isPending = update.status === 'pending';
                    const dateStr = new Date(update.createdAt).toLocaleDateString('ar-EG', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    });

                    return (
                      <div
                        key={update.id}
                        className={`p-4 rounded-2xl border transition-all ${
                          isPending
                            ? isDark
                              ? 'bg-[#161F2E] border-amber-500/40 shadow-sm'
                              : 'bg-amber-50 border-amber-300 shadow-xs'
                            : isDark
                            ? 'bg-[#121824] border-neutral-700/40 opacity-75'
                            : 'bg-neutral-50 border-neutral-200'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3 mb-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className={`font-bold text-xs ${isDark ? 'text-white' : 'text-neutral-900'}`}>
                                من: {update.senderEmail}
                              </span>
                              {isPending ? (
                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                                  isDark ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' : 'bg-amber-500 text-neutral-950 border-amber-600 font-extrabold'
                                }`}>
                                  جديد
                                </span>
                              ) : (
                                <span className={`px-2 py-0.5 rounded-full text-[10px] ${
                                  isDark ? 'bg-neutral-700 text-neutral-300' : 'bg-neutral-200 text-neutral-700'
                                }`}>
                                  تم تطبيقه
                                </span>
                              )}
                            </div>
                            <span className={`text-[11px] block mt-0.5 ${isDark ? 'text-neutral-400' : 'text-neutral-500'}`}>
                              {dateStr}
                            </span>
                          </div>

                          <button
                            onClick={() => handleDeleteUpdate(update.id)}
                            className={`p-1 transition-colors cursor-pointer ${
                              isDark ? 'text-neutral-400 hover:text-rose-400' : 'text-neutral-500 hover:text-rose-600'
                            }`}
                            title="حذف هذا التحديث"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        {update.note && (
                          <p className={`text-xs p-2.5 rounded-xl mb-3 border ${
                            isDark ? 'bg-black/30 text-neutral-200 border-neutral-700/50' : 'bg-white text-neutral-800 border-neutral-200 font-medium'
                          }`}>
                            {update.note}
                          </p>
                        )}

                        <div className="flex items-center justify-between gap-3 flex-wrap">
                          <div className={`flex items-center gap-3 text-xs font-mono font-bold ${
                            isDark ? 'text-neutral-300' : 'text-neutral-700'
                          }`}>
                            <span>🏢 {update.buildingsCount} عمارة</span>
                            <span>🏠 {update.tenantsCount} مستأجر</span>
                            <span>💰 {update.paymentsCount} دفعة</span>
                          </div>

                          <button
                            onClick={() => handleApply(update)}
                            disabled={applyingId === update.id}
                            className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-xs transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>
                              {applyingId === update.id ? 'جاري التطبيق...' : 'تطبيق هذا التحديث على حسابي'}
                            </span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer - Fixed to bottom */}
        <div className={`pt-3 border-t mt-3 flex justify-end shrink-0 ${
          isDark ? 'border-neutral-700/60' : 'border-neutral-200'
        }`}>
          <button
            onClick={onClose}
            className={`px-5 py-2 rounded-xl font-bold text-xs transition-colors cursor-pointer ${
              isDark
                ? 'bg-neutral-800 hover:bg-neutral-700 text-white'
                : 'bg-neutral-200 hover:bg-neutral-300 text-neutral-900'
            }`}
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
