import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
} from 'recharts';
import {
  BarChart3,
  TrendingUp,
  AlertCircle,
  Building2,
  CheckCircle2,
  Eye,
  EyeOff,
  Maximize2,
  Minimize2,
  X,
  Sparkles,
} from 'lucide-react';
import { Building, Tenant, TenantFinancialSnapshot, ThemeMode } from '../types';
import { formatCurrency, formatMonthName } from '../utils/formatters';
import { getThemeConfig, isDarkTheme } from '../utils/theme';

interface CollectionAnalyticsChartProps {
  totalCollected: number;
  totalRemaining: number;
  totalExpectedRent: number;
  currency: string;
  activeMonthKey: string;
  theme: ThemeMode;
  buildings: Building[];
  tenants: Tenant[];
  snapshots: TenantFinancialSnapshot[];
}

export const CollectionAnalyticsChart: React.FC<CollectionAnalyticsChartProps> = ({
  totalCollected,
  totalRemaining,
  totalExpectedRent,
  currency,
  activeMonthKey,
  theme,
  buildings,
  tenants,
  snapshots,
}) => {
  const [chartMode, setChartMode] = useState<'overall' | 'buildings'>('overall');
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);
  const [isExpanded, setIsExpanded] = useState<boolean>(false);

  const themeConfig = getThemeConfig(theme);
  const isDark = isDarkTheme(theme);

  const collectionRate =
    totalExpectedRent > 0 ? Math.round((totalCollected / totalExpectedRent) * 100) : 0;
  const remainingRate =
    totalExpectedRent > 0 ? Math.max(0, 100 - collectionRate) : 0;

  // 1. Data for Overall Monthly Comparison
  const overallData = useMemo(() => {
    return [
      {
        name: 'المحصل',
        amount: totalCollected,
        percentage: collectionRate,
        fill: themeConfig.chartCollected,
      },
      {
        name: 'المتبقي',
        amount: totalRemaining,
        percentage: remainingRate,
        fill: themeConfig.chartRemaining,
      },
    ];
  }, [totalCollected, totalRemaining, collectionRate, remainingRate, themeConfig]);

  // 2. Data for Building-by-Building Comparison
  const buildingsData = useMemo(() => {
    if (buildings.length === 0) return [];

    return buildings.map((b) => {
      const bSnapshots = snapshots.filter((s) => s.tenant.buildingId === b.id);
      const bExpected = bSnapshots.reduce((acc, s) => acc + s.monthlyRent, 0);
      const bCollected = bSnapshots.reduce((acc, s) => acc + s.totalPaid, 0);
      const bRemaining = bSnapshots.reduce((acc, s) => acc + s.balanceRemaining, 0);
      const bRate = bExpected > 0 ? Math.round((bCollected / bExpected) * 100) : 0;

      const shortName = b.name.length > 15 ? b.name.slice(0, 14) + '…' : b.name;

      return {
        id: b.id,
        fullName: b.name,
        name: shortName,
        collected: bCollected,
        remaining: bRemaining,
        expected: bExpected,
        rate: bRate,
        tenantsCount: bSnapshots.length,
      };
    });
  }, [buildings, snapshots]);

  if (tenants.length === 0 || totalExpectedRent === 0) {
    return null;
  }

  // Custom Tooltips
  const CustomOverallTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      const isCollected = data.name === 'المحصل';
      return (
        <div
          className={`p-3 rounded-xl border shadow-xl text-xs space-y-1.5 min-w-[170px] ${
            isDark
              ? 'bg-[#121A28] border-neutral-700 text-white'
              : 'bg-white border-neutral-200 text-neutral-900 shadow-md'
          }`}
        >
          <div className="flex items-center gap-1.5 font-bold">
            <span
              className="w-2.5 h-2.5 rounded-full inline-block"
              style={{ backgroundColor: data.fill }}
            />
            <span>{isCollected ? 'المبالغ المحصلة' : 'المبالغ المتبقية'}</span>
          </div>
          <div className="text-base font-extrabold font-mono tabular-nums pt-0.5">
            {formatCurrency(data.amount, currency)}
          </div>
          <div className="text-[11px] text-neutral-400 flex items-center justify-between border-t border-neutral-700/30 pt-1">
            <span>النسبة من الإجمالي:</span>
            <span className="font-bold text-amber-400">{data.percentage}%</span>
          </div>
        </div>
      );
    }
    return null;
  };

  const CustomBuildingTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div
          className={`p-3 rounded-xl border shadow-xl text-xs space-y-2 min-w-[200px] ${
            isDark
              ? 'bg-[#121A28] border-neutral-700 text-white'
              : 'bg-white border-neutral-200 text-neutral-900 shadow-md'
          }`}
        >
          <div className="font-extrabold text-sm border-b border-neutral-700/30 pb-1 flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5 text-amber-500" />
            <span>{data.fullName}</span>
          </div>
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1 text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span>المحصل:</span>
              </span>
              <span className="font-mono font-bold tabular-nums">
                {formatCurrency(data.collected, currency)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1 text-rose-400">
                <span className="w-2 h-2 rounded-full bg-rose-500" />
                <span>المتبقي:</span>
              </span>
              <span className="font-mono font-bold tabular-nums">
                {formatCurrency(data.remaining, currency)}
              </span>
            </div>
            <div className="flex items-center justify-between pt-1 border-t border-neutral-700/30 text-neutral-400 text-[11px]">
              <span>إجمالي إيجار العمارة:</span>
              <span className="font-mono font-semibold tabular-nums">
                {formatCurrency(data.expected, currency)}
              </span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span>نسبة التحصيل:</span>
              <span className="font-bold text-emerald-400">{data.rate}%</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  const renderChartContent = (isModal = false) => (
    <>
      {/* KPI mini-cards row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 sm:gap-4 mb-6">
        <div
          className={`p-3.5 rounded-xl border transition-colors ${
            isDark
              ? 'bg-[#101725]/80 border-emerald-500/20'
              : 'bg-emerald-50/50 border-emerald-200'
          }`}
        >
          <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 text-xs font-semibold mb-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>إجمالي المحصل</span>
          </div>
          <div className="text-lg sm:text-xl font-extrabold font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
            {formatCurrency(totalCollected, currency)}
          </div>
          <span className="text-[11px] text-neutral-400">
            {collectionRate}% من المستحق
          </span>
        </div>

        <div
          className={`p-3.5 rounded-xl border transition-colors ${
            isDark
              ? 'bg-[#101725]/80 border-rose-500/20'
              : 'bg-rose-50/50 border-rose-200'
          }`}
        >
          <div className="flex items-center gap-1.5 text-rose-600 dark:text-rose-400 text-xs font-semibold mb-1">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>المتبقي غير المحصل</span>
          </div>
          <div className="text-lg sm:text-xl font-extrabold font-mono tabular-nums text-rose-600 dark:text-rose-400">
            {formatCurrency(totalRemaining, currency)}
          </div>
          <span className="text-[11px] text-neutral-400">
            {remainingRate}% متبقي للتحصيل
          </span>
        </div>

        <div
          className={`col-span-2 sm:col-span-1 p-3.5 rounded-xl border transition-colors ${
            isDark
              ? 'bg-[#101725]/80 border-neutral-700/60'
              : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <div className="text-xs font-semibold text-neutral-400 mb-1">
            مؤشر الإنجاز الشهري
          </div>
          <div className="flex items-center justify-between text-xs font-bold mb-1.5">
            <span className="text-emerald-500">تم {collectionRate}%</span>
            <span className="text-neutral-400">المطلوب {formatCurrency(totalExpectedRent, currency)}</span>
          </div>
          <div
            className={`w-full h-2 rounded-full overflow-hidden ${
              isDark ? 'bg-neutral-800' : 'bg-neutral-200'
            }`}
          >
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500 rounded-full"
              style={{ width: `${Math.min(100, collectionRate)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Main Recharts Container */}
      <div className={`w-full ${isModal ? 'h-[420px] sm:h-[500px]' : 'h-64 sm:h-72 lg:h-80'} pt-2`} dir="ltr">
        <ResponsiveContainer width="100%" height="100%">
          {chartMode === 'overall' ? (
            <BarChart
              data={overallData}
              margin={{ top: 20, right: 30, left: 10, bottom: 10 }}
              barSize={isModal ? 80 : 54}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                stroke={themeConfig.chartGrid}
                vertical={false}
              />
              <XAxis
                dataKey="name"
                tick={{ fill: themeConfig.chartText, fontSize: 13, fontWeight: 700 }}
                axisLine={{ stroke: themeConfig.chartGrid }}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: themeConfig.chartText, fontSize: 11 }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(val) =>
                  val >= 1000 ? `${(val / 1000).toFixed(1)}k` : `${val}`
                }
              />
              <Tooltip content={<CustomOverallTooltip />} cursor={{ fill: 'rgba(255, 255, 255, 0.04)' }} />
              <Bar
                dataKey="amount"
                radius={[8, 8, 0, 0]}
                animationDuration={800}
              >
                {overallData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          ) : (
            <BarChart
              data={buildingsData}
              margin={{ top: 20, right: 20, left: 10, bottom: 25 }}
              barGap={6}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                stroke={themeConfig.chartGrid}
                vertical={false}
              />
              <XAxis
                dataKey="name"
                tick={{ fill: themeConfig.chartText, fontSize: 11, fontWeight: 600 }}
                axisLine={{ stroke: themeConfig.chartGrid }}
                tickLine={false}
                interval={0}
                angle={-15}
                textAnchor="end"
              />
              <YAxis
                tick={{ fill: themeConfig.chartText, fontSize: 11 }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(val) =>
                  val >= 1000 ? `${(val / 1000).toFixed(1)}k` : `${val}`
                }
              />
              <Tooltip content={<CustomBuildingTooltip />} cursor={{ fill: 'rgba(255, 255, 255, 0.04)' }} />
              <Legend
                verticalAlign="top"
                align="right"
                wrapperStyle={{ paddingBottom: 12, fontSize: 12 }}
                formatter={(value) => (
                  <span style={{ color: themeConfig.chartText, fontWeight: 600 }}>
                    {value === 'collected' ? 'المحصل' : 'المتبقي'}
                  </span>
                )}
              />
              <Bar
                name="collected"
                dataKey="collected"
                fill={themeConfig.chartCollected}
                radius={[6, 6, 0, 0]}
                animationDuration={800}
                maxBarSize={45}
              />
              <Bar
                name="remaining"
                dataKey="remaining"
                fill={themeConfig.chartRemaining}
                radius={[6, 6, 0, 0]}
                animationDuration={800}
                maxBarSize={45}
              />
            </BarChart>
          )}
        </ResponsiveContainer>
      </div>
    </>
  );

  return (
    <>
      <section
        className={`p-4 sm:p-6 rounded-2xl border shadow-md transition-all duration-200 ${themeConfig.bgCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
      >
        {/* Header with Title, Mode Switcher and Hide/Expand Actions */}
        <div className={`flex flex-col md:flex-row md:items-center justify-between gap-3 ${!isCollapsed ? 'mb-6 pb-4 border-b border-neutral-700/20' : ''}`}>
          <div>
            <div className="flex items-center gap-2">
              <div
                className={`p-2 rounded-xl ${
                  isDark ? 'bg-neutral-800 text-amber-400' : 'bg-neutral-100 text-amber-700'
                }`}
              >
                <BarChart3 className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-extrabold tracking-tight flex items-center gap-2">
                  <span>مؤشر التحصيل المالي لشهر {formatMonthName(activeMonthKey)}</span>
                </h2>
                {!isCollapsed && (
                  <p className="text-xs text-neutral-400 mt-0.5">
                    مقارنة بيانية دقيقة بين إجمالي المبالغ المحصلة والمتبقية
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Action Controls & KPI summary */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {!isCollapsed && (
              <>
                {/* Collection Status Pill */}
                <div
                  className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold ${
                    collectionRate >= 80
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                      : collectionRate >= 50
                      ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                      : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                  }`}
                >
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>نسبة التحصيل: {collectionRate}%</span>
                </div>

                {/* Toggle between Overall vs By-Building */}
                {buildings.length > 1 && (
                  <div
                    className={`flex items-center p-1 rounded-xl border text-xs font-medium ${themeConfig.bgSubCard} ${themeConfig.borderCard}`}
                  >
                    <button
                      type="button"
                      onClick={() => setChartMode('overall')}
                      className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                        chartMode === 'overall'
                          ? 'bg-amber-500 text-neutral-950 font-bold shadow-xs'
                          : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      إجمالي الشهر
                    </button>
                    <button
                      type="button"
                      onClick={() => setChartMode('buildings')}
                      className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                        chartMode === 'buildings'
                          ? 'bg-amber-500 text-neutral-950 font-bold shadow-xs'
                          : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      حسب العمارات ({buildings.length})
                    </button>
                  </div>
                )}
              </>
            )}

            {/* Expand (Maximize) Button */}
            {!isCollapsed && (
              <button
                type="button"
                onClick={() => setIsExpanded(true)}
                className={`p-2 rounded-xl border text-xs transition-all cursor-pointer flex items-center gap-1 ${
                  isDark
                    ? 'bg-neutral-800/80 border-neutral-700 text-neutral-300 hover:text-white hover:bg-neutral-700'
                    : 'bg-neutral-100 border-neutral-200 text-neutral-700 hover:text-black hover:bg-neutral-200'
                }`}
                title="توسيع الرسم البياني لنافذة كاملة"
              >
                <Maximize2 className="w-4 h-4 text-amber-500" />
                <span className="hidden lg:inline text-[11px]">توسيع</span>
              </button>
            )}

            {/* Hide / Collapse Toggle Button */}
            <button
              type="button"
              onClick={() => setIsCollapsed(!isCollapsed)}
              className={`p-2 rounded-xl border text-xs transition-all cursor-pointer flex items-center gap-1.5 font-semibold ${
                isDark
                  ? 'bg-neutral-800/80 border-neutral-700 text-neutral-300 hover:text-white hover:bg-neutral-700'
                  : 'bg-neutral-100 border-neutral-200 text-neutral-700 hover:text-black hover:bg-neutral-200'
              }`}
              title={isCollapsed ? 'إظهار الرسم البياني والمؤشرات' : 'إخفاء (طي) الرسم البياني'}
            >
              {isCollapsed ? (
                <>
                  <Eye className="w-4 h-4 text-emerald-400" />
                  <span>إظهار الرسم البياني</span>
                </>
              ) : (
                <>
                  <EyeOff className="w-4 h-4 text-neutral-400" />
                  <span>إخفاء</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Collapsible Content Area */}
        {!isCollapsed && renderChartContent(false)}
      </section>

      {/* Expanded Modal View (Maximize Overlay) */}
      {isExpanded && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div
            className={`w-full max-w-5xl rounded-3xl border shadow-2xl p-5 sm:p-8 relative overflow-y-auto max-h-[92vh] ${
              isDark
                ? 'bg-[#111827] border-neutral-700 text-white'
                : 'bg-white border-neutral-200 text-neutral-900'
            }`}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 mb-6 border-b border-neutral-700/30">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg sm:text-xl font-extrabold">
                    تحليل التحصيل المالي الشامل - {formatMonthName(activeMonthKey)}
                  </h3>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    وضع العرض المكبر للرسم البياني والمقارنات التفصيلية
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Mode switcher in modal */}
                {buildings.length > 1 && (
                  <div
                    className={`hidden sm:flex items-center p-1 rounded-xl border text-xs font-medium ${
                      isDark ? 'bg-[#0E1522] border-neutral-700' : 'bg-neutral-100 border-neutral-300'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => setChartMode('overall')}
                      className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                        chartMode === 'overall'
                          ? 'bg-amber-500 text-neutral-950 font-bold shadow-xs'
                          : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      إجمالي الشهر
                    </button>
                    <button
                      type="button"
                      onClick={() => setChartMode('buildings')}
                      className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                        chartMode === 'buildings'
                          ? 'bg-amber-500 text-neutral-950 font-bold shadow-xs'
                          : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      حسب العمارات ({buildings.length})
                    </button>
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => setIsExpanded(false)}
                  className={`p-2.5 rounded-xl border transition-colors cursor-pointer ${
                    isDark
                      ? 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white hover:bg-neutral-700'
                      : 'bg-neutral-100 border-neutral-200 text-neutral-700 hover:text-black hover:bg-neutral-200'
                  }`}
                  title="إغلاق العرض المكبر"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            {renderChartContent(true)}
          </div>
        </div>
      )}
    </>
  );
};
