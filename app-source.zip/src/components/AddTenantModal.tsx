import React, { useState, useEffect } from 'react';
import { X, Check, Building2, Calendar, Phone } from 'lucide-react';
import { Building, Tenant, ThemeMode, UnitType } from '../types';

interface AddTenantModalProps {
  isOpen: boolean;
  onClose: () => void;
  buildings: Building[];
  currency: string;
  initialBuildingId?: string;
  onSaveTenant: (tenant: Tenant, newBuilding?: Building) => void;
  onOpenAddBuilding?: () => void;
  theme: ThemeMode;
}

export const AddTenantModal: React.FC<AddTenantModalProps> = ({
  isOpen,
  onClose,
  buildings,
  currency,
  initialBuildingId,
  onSaveTenant,
  onOpenAddBuilding,
  theme,
}) => {
  // Hooks MUST be called unconditionally at top of component
  const [buildingId, setBuildingId] = useState<string>(
    initialBuildingId || (buildings.length > 0 ? buildings[0].id : 'new')
  );
  const [newBuildingName, setNewBuildingName] = useState<string>('');
  const [newBuildingLocation, setNewBuildingLocation] = useState<string>('');

  const [unitNumber, setUnitNumber] = useState<string>('');
  const [unitType, setUnitType] = useState<UnitType>('apartment');
  const [customUnitType, setCustomUnitType] = useState<string>('');
  const [name, setName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [monthlyRent, setMonthlyRent] = useState<number | ''>(350);
  const [securityDeposit, setSecurityDeposit] = useState<number | ''>('');
  const [leaseStart, setLeaseStart] = useState<string>('');
  const [leaseEnd, setLeaseEnd] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      if (initialBuildingId) {
        setBuildingId(initialBuildingId);
      } else if (buildings.length > 0) {
        // Keep current selected buildingId if still valid, otherwise default to first
        setBuildingId((prev) => {
          if (prev && prev !== 'new' && buildings.some((b) => b.id === prev)) {
            return prev;
          }
          return buildings[0].id;
        });
      } else {
        setBuildingId('new');
      }
    }
  }, [isOpen, initialBuildingId]);

  const resetForm = () => {
    setUnitNumber('');
    setUnitType('apartment');
    setCustomUnitType('');
    setName('');
    setPhone('');
    setMonthlyRent(350);
    setSecurityDeposit('');
    setLeaseStart('');
    setLeaseEnd('');
    setNotes('');
    setNewBuildingName('');
    setNewBuildingLocation('');
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return; // unitNumber is optional
    const rentNum = typeof monthlyRent === 'number' ? monthlyRent : 0;
    if (rentNum <= 0) return;

    let targetBuildingId = buildingId;
    let createdBuilding: Building | undefined = undefined;

    if (buildingId === 'new') {
      if (!newBuildingName.trim()) return;
      const bId = `b-${Date.now()}`;
      createdBuilding = {
        id: bId,
        name: newBuildingName.trim(),
        location: newBuildingLocation.trim() || 'الموقع غير محدد',
      };
      targetBuildingId = bId;
    }

    const depositNum = typeof securityDeposit === 'number' ? securityDeposit : 0;

    const newTenant: Tenant = {
      id: `t-${Date.now()}`,
      buildingId: targetBuildingId,
      unitNumber: unitNumber.trim(),
      unitType,
      customUnitType: unitType === 'other' ? customUnitType.trim() : undefined,
      name: name.trim(),
      phone: phone.trim() || '0790000000',
      monthlyRent: rentNum,
      currency,
      leaseStart: leaseStart.trim() || undefined,
      leaseEnd: leaseEnd.trim() || undefined,
      securityDeposit: depositNum,
      depositStatus: depositNum > 0 ? 'held' : undefined,
      notes: notes.trim() || undefined,
    };

    onSaveTenant(newTenant, createdBuilding);
    resetForm();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`relative w-full sm:max-w-xl border-t sm:border sm:rounded-2xl rounded-t-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col transition-colors ${
          theme === 'dark'
            ? 'bg-[#151C28] border-neutral-700/80 text-white'
            : 'bg-white border-neutral-300 text-neutral-900'
        }`}
      >
        {/* Header */}
        <div
          className={`flex items-center justify-between px-6 py-4 border-b ${
            theme === 'dark' ? 'bg-[#121824] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <div>
            <span className="text-xs font-semibold text-amber-500">إضافة شقة / محل ومستأجر</span>
            <h3 className="text-lg font-bold tracking-tight">تسجيل وحدة مستأجرة تابعة للعمارة</h3>
          </div>
          <button
            onClick={handleClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-700 dark:hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1 text-xs">
          {/* Building Selection */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block font-bold text-neutral-700 dark:text-neutral-300">
                العمارة أو المجمع التابع له <span className="text-rose-500">*</span>
              </label>
              {onOpenAddBuilding && (
                <button
                  type="button"
                  onClick={() => {
                    handleClose();
                    onOpenAddBuilding();
                  }}
                  className="text-amber-500 hover:underline font-semibold text-[11px] cursor-pointer"
                >
                  + إنشاء عمارة جديدة منفصلة
                </button>
              )}
            </div>

            <select
              value={buildingId}
              onChange={(e) => setBuildingId(e.target.value)}
              className={`w-full py-2.5 px-3 rounded-xl border outline-none font-semibold cursor-pointer ${
                theme === 'dark'
                  ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                  : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
              }`}
            >
              {buildings.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name} ({b.location})
                </option>
              ))}
              <option value="new">+ إضافة عمارة / مجمع جديد لهذه الشقة...</option>
            </select>
          </div>

          {/* New Building Inputs if selected inline */}
          {buildingId === 'new' && (
            <div
              className={`p-3.5 rounded-xl border space-y-3 ${
                theme === 'dark'
                  ? 'bg-[#0F1520] border-neutral-800'
                  : 'bg-amber-50/50 border-amber-200'
              }`}
            >
              <div className="space-y-1">
                <label className="block font-bold text-amber-600 dark:text-amber-300">
                  اسم العمارة الجديدة <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: عمارة النور أو مجمع الشروق التجاري"
                  value={newBuildingName}
                  onChange={(e) => setNewBuildingName(e.target.value)}
                  className={`w-full py-2 px-3 rounded-lg border outline-none ${
                    theme === 'dark'
                      ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                      : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                  }`}
                />
              </div>
              <div className="space-y-1">
                <label className="block text-neutral-500">الموقع أو العنوان (اختياري)</label>
                <input
                  type="text"
                  placeholder="مثال: عمان، شارع الجامعة"
                  value={newBuildingLocation}
                  onChange={(e) => setNewBuildingLocation(e.target.value)}
                  className={`w-full py-2 px-3 rounded-lg border outline-none ${
                    theme === 'dark'
                      ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                      : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                  }`}
                />
              </div>
            </div>
          )}

          {/* Unit Number & Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block font-bold text-neutral-700 dark:text-neutral-300">
                رقم أو مسمى الوحدة <span className="text-neutral-400 font-normal">(اختياري)</span>
              </label>
              <input
                type="text"
                placeholder="مثال: شقة 101، محل 2 (اختياري)"
                value={unitNumber}
                onChange={(e) => setUnitNumber(e.target.value)}
                className={`w-full py-2.5 px-3 rounded-xl border outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
              />
            </div>

            <div className="space-y-1">
              <label className="block font-bold text-neutral-700 dark:text-neutral-300">
                نوع العقار / الوحدة
              </label>
              <select
                value={unitType}
                onChange={(e) => setUnitType(e.target.value as UnitType)}
                className={`w-full py-2.5 px-3 rounded-xl border outline-none cursor-pointer ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
              >
                <option value="apartment">شقة سكنية (Apartment)</option>
                <option value="commercial_shop">محل تجاري (Commercial Shop)</option>
                <option value="office">مكتب أعمال (Office)</option>
                <option value="penthouse">بنتهاوس (Penthouse)</option>
                <option value="villa">فيلا مستقلة (Villa)</option>
                <option value="other">أخرى (مخصص)...</option>
              </select>
            </div>
          </div>

          {/* Custom Unit Type Name when 'other' is selected */}
          {unitType === 'other' && (
            <div className="space-y-1 animate-in fade-in duration-150">
              <label className="block font-bold text-amber-500 dark:text-amber-400">
                اكتب نوع الوحدة المخصص <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required={unitType === 'other'}
                placeholder="مثال: مستودع، كراج، استوديو، ملحق، معرض، صالة..."
                value={customUnitType}
                onChange={(e) => setCustomUnitType(e.target.value)}
                className={`w-full py-2.5 px-3 rounded-xl border outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-amber-500/50 text-white focus:border-amber-400'
                    : 'bg-amber-50/40 border-amber-300 text-neutral-900 focus:border-amber-500'
                }`}
              />
            </div>
          )}

          {/* Tenant Name & Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block font-bold text-neutral-700 dark:text-neutral-300">
                اسم المستأجر الكامل <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="مثال: م. عمر التميمي"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className={`w-full py-2.5 px-3 rounded-xl border outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
              />
            </div>

            <div className="space-y-1">
              <label className="block font-bold text-neutral-700 dark:text-neutral-300">
                رقم الهاتف (للاتصال والواتساب) <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="مثال: 0791234567 أو 0780000000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className={`w-full py-2.5 px-3 pr-8 rounded-xl border font-mono outline-none text-left ${
                    theme === 'dark'
                      ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                      : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                  }`}
                  dir="ltr"
                />
                <Phone className="w-3.5 h-3.5 absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 pointer-events-none" />
              </div>
              <span className="text-[10px] text-neutral-400">
                يمكنك كتابة رقم الهاتف مباشرة (مثلاً: 079XXXXXXX أو +9627XXXXXXX)
              </span>
            </div>
          </div>

          {/* Monthly Rent & Security Deposit */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block font-bold text-neutral-700 dark:text-neutral-300">
                الإيجار الشهري ({currency}) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="1"
                required
                placeholder="مثال: 350"
                value={monthlyRent}
                onChange={(e) => setMonthlyRent(e.target.value === '' ? '' : parseFloat(e.target.value))}
                className={`w-full py-2.5 px-3 rounded-xl border font-mono font-bold text-left outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
                dir="ltr"
              />
            </div>

            <div className="space-y-1">
              <label className="block font-bold text-sky-500">
                قيمة ضمان المحل / التأمين ({currency}) <span className="text-neutral-400 font-normal">(اختياري)</span>
              </label>
              <input
                type="number"
                min="0"
                placeholder="0"
                value={securityDeposit}
                onChange={(e) => setSecurityDeposit(e.target.value === '' ? '' : parseFloat(e.target.value))}
                className={`w-full py-2.5 px-3 rounded-xl border font-mono font-bold text-left outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-sky-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-sky-500'
                }`}
                dir="ltr"
              />
            </div>
          </div>

          {/* Lease Dates (COMPLETELY OPTIONAL) */}
          <div
            className={`p-3.5 rounded-xl border space-y-2.5 ${
              theme === 'dark' ? 'bg-[#0F1520] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
            }`}
          >
            <div className="flex items-center gap-2 text-neutral-500 dark:text-neutral-400">
              <Calendar className="w-4 h-4 text-amber-500" />
              <span className="font-semibold text-xs">
                تواريخ العقد <span className="text-[11px] text-neutral-400 font-normal">(اختياري تماماً — يمكنك تركه فارغاً)</span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-neutral-500 dark:text-neutral-400">تاريخ بداية العقد</label>
                <input
                  type="date"
                  value={leaseStart}
                  min="2020-01-01"
                  max="2040-12-31"
                  onChange={(e) => setLeaseStart(e.target.value)}
                  className={`w-full py-2 px-3 rounded-xl border outline-none ${
                    theme === 'dark'
                      ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                      : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                  }`}
                />
              </div>
              <div className="space-y-1">
                <label className="block text-neutral-500 dark:text-neutral-400">تاريخ نهاية العقد</label>
                <input
                  type="date"
                  value={leaseEnd}
                  min="2020-01-01"
                  max="2040-12-31"
                  onChange={(e) => setLeaseEnd(e.target.value)}
                  className={`w-full py-2 px-3 rounded-xl border outline-none ${
                    theme === 'dark'
                      ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                      : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-1">
            <label className="block text-neutral-500">ملاحظات إضافية (اختياري)</label>
            <input
              type="text"
              placeholder="مثال: شامل الماء وموقف خاص، الدفع في نهاية الشهر"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className={`w-full py-2 px-3 rounded-xl border outline-none ${
                theme === 'dark'
                  ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                  : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
              }`}
            />
          </div>

          {/* Submit */}
          <div
            className={`pt-3 flex items-center justify-end gap-3 border-t ${
              theme === 'dark' ? 'border-neutral-800' : 'border-neutral-200'
            }`}
          >
            <button
              type="button"
              onClick={handleClose}
              className={`px-4 py-2.5 rounded-xl border font-semibold cursor-pointer ${
                theme === 'dark'
                  ? 'border-neutral-700 text-neutral-300 hover:bg-neutral-800'
                  : 'border-neutral-300 text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-bold shadow-lg transition-all active:scale-95 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>إضافة وتفعيل الشقة</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
