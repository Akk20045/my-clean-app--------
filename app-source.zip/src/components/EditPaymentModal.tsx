import React, { useState, useEffect } from 'react';
import { X, Check, CreditCard, Banknote, Landmark, FileText } from 'lucide-react';
import { PaymentMethod, PaymentRecord, ThemeMode } from '../types';
import { formatCurrency, formatMonthName } from '../utils/formatters';

interface EditPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  payment: PaymentRecord | null;
  tenantName: string;
  unitNumber?: string;
  currency: string;
  onUpdatePayment: (updated: PaymentRecord) => void;
  theme: ThemeMode;
}

export const EditPaymentModal: React.FC<EditPaymentModalProps> = ({
  isOpen,
  onClose,
  payment,
  tenantName,
  unitNumber,
  currency,
  onUpdatePayment,
  theme,
}) => {
  // Hooks MUST be called unconditionally at top of component
  const [amount, setAmount] = useState<number | ''>(payment ? payment.amount : 0);
  const [method, setMethod] = useState<PaymentMethod>(payment ? payment.method : 'cliq');
  const [date, setDate] = useState<string>(payment ? payment.date : new Date().toISOString().slice(0, 10));
  const [referenceNumber, setReferenceNumber] = useState<string>(payment?.referenceNumber || '');
  const [notes, setNotes] = useState<string>(payment?.notes || '');

  useEffect(() => {
    if (payment) {
      setAmount(payment.amount);
      setMethod(payment.method);
      setDate(payment.date);
      setReferenceNumber(payment.referenceNumber || '');
      setNotes(payment.notes || '');
    }
  }, [payment]);

  if (!isOpen || !payment) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = typeof amount === 'number' ? amount : 0;
    if (amountNum <= 0) return;

    onUpdatePayment({
      ...payment,
      amount: amountNum,
      method,
      date,
      referenceNumber: referenceNumber.trim() || undefined,
      notes: notes.trim() || undefined,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`relative w-full sm:max-w-md border-t sm:border sm:rounded-2xl rounded-t-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col transition-colors ${
          theme === 'dark'
            ? 'bg-[#151C28] border-neutral-700/80 text-white'
            : 'bg-white border-neutral-300 text-neutral-900'
        }`}
      >
        {/* Header */}
        <div
          className={`flex items-center justify-between px-6 py-4 border-b ${
            theme === 'dark' ? 'bg-[#121824] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <div>
            <span className="text-xs font-semibold text-amber-500">تعديل مبلغ وتفاصيل الدفعة</span>
            <h3 className="text-base font-extrabold tracking-tight flex items-center gap-1.5 flex-wrap">
              {unitNumber?.trim() ? (
                <>
                  <span>{unitNumber}</span>
                  <span className="text-neutral-400">·</span>
                </>
              ) : null}
              <span className="text-sm font-semibold">{tenantName}</span>
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-700 dark:hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs overflow-y-auto">
          {/* Target Month preview */}
          <div
            className={`p-3 rounded-xl border flex items-center justify-between ${
              theme === 'dark' ? 'bg-[#0F1520] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
            }`}
          >
            <div>
              <span className="text-neutral-400 block text-[10px]">استحقاق شهر:</span>
              <span className="text-xs font-bold text-amber-500">
                {formatMonthName(payment.monthKey)}
              </span>
            </div>
            <div className="text-left font-mono">
              <span className="text-neutral-400 block text-[10px]">رقم السند:</span>
              <span className="text-xs font-bold text-neutral-300">{payment.receiptNumber}</span>
            </div>
          </div>

          {/* Amount Paid */}
          <div className="space-y-1.5">
            <label className="block font-bold text-neutral-700 dark:text-neutral-300">
              المبلغ المدفوع فعلياً ({currency}) <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                type="number"
                min="0.01"
                step="any"
                required
                value={amount}
                onChange={(e) =>
                  setAmount(e.target.value === '' ? '' : parseFloat(e.target.value))
                }
                className={`w-full py-2.5 pr-16 pl-3.5 rounded-xl border font-mono text-lg font-bold tabular-nums outline-none text-left ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
                dir="ltr"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 font-bold text-amber-500 pointer-events-none">
                {currency}
              </span>
            </div>
          </div>

          {/* Payment Method */}
          <div className="space-y-1.5">
            <label className="block font-bold text-neutral-700 dark:text-neutral-300">
              طريقة الدفع
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setMethod('cliq')}
                className={`flex items-center justify-center p-2.5 rounded-xl border font-bold gap-1.5 transition-all cursor-pointer ${
                  method === 'cliq'
                    ? 'bg-amber-500/15 border-amber-500 text-amber-600 dark:text-amber-300'
                    : theme === 'dark'
                    ? 'bg-[#0F1520] border-neutral-800 text-neutral-400'
                    : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                }`}
              >
                <CreditCard className="w-4 h-4" />
                <span>كليك (CliQ)</span>
              </button>

              <button
                type="button"
                onClick={() => setMethod('cash')}
                className={`flex items-center justify-center p-2.5 rounded-xl border font-bold gap-1.5 transition-all cursor-pointer ${
                  method === 'cash'
                    ? 'bg-amber-500/15 border-amber-500 text-amber-600 dark:text-amber-300'
                    : theme === 'dark'
                    ? 'bg-[#0F1520] border-neutral-800 text-neutral-400'
                    : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                }`}
              >
                <Banknote className="w-4 h-4" />
                <span>نقداً (كاش)</span>
              </button>

              <button
                type="button"
                onClick={() => setMethod('bank_transfer')}
                className={`flex items-center justify-center p-2.5 rounded-xl border font-bold gap-1.5 transition-all cursor-pointer ${
                  method === 'bank_transfer'
                    ? 'bg-amber-500/15 border-amber-500 text-amber-600 dark:text-amber-300'
                    : theme === 'dark'
                    ? 'bg-[#0F1520] border-neutral-800 text-neutral-400'
                    : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                }`}
              >
                <Landmark className="w-4 h-4" />
                <span>تحويل بنكي</span>
              </button>

              <button
                type="button"
                onClick={() => setMethod('cheque')}
                className={`flex items-center justify-center p-2.5 rounded-xl border font-bold gap-1.5 transition-all cursor-pointer ${
                  method === 'cheque'
                    ? 'bg-amber-500/15 border-amber-500 text-amber-600 dark:text-amber-300'
                    : theme === 'dark'
                    ? 'bg-[#0F1520] border-neutral-800 text-neutral-400'
                    : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>شيك مصرفي</span>
              </button>
            </div>
          </div>

          {/* Date & Reference */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div className="space-y-1">
              <label className="block text-neutral-500">تاريخ الدفع</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className={`w-full py-2 px-3 rounded-xl border outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
              />
            </div>

            <div className="space-y-1">
              <label className="block text-neutral-500">الرقم المرجعي</label>
              <input
                type="text"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                className={`w-full py-2 px-3 rounded-xl border outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
              />
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-1">
            <label className="block text-neutral-500">ملاحظات إضافية</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className={`w-full py-2 px-3 rounded-xl border outline-none ${
                theme === 'dark'
                  ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                  : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
              }`}
            />
          </div>

          {/* Footer actions */}
          <div
            className={`pt-3 flex items-center justify-end gap-2 border-t ${
              theme === 'dark' ? 'border-neutral-800' : 'border-neutral-200'
            }`}
          >
            <button
              type="button"
              onClick={onClose}
              className={`px-4 py-2 rounded-xl border font-semibold cursor-pointer ${
                theme === 'dark'
                  ? 'border-neutral-700 text-neutral-300 hover:bg-neutral-800'
                  : 'border-neutral-300 text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-bold shadow-md transition-all active:scale-95 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>تحديث الدفعة</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
