import React, { useState, useEffect } from 'react';
import { AlertTriangle, ShieldAlert, Trash2, X, Check } from 'lucide-react';
import { ThemeMode } from '../types';

interface ConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  isDestructive?: boolean;
  requireInputText?: string;
  theme: ThemeMode;
}

// Normalizer to handle Arabic alef variants, tanween, and extra whitespace
const normalizeArabic = (str: string) => {
  return str
    .trim()
    .replace(/[أإآ]/g, 'ا')
    .replace(/ـ/g, '') // tatweel
    .replace(/ً|ٌ|ٍ|َ|ُ|ِ|ْ|ّ/g, '') // diacritics
    .replace(/\s+/g, ' ');
};

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = 'نعم، تأكيد الحذف',
  cancelText = 'إلغاء وتراجع',
  isDestructive = true,
  requireInputText,
  theme,
}) => {
  const [typedInput, setTypedInput] = useState('');

  useEffect(() => {
    if (isOpen) {
      setTypedInput('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isInputRequired = !!requireInputText;
  const isInputMatched = isInputRequired
    ? normalizeArabic(typedInput) === normalizeArabic(requireInputText)
    : true;

  const handleConfirm = () => {
    if (isInputRequired && !isInputMatched) return;
    onConfirm();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-md border rounded-2xl shadow-2xl overflow-hidden flex flex-col transition-colors ${
          theme === 'dark'
            ? 'bg-[#151C28] border-neutral-700/80 text-white'
            : 'bg-white border-neutral-300 text-neutral-900'
        }`}
      >
        <div className="p-6 space-y-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div
                className={`p-3 rounded-2xl border shrink-0 ${
                  requireInputText
                    ? 'bg-rose-500/20 border-rose-500/50 text-rose-500 animate-pulse'
                    : isDestructive
                    ? 'bg-rose-500/10 border-rose-500/30 text-rose-500'
                    : 'bg-amber-500/10 border-amber-500/30 text-amber-500'
                }`}
              >
                {requireInputText ? (
                  <ShieldAlert className="w-6 h-6" />
                ) : isDestructive ? (
                  <Trash2 className="w-6 h-6" />
                ) : (
                  <AlertTriangle className="w-6 h-6" />
                )}
              </div>
              <div>
                <h3 className="text-base font-extrabold tracking-tight">{title}</h3>
                <span className="text-[11px] text-rose-400 font-medium">
                  {requireInputText ? 'حماية مشددة ضد الحذف الخطأ' : 'تأكيد العملية'}
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-neutral-400 hover:text-neutral-700 dark:hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">{message}</p>

          {requireInputText && (
            <div className="p-3.5 rounded-xl border border-rose-500/30 bg-rose-500/10 space-y-2.5">
              <div className="text-xs font-bold text-rose-400 flex items-center justify-between">
                <span>لتأكيد الحذف النهائي، يرجى كتابة النص التالي بالكامل:</span>
              </div>
              <div className="p-2.5 rounded-lg bg-black/40 border border-rose-500/20 text-center font-mono text-xs font-bold text-rose-200 select-all dir-rtl">
                {requireInputText}
              </div>
              <input
                type="text"
                value={typedInput}
                onChange={(e) => setTypedInput(e.target.value)}
                placeholder="اكتب العبارة هنا..."
                className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold outline-none transition-all ${
                  theme === 'dark'
                    ? 'bg-[#182130] border-neutral-700 text-white focus:border-rose-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-rose-500'
                } ${isInputMatched ? 'border-emerald-500 focus:border-emerald-500 bg-emerald-500/5' : ''}`}
                autoFocus
              />
              {typedInput.trim() !== '' && !isInputMatched && (
                <p className="text-[11px] text-rose-400 font-semibold">
                  ⚠️ العبارة المكتوبة لا تطابق العبارة المطلوبة بالضبط.
                </p>
              )}
              {isInputMatched && (
                <p className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" />
                  تمت كتابة العبارة بنجاح، يمكنك الآن تأكيد العملية.
                </p>
              )}
            </div>
          )}

          <div
            className={`pt-3 flex items-center justify-end gap-2.5 border-t ${
              theme === 'dark' ? 'border-neutral-800' : 'border-neutral-200'
            }`}
          >
            <button
              type="button"
              onClick={onClose}
              className={`px-4 py-2 rounded-xl border text-xs font-semibold transition-colors cursor-pointer ${
                theme === 'dark'
                  ? 'border-neutral-700 text-neutral-300 hover:bg-neutral-800'
                  : 'border-neutral-300 text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              {cancelText}
            </button>

            <button
              type="button"
              onClick={handleConfirm}
              disabled={isInputRequired && !isInputMatched}
              className={`flex items-center gap-1.5 px-5 py-2 rounded-xl font-bold text-xs shadow-md transition-all active:scale-95 ${
                isInputRequired && !isInputMatched
                  ? 'bg-neutral-700 text-neutral-400 cursor-not-allowed opacity-50 shadow-none'
                  : isDestructive
                  ? 'bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white shadow-rose-950/30 cursor-pointer'
                  : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 cursor-pointer'
              }`}
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{confirmText}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
