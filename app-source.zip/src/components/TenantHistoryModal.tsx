import React from 'react';
import { X, Calendar, Receipt, Trash2, Phone, MessageCircle, Pencil } from 'lucide-react';
import { PaymentRecord, TenantFinancialSnapshot, ThemeMode } from '../types';
import {
  formatCurrency,
  formatMonthName,
  getPaymentMethodNameAr,
  generateWhatsAppLink,
  sanitizePhoneForCall,
  getUnitDisplayTag,
} from '../utils/formatters';

interface TenantHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  snapshot: TenantFinancialSnapshot | null;
  allTenantPayments: PaymentRecord[];
  currency: string;
  onViewReceipt: (payment: PaymentRecord) => void;
  onEditPayment: (payment: PaymentRecord) => void;
  onDeletePayment: (paymentId: string) => void;
  theme: ThemeMode;
}

export const TenantHistoryModal: React.FC<TenantHistoryModalProps> = ({
  isOpen,
  onClose,
  snapshot,
  allTenantPayments,
  currency,
  onViewReceipt,
  onEditPayment,
  onDeletePayment,
  theme,
}) => {
  if (!isOpen || !snapshot) return null;

  const { tenant, buildingName, monthlyRent } = snapshot;

  const sortedPayments = [...allTenantPayments].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const totalHistoricalPaid = sortedPayments.reduce((acc, curr) => acc + curr.amount, 0);

  const unitTag = getUnitDisplayTag(tenant.unitNumber, tenant.unitType, tenant.customUnitType);

  const waUrl = generateWhatsAppLink(
    tenant.phone,
    tenant.name,
    unitTag,
    buildingName,
    snapshot.monthKey,
    snapshot.status,
    monthlyRent,
    snapshot.totalPaid,
    snapshot.balanceRemaining,
    currency
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-2xl border rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col transition-colors ${
          theme === 'dark'
            ? 'bg-[#151C28] border-neutral-700/80 text-white'
            : 'bg-white border-neutral-300 text-neutral-900'
        }`}
      >
        {/* Header */}
        <div
          className={`flex items-center justify-between px-6 py-4 border-b ${
            theme === 'dark' ? 'bg-[#121824] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <div>
            <span className="text-xs font-semibold text-amber-500">سجل الدفعات التراكمي</span>
            <h3 className="text-lg font-bold tracking-tight flex items-center gap-2">
              <span>{tenant.name}</span>
              <span className="text-neutral-400 font-normal">·</span>
              <span className="text-neutral-500 text-sm">
                {buildingName}{tenant.unitNumber?.trim() ? ` (${tenant.unitNumber})` : ''}
              </span>
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-700 dark:hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tenant Summary Pill & Quick Contacts */}
        <div
          className={`px-6 py-3 border-b flex flex-wrap items-center justify-between gap-3 text-xs ${
            theme === 'dark'
              ? 'bg-[#0F1520] border-neutral-800/80'
              : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <div className="flex items-center gap-4">
            <div>
              <span className="text-neutral-400 block">الإيجار الشهري:</span>
              <span className="font-bold font-mono">{formatCurrency(monthlyRent, currency)}</span>
            </div>
            <div>
              <span className="text-neutral-400 block">المسدد تاريخياً:</span>
              <span className="font-bold text-emerald-500 font-mono">
                {formatCurrency(totalHistoricalPaid, currency)}
              </span>
            </div>
            {tenant.securityDeposit > 0 && (
              <div>
                <span className="text-neutral-400 block">الضمان المحتجز:</span>
                <span className="font-bold text-sky-500 font-mono">
                  {formatCurrency(tenant.securityDeposit, currency)}
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            {sanitizePhoneForCall(tenant.phone) ? (
              <a
                href={`tel:${sanitizePhoneForCall(tenant.phone)}`}
                className={`px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 transition-colors cursor-pointer ${
                  theme === 'dark'
                    ? 'bg-neutral-800 border-neutral-700 text-neutral-200 hover:text-white'
                    : 'bg-white border-neutral-300 text-neutral-800 hover:bg-neutral-100'
                }`}
                title={`اتصال: ${tenant.phone}`}
              >
                <Phone className="w-3.5 h-3.5" />
                <span>اتصال</span>
              </a>
            ) : null}
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-500 font-bold border border-emerald-500/30 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>واتساب</span>
            </a>
          </div>
        </div>

        {/* Payments List */}
        <div className="p-6 overflow-y-auto space-y-3">
          {sortedPayments.length === 0 ? (
            <div className="text-center py-12 text-neutral-400 space-y-2">
              <Calendar className="w-10 h-10 mx-auto text-neutral-400" />
              <p className="text-sm">لا توجد دفعات مسجلة لهذا المستأجر حتى الآن.</p>
            </div>
          ) : (
            sortedPayments.map((p) => (
              <div
                key={p.id}
                className={`flex items-center justify-between p-4 rounded-xl border transition-all ${
                  theme === 'dark'
                    ? 'bg-[#0F1520] border-neutral-800/80 hover:border-neutral-700'
                    : 'bg-neutral-50 border-neutral-200 hover:border-neutral-300'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-amber-500 px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30">
                      شهر: {formatMonthName(p.monthKey)}
                    </span>
                    <span className="text-xs font-mono text-neutral-400">{p.receiptNumber}</span>
                  </div>
                  <div className="text-xs text-neutral-400 flex items-center gap-3">
                    <span>التاريخ: <strong className="font-semibold text-neutral-700 dark:text-neutral-300">{p.date}</strong></span>
                    <span>·</span>
                    <span>طريقة الدفع: <strong className="font-semibold text-neutral-700 dark:text-neutral-300">{getPaymentMethodNameAr(p.method)}</strong></span>
                    {p.referenceNumber && (
                      <>
                        <span>·</span>
                        <span>مرجع: <strong className="font-mono text-neutral-700 dark:text-neutral-300">{p.referenceNumber}</strong></span>
                      </>
                    )}
                  </div>
                  {p.notes && <div className="text-xs text-neutral-400 italic">ملاحظة: {p.notes}</div>}
                </div>

                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4 shrink-0">
                  <div className="text-left font-mono">
                    <span className="text-base font-black text-emerald-500 tabular-nums block">
                      {formatCurrency(p.amount, currency)}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 flex-wrap">
                    {/* زر تعديل مبلغ وتفاصيل الدفعة */}
                    <button
                      onClick={() => onEditPayment(p)}
                      className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95 ${
                        theme === 'dark'
                          ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 hover:bg-amber-500/25 hover:border-amber-400'
                          : 'bg-amber-50 border-amber-300 text-amber-900 hover:bg-amber-100'
                      }`}
                      title="تعديل مبلغ وتفاصيل هذه الدفعة"
                    >
                      <Pencil className="w-3.5 h-3.5 text-amber-500" />
                      <span>تعديل</span>
                    </button>

                    {/* زر سند القبض (أيقونة الورقة وحرف S/الـ $) */}
                    <button
                      onClick={() => onViewReceipt(p)}
                      className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95 ${
                        theme === 'dark'
                          ? 'bg-neutral-800/90 border-neutral-700 text-neutral-200 hover:text-white hover:bg-neutral-700'
                          : 'bg-neutral-100 border-neutral-300 text-neutral-800 hover:bg-neutral-200'
                      }`}
                      title="عرض وطباعة ومشاركة سند القبض الرسمي"
                    >
                      <Receipt className="w-3.5 h-3.5 text-emerald-500" />
                      <span>سند قبض</span>
                    </button>

                    {/* زر حذف الدفعة */}
                    <button
                      onClick={() => onDeletePayment(p.id)}
                      className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 border border-rose-500/20 text-xs font-bold transition-all cursor-pointer active:scale-95"
                      title="حذف هذه الدفعة نهائياً"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span className="hidden xs:inline">حذف</span>
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
