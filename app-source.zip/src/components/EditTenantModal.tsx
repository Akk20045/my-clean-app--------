import React, { useState, useEffect } from 'react';
import { X, Check, Trash2, Calendar } from 'lucide-react';
import { Building, Tenant, ThemeMode, UnitType } from '../types';

interface EditTenantModalProps {
  isOpen: boolean;
  onClose: () => void;
  tenant: Tenant | null;
  buildings: Building[];
  currency: string;
  onUpdateTenant: (updated: Tenant) => void;
  onDeleteTenant: (tenantId: string) => void;
  theme: ThemeMode;
}

export const EditTenantModal: React.FC<EditTenantModalProps> = ({
  isOpen,
  onClose,
  tenant,
  buildings,
  currency,
  onUpdateTenant,
  onDeleteTenant,
  theme,
}) => {
  // Hooks MUST be called unconditionally at top of component
  const [buildingId, setBuildingId] = useState<string>('');
  const [unitNumber, setUnitNumber] = useState<string>('');
  const [unitType, setUnitType] = useState<UnitType>('apartment');
  const [customUnitType, setCustomUnitType] = useState<string>('');
  const [name, setName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [monthlyRent, setMonthlyRent] = useState<number | ''>(350);
  const [securityDeposit, setSecurityDeposit] = useState<number | ''>('');
  const [leaseStart, setLeaseStart] = useState<string>('');
  const [leaseEnd, setLeaseEnd] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  useEffect(() => {
    if (tenant) {
      setBuildingId(tenant.buildingId);
      setUnitNumber(tenant.unitNumber || '');
      setUnitType(tenant.unitType);
      setCustomUnitType(tenant.customUnitType || '');
      setName(tenant.name);
      setPhone(tenant.phone);
      setMonthlyRent(tenant.monthlyRent);
      setSecurityDeposit(tenant.securityDeposit || '');
      setLeaseStart(tenant.leaseStart || '');
      setLeaseEnd(tenant.leaseEnd || '');
      setNotes(tenant.notes || '');
    }
  }, [tenant]);

  if (!isOpen || !tenant) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return; // unitNumber is optional
    const rentNum = typeof monthlyRent === 'number' ? monthlyRent : 0;
    if (rentNum <= 0) return;

    const depositNum = typeof securityDeposit === 'number' ? securityDeposit : 0;

    const updated: Tenant = {
      ...tenant,
      buildingId: buildingId || (buildings.length > 0 ? buildings[0].id : tenant.buildingId),
      unitNumber: unitNumber.trim(),
      unitType,
      customUnitType: unitType === 'other' ? customUnitType.trim() : undefined,
      name: name.trim(),
      phone: phone.trim(),
      monthlyRent: rentNum,
      securityDeposit: depositNum,
      depositStatus: depositNum > 0 ? 'held' : undefined,
      leaseStart: leaseStart.trim() || undefined,
      leaseEnd: leaseEnd.trim() || undefined,
      notes: notes.trim() || undefined,
    };

    onUpdateTenant(updated);
    onClose();
  };

  const handleDelete = () => {
    onDeleteTenant(tenant.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`relative w-full sm:max-w-xl border-t sm:border sm:rounded-2xl rounded-t-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col transition-colors ${
          theme === 'dark'
            ? 'bg-[#151C28] border-neutral-700/80 text-white'
            : 'bg-white border-neutral-300 text-neutral-900'
        }`}
      >
        {/* Header */}
        <div
          className={`flex items-center justify-between px-6 py-4 border-b ${
            theme === 'dark' ? 'bg-[#121824] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <div>
            <span className="text-xs font-semibold text-amber-500">تعديل بيانات الشقة والإيجار</span>
            <h3 className="text-lg font-bold tracking-tight">
              {tenant.unitNumber ? `${tenant.unitNumber} — ` : ''}{tenant.name}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-700 dark:hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto text-xs">
          {/* Building Selection */}
          <div className="space-y-1.5">
            <label className="block font-bold text-neutral-700 dark:text-neutral-300">
              العمارة التابع لها <span className="text-rose-500">*</span>
            </label>
            <select
              value={buildingId}
              onChange={(e) => setBuildingId(e.target.value)}
              className={`w-full py-2.5 px-3 rounded-xl border outline-none font-semibold cursor-pointer ${
                theme === 'dark'
                  ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                  : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
              }`}
            >
              {buildings.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name} ({b.location})
                </option>
              ))}
            </select>
          </div>

          {/* Unit Number & Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block font-bold text-neutral-700 dark:text-neutral-300">
                رقم أو مسمى الوحدة <span className="text-neutral-400 font-normal">(اختياري)</span>
              </label>
              <input
                type="text"
                placeholder="مثال: شقة 101، محل 2 (اختياري)"
                value={unitNumber}
                onChange={(e) => setUnitNumber(e.target.value)}
                className={`w-full py-2.5 px-3 rounded-xl border outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
              />
            </div>

            <div className="space-y-1">
              <label className="block font-bold text-neutral-700 dark:text-neutral-300">
                نوع العقار / الوحدة
              </label>
              <select
                value={unitType}
                onChange={(e) => setUnitType(e.target.value as UnitType)}
                className={`w-full py-2.5 px-3 rounded-xl border outline-none cursor-pointer ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
              >
                <option value="apartment">شقة سكنية (Apartment)</option>
                <option value="commercial_shop">محل تجاري (Commercial Shop)</option>
                <option value="office">مكتب أعمال (Office)</option>
                <option value="penthouse">بنتهاوس (Penthouse)</option>
                <option value="villa">فيلا مستقلة (Villa)</option>
                <option value="other">أخرى (مخصص)...</option>
              </select>
            </div>
          </div>

          {/* Custom Unit Type Name when 'other' is selected */}
          {unitType === 'other' && (
            <div className="space-y-1 animate-in fade-in duration-150">
              <label className="block font-bold text-amber-500 dark:text-amber-400">
                اكتب نوع الوحدة المخصص <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required={unitType === 'other'}
                placeholder="مثال: مستودع، كراج، استوديو، ملحق، معرض، صالة..."
                value={customUnitType}
                onChange={(e) => setCustomUnitType(e.target.value)}
                className={`w-full py-2.5 px-3 rounded-xl border outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-amber-500/50 text-white focus:border-amber-400'
                    : 'bg-amber-50/40 border-amber-300 text-neutral-900 focus:border-amber-500'
                }`}
              />
            </div>
          )}

          {/* Tenant Name & Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block font-bold text-neutral-700 dark:text-neutral-300">
                اسم المستأجر <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className={`w-full py-2.5 px-3 rounded-xl border outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
              />
            </div>

            <div className="space-y-1">
              <label className="block font-bold text-neutral-700 dark:text-neutral-300">
                رقم الهاتف (للاتصال والواتساب) <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className={`w-full py-2.5 px-3 rounded-xl border font-mono outline-none text-left ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
                dir="ltr"
              />
            </div>
          </div>

          {/* Monthly Rent & Security Deposit */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block font-bold text-neutral-700 dark:text-neutral-300">
                مبلغ الإيجار الشهري الكامل ({currency}) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="1"
                required
                value={monthlyRent}
                onChange={(e) =>
                  setMonthlyRent(e.target.value === '' ? '' : parseFloat(e.target.value))
                }
                className={`w-full py-2.5 px-3 rounded-xl border font-mono font-bold text-left outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
                dir="ltr"
              />
            </div>

            <div className="space-y-1">
              <label className="block font-bold text-sky-500">
                ضمان المحل / التأمين ({currency}) <span className="text-neutral-400 font-normal">(اختياري)</span>
              </label>
              <input
                type="number"
                min="0"
                placeholder="0"
                value={securityDeposit}
                onChange={(e) =>
                  setSecurityDeposit(e.target.value === '' ? '' : parseFloat(e.target.value))
                }
                className={`w-full py-2.5 px-3 rounded-xl border font-mono font-bold text-left outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-sky-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-sky-500'
                }`}
                dir="ltr"
              />
            </div>
          </div>

          {/* Lease Dates (Optional) */}
          <div
            className={`p-3.5 rounded-xl border space-y-2.5 ${
              theme === 'dark' ? 'bg-[#0F1520] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
            }`}
          >
            <div className="flex items-center gap-2 text-neutral-500 dark:text-neutral-400">
              <Calendar className="w-4 h-4 text-amber-500" />
              <span className="font-semibold text-xs">
                تواريخ العقد <span className="text-[11px] text-neutral-400 font-normal">(اختياري)</span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-neutral-500 dark:text-neutral-400">تاريخ بداية العقد</label>
                <input
                  type="date"
                  value={leaseStart}
                  onChange={(e) => setLeaseStart(e.target.value)}
                  className={`w-full py-2 px-3 rounded-xl border outline-none ${
                    theme === 'dark'
                      ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                      : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                  }`}
                />
              </div>
              <div className="space-y-1">
                <label className="block text-neutral-500 dark:text-neutral-400">تاريخ نهاية العقد</label>
                <input
                  type="date"
                  value={leaseEnd}
                  onChange={(e) => setLeaseEnd(e.target.value)}
                  className={`w-full py-2 px-3 rounded-xl border outline-none ${
                    theme === 'dark'
                      ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                      : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-1">
            <label className="block text-neutral-500">ملاحظات إضافية</label>
            <input
              type="text"
              placeholder="مثال: دفعة في نهاية الشهر، موقف سيارة خاص"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className={`w-full py-2 px-3 rounded-xl border outline-none ${
                theme === 'dark'
                  ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                  : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
              }`}
            />
          </div>

          {/* Footer actions */}
          <div
            className={`pt-4 flex items-center justify-between border-t ${
              theme === 'dark' ? 'border-neutral-800' : 'border-neutral-200'
            }`}
          >
            <button
              type="button"
              onClick={handleDelete}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-rose-500 hover:bg-rose-500/10 border border-rose-500/30 transition-colors font-bold cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>حذف الشقة</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className={`px-4 py-2 rounded-xl border font-semibold cursor-pointer ${
                  theme === 'dark'
                    ? 'border-neutral-700 text-neutral-300 hover:bg-neutral-800'
                    : 'border-neutral-300 text-neutral-700 hover:bg-neutral-100'
                }`}
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-bold shadow-md transition-all active:scale-95 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>حفظ التعديلات</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
