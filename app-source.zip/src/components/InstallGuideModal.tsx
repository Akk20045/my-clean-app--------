import React, { useState } from 'react';
import { X, Share, PlusSquare, Smartphone, CheckCircle2, ShieldCheck, Sparkles, Zap, HardDrive, Download, MoreVertical, WifiOff } from 'lucide-react';
import { ThemeMode } from '../types';

interface InstallGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: ThemeMode;
}

export const InstallGuideModal: React.FC<InstallGuideModalProps> = ({ isOpen, onClose, theme }) => {
  // Detect platform
  const isIOSDevice = typeof window !== 'undefined' && (/iphone|ipad|ipod/.test(navigator.userAgent.toLowerCase()) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1));
  const [platformTab, setPlatformTab] = useState<'android' | 'ios'>(isIOSDevice ? 'ios' : 'android');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200 overflow-y-auto">
      <div
        className={`relative w-full max-w-lg rounded-3xl border shadow-2xl p-5 sm:p-7 space-y-5 overflow-hidden my-auto ${
          theme === 'dark' ? 'bg-[#121824] border-neutral-800 text-white' : 'bg-white border-neutral-200 text-neutral-900'
        }`}
        dir="rtl"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className={`absolute top-4 left-4 p-2 rounded-full border transition-colors cursor-pointer ${
            theme === 'dark' ? 'bg-neutral-800/80 border-neutral-700 text-neutral-400 hover:text-white' : 'bg-neutral-100 border-neutral-200 text-neutral-600 hover:text-black'
          }`}
          title="إغلاق النافذة"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="text-center space-y-2 pt-1">
          <div className="inline-flex items-center justify-center w-13 h-13 rounded-2xl bg-gradient-to-tr from-amber-600 via-amber-500 to-amber-300 text-neutral-950 font-black text-xl shadow-lg shadow-amber-500/20">
            <span>تحصيل</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black">
            تثبيت واستخدام التطبيق كـ <span className="text-amber-500">تطبيق مستقل (APK / PWA)</span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 max-w-md mx-auto leading-relaxed">
            يعمل تطبيق <strong>تحصيل</strong> كتطبيق أصيل دون الحاجة لمتصفح، مع إمكانية إضافة وحذف العمارات والمستأجرين وحساب الإيجارات بالكامل <strong className="text-amber-400">بدون اتصال بالإنترنت (أوفلاين)</strong>.
          </p>
        </div>

        {/* Platform Tabs */}
        <div className="flex items-center p-1 rounded-2xl border bg-black/10 border-neutral-700/30 gap-1">
          <button
            onClick={() => setPlatformTab('android')}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              platformTab === 'android'
                ? 'bg-amber-500 text-neutral-950 shadow-md font-extrabold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>أندرويد (Android / APK)</span>
          </button>
          <button
            onClick={() => setPlatformTab('ios')}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              platformTab === 'ios'
                ? 'bg-amber-500 text-neutral-950 shadow-md font-extrabold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>آيفون وآيباد (iOS)</span>
          </button>
        </div>

        {/* Tab 1: Android Guide */}
        {platformTab === 'android' && (
          <div className="space-y-3">
            <div
              className={`p-3.5 rounded-2xl border flex items-start gap-3 transition-colors ${
                theme === 'dark' ? 'bg-[#17202F] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
              }`}
            >
              <div className="w-7 h-7 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-500 flex items-center justify-center font-bold text-xs shrink-0">
                1
              </div>
              <div className="space-y-1">
                <div className="font-bold text-xs sm:text-sm">
                  افتح الرابط في متصفح Chrome على هاتفك
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  اضغط على زر القائمة <MoreVertical className="w-3.5 h-3.5 inline text-amber-400 mx-0.5" /> (النقاط الثلاث في الزاوية العلوية).
                </p>
              </div>
            </div>

            <div
              className={`p-3.5 rounded-2xl border flex items-start gap-3 transition-colors ${
                theme === 'dark' ? 'bg-[#17202F] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
              }`}
            >
              <div className="w-7 h-7 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-500 flex items-center justify-center font-bold text-xs shrink-0">
                2
              </div>
              <div className="space-y-1">
                <div className="font-bold text-xs sm:text-sm">
                  اختر "تثبيت التطبيق" (Install App)
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  أو اختر "إضافة إلى الشاشة الرئيسية". سيقوم نظام أندرويد بتثبيت حزمة WebAPK كاملة على هاتفك مع أيقونة التطبيق.
                </p>
              </div>
            </div>

            <div
              className={`p-3.5 rounded-2xl border flex items-start gap-3 transition-colors ${
                theme === 'dark' ? 'bg-[#17202F] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
              }`}
            >
              <div className="w-7 h-7 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-500 flex items-center justify-center font-bold text-xs shrink-0">
                3
              </div>
              <div className="space-y-1">
                <div className="font-bold text-xs sm:text-sm">
                  افتح التطبيق في أي وقت بدون إنترنت
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  يمكنك استخدامه حتى في وضع الطيران! يمكنك إضافة وحذف وتعديل البيانات وحساب الإيجارات وسندات القبض ويتم الحفظ مباشرة على هاتفك.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: iOS Guide */}
        {platformTab === 'ios' && (
          <div className="space-y-3">
            <div
              className={`p-3.5 rounded-2xl border flex items-start gap-3 transition-colors ${
                theme === 'dark' ? 'bg-[#17202F] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
              }`}
            >
              <div className="w-7 h-7 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-500 flex items-center justify-center font-bold text-xs shrink-0">
                1
              </div>
              <div className="space-y-1">
                <div className="font-bold text-xs sm:text-sm">
                  افتح الرابط في متصفح سفاري (Safari)
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  اضغط على زر المشاركة <Share className="w-3.5 h-3.5 inline text-sky-400 mx-1" /> في شريط أدوات سفاري.
                </p>
              </div>
            </div>

            <div
              className={`p-3.5 rounded-2xl border flex items-start gap-3 transition-colors ${
                theme === 'dark' ? 'bg-[#17202F] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
              }`}
            >
              <div className="w-7 h-7 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-500 flex items-center justify-center font-bold text-xs shrink-0">
                2
              </div>
              <div className="space-y-1">
                <div className="font-bold text-xs sm:text-sm">
                  اختر "إضافة إلى الشاشة الرئيسية"
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed flex items-center gap-1 flex-wrap">
                  اختر خيار
                  <span className="inline-flex items-center gap-1 font-bold text-neutral-200 px-1.5 py-0.5 rounded-md bg-neutral-800 border border-neutral-700">
                    <PlusSquare className="w-3 h-3 text-amber-400" /> إضافة إلى الشاشة الرئيسية (Add to Home Screen)
                  </span>
                </p>
              </div>
            </div>

            <div
              className={`p-3.5 rounded-2xl border flex items-start gap-3 transition-colors ${
                theme === 'dark' ? 'bg-[#17202F] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
              }`}
            >
              <div className="w-7 h-7 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-500 flex items-center justify-center font-bold text-xs shrink-0">
                3
              </div>
              <div className="space-y-1">
                <div className="font-bold text-xs sm:text-sm">
                  اضغط "إضافة" (Add) في الزاوية
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  سيظهر التطبيق كأيقونة مستقلة على شاشة هاتفك ويعمل بملء الشاشة وبكامل ميزاته أوفلاين.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Benefits Box */}
        <div
          className={`p-3 rounded-2xl border flex flex-col sm:flex-row items-center justify-between gap-2.5 text-xs ${
            theme === 'dark' ? 'bg-amber-950/20 border-amber-500/20 text-amber-200/90' : 'bg-amber-50 border-amber-200 text-amber-900'
          }`}
        >
          <div className="flex items-center gap-1.5">
            <WifiOff className="w-4 h-4 text-amber-500 shrink-0" />
            <span className="font-semibold text-[11px]">يعمل 100% بدون إنترنت (أوفلاين كامل)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <HardDrive className="w-4 h-4 text-amber-500 shrink-0" />
            <span className="font-semibold text-[11px]">حفظ تلقائي وفوري على جهازك</span>
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={onClose}
          className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-black text-xs sm:text-sm shadow-lg transition-all active:scale-98 cursor-pointer"
        >
          حسناً، فهمت
        </button>
      </div>
    </div>
  );
};
