import React from 'react';
import { Building2, MapPin, Plus, Trash2, Pencil } from 'lucide-react';
import { Building, TenantFinancialSnapshot, ThemeMode } from '../types';
import { TenantCard } from './TenantCard';
import { formatCurrency } from '../utils/formatters';
import { isDarkTheme, getThemeConfig } from '../utils/theme';

interface BuildingSectionProps {
  building: Building;
  snapshots: TenantFinancialSnapshot[];
  currency: string;
  onRecordPayment: (tenantId: string) => void;
  onViewHistory: (tenantId: string) => void;
  onEditTenant: (tenantId: string) => void;
  onDeleteTenant: (tenantId: string) => void;
  onAddUnitToBuilding: (buildingId: string) => void;
  onEditBuilding: (buildingId: string) => void;
  onDeleteBuilding: (buildingId: string) => void;
  theme: ThemeMode;
}

export const BuildingSection: React.FC<BuildingSectionProps> = ({
  building,
  snapshots,
  currency,
  onRecordPayment,
  onViewHistory,
  onEditTenant,
  onDeleteTenant,
  onAddUnitToBuilding,
  onEditBuilding,
  onDeleteBuilding,
  theme,
}) => {
  const isDark = isDarkTheme(theme);
  const themeConfig = getThemeConfig(theme);
  const totalRent = snapshots.reduce((acc, curr) => acc + curr.monthlyRent, 0);
  const totalPaid = snapshots.reduce((acc, curr) => acc + curr.totalPaid, 0);
  const buildingRate = totalRent > 0 ? Math.round((totalPaid / totalRent) * 100) : 0;

  return (
    <div
      className={`rounded-3xl border p-5 sm:p-6 space-y-5 transition-all shadow-md ${themeConfig.bgCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
    >
      {/* Building Master Header */}
      <div className={`flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b ${themeConfig.borderCard}`}>
        <div className="flex items-start sm:items-center gap-3.5">
          <div
            className={`p-3 rounded-2xl border shrink-0 ${themeConfig.bgSubCard} ${themeConfig.borderCard} text-amber-500`}
          >
            <Building2 className="w-6 h-6" />
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg sm:text-xl font-extrabold tracking-tight">
                {building.name}
              </h2>
              <span
                className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${themeConfig.bgSubCard} ${themeConfig.borderCard} border`}
              >
                {snapshots.length} {snapshots.length === 1 ? 'وحدة / شقة' : 'وحدات / شقق'}
              </span>
            </div>

            <div className={`flex items-center gap-1.5 text-xs mt-1 ${themeConfig.subTextColor}`}>
              <MapPin className="w-3.5 h-3.5 text-amber-500" />
              <span>{building.location}</span>
              {building.notes && (
                <>
                  <span>·</span>
                  <span>{building.notes}</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Right side: Financial snapshot + Actions */}
        <div className="flex flex-wrap items-center gap-2.5 justify-between md:justify-end">
          {snapshots.length > 0 && (
            <div
              className={`flex items-center gap-4 px-3.5 py-2 rounded-xl border text-xs ${themeConfig.bgSubCard} ${themeConfig.borderCard}`}
            >
              <div>
                <span className={`block text-[10px] ${themeConfig.subTextColor}`}>مجموع الإيجارات:</span>
                <span className="font-bold font-mono tabular-nums text-sm">
                  {formatCurrency(totalRent, currency)}
                </span>
              </div>
              <div className={`h-6 w-px ${themeConfig.borderCard} bg-current opacity-20`} />
              <div>
                <span className={`block text-[10px] ${themeConfig.subTextColor}`}>المحصل:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400 font-mono tabular-nums text-sm">
                  {formatCurrency(totalPaid, currency)}{' '}
                  <span className="text-[11px] font-normal">({buildingRate}%)</span>
                </span>
              </div>
            </div>
          )}

          <div className="flex items-center gap-1.5">
            {/* Direct Add Apartment / Tenant to this building */}
            <button
              onClick={() => onAddUnitToBuilding(building.id)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-bold text-xs shadow-sm transition-all active:scale-95 whitespace-nowrap cursor-pointer"
              title="إضافة شقة جديدة تابعة لهذه العمارة"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ إضافة شقة</span>
            </button>

            {/* Edit Building Button */}
            <button
              onClick={() => onEditBuilding(building.id)}
              className={`p-2 rounded-xl border transition-colors cursor-pointer ${themeConfig.bgSubCard} ${themeConfig.borderCard} hover:border-amber-500/60`}
              title="تعديل اسم وموقع وبيانات العمارة"
            >
              <Pencil className="w-4 h-4" />
            </button>

            {/* Delete Building Button */}
            <button
              onClick={() => onDeleteBuilding(building.id)}
              className="p-2 rounded-xl border border-rose-500/30 text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
              title="حذف العمارة بالكامل"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Nested Apartments and Units */}
      {snapshots.length === 0 ? (
        <div
          onClick={() => onAddUnitToBuilding(building.id)}
          className={`p-8 rounded-2xl border-2 border-dashed text-center cursor-pointer transition-all ${themeConfig.bgSubCard} ${themeConfig.borderCard} hover:border-amber-500/60`}
        >
          <Plus className="w-8 h-8 mx-auto text-amber-500 mb-2 opacity-80" />
          <h4 className="text-sm font-bold">
            العمارة مضافة ولكن لا توجد شقق أو محلات مسجلة فيها حتى الآن
          </h4>
          <p className={`text-xs mt-1 ${themeConfig.subTextColor}`}>
            اضغط هنا لإضافة أول شقة، اسم المستأجر ومبلغ الإيجار التابع لهذه العمارة
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {snapshots.map((snapshot) => (
            <TenantCard
              key={snapshot.tenant.id}
              snapshot={snapshot}
              currency={currency}
              onRecordPayment={onRecordPayment}
              onViewHistory={onViewHistory}
              onEditTenant={onEditTenant}
              onDeleteTenant={onDeleteTenant}
              theme={theme}
            />
          ))}
        </div>
      )}
    </div>
  );
};
