import React, { useState } from 'react';
import {
  Phone,
  MessageCircle,
  PlusCircle,
  History,
  ArrowUpDown,
  Shield,
  FileSpreadsheet,
  FileText,
  Printer,
  Pencil,
  Trash2,
  SlidersHorizontal,
} from 'lucide-react';
import { TenantFinancialSnapshot, ThemeMode } from '../types';
import { isDarkTheme, getThemeConfig } from '../utils/theme';
import {
  formatCurrency,
  generateWhatsAppLink,
  sanitizePhoneForCall,
  getUnitTypeLabel,
  getUnitDisplayTag,
} from '../utils/formatters';

interface ExecutiveTableProps {
  snapshots: TenantFinancialSnapshot[];
  currency: string;
  onRecordPayment: (tenantId: string) => void;
  onViewHistory: (tenantId: string) => void;
  onEditTenant: (tenantId: string) => void;
  onDeleteTenant?: (tenantId: string) => void;
  onOpenBulkEditModal?: () => void;
  onExportExcel: () => void;
  onExportWord?: () => void;
  onOpenPdfReport?: () => void;
  theme: ThemeMode;
}

type SortField = 'unit' | 'tenant' | 'building' | 'rent' | 'paid' | 'remaining' | 'status';
type SortOrder = 'asc' | 'desc';

export const ExecutiveTable: React.FC<ExecutiveTableProps> = ({
  snapshots,
  currency,
  onRecordPayment,
  onViewHistory,
  onEditTenant,
  onDeleteTenant,
  onOpenBulkEditModal,
  onExportExcel,
  onExportWord,
  onOpenPdfReport,
  theme,
}) => {
  const [sortField, setSortField] = useState<SortField>('building');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const [isCompact, setIsCompact] = useState<boolean>(false);
  const isDark = isDarkTheme(theme);
  const themeConfig = getThemeConfig(theme);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const sortedSnapshots = [...snapshots].sort((a, b) => {
    let comparison = 0;
    switch (sortField) {
      case 'unit':
        comparison = (a.tenant.unitNumber || '').localeCompare(b.tenant.unitNumber || '', 'ar');
        break;
      case 'tenant':
        comparison = a.tenant.name.localeCompare(b.tenant.name, 'ar');
        break;
      case 'building':
        comparison = a.buildingName.localeCompare(b.buildingName, 'ar');
        break;
      case 'rent':
        comparison = a.monthlyRent - b.monthlyRent;
        break;
      case 'paid':
        comparison = a.totalPaid - b.totalPaid;
        break;
      case 'remaining':
        comparison = a.balanceRemaining - b.balanceRemaining;
        break;
      case 'status':
        const order = { unpaid: 1, partial: 2, paid: 3 };
        comparison = order[a.status] - order[b.status];
        break;
      default:
        comparison = 0;
    }
    return sortOrder === 'asc' ? comparison : -comparison;
  });

  // Calculate Excel-style column totals
  const totalMonthlyRent = snapshots.reduce((acc, s) => acc + s.monthlyRent, 0);
  const totalPaid = snapshots.reduce((acc, s) => acc + s.totalPaid, 0);
  const totalRemaining = snapshots.reduce((acc, s) => acc + s.balanceRemaining, 0);
  const totalDeposits = snapshots.reduce((acc, s) => acc + (s.tenant.securityDeposit || 0), 0);
  const overallCollectionRate =
    totalMonthlyRent > 0 ? Math.round((totalPaid / totalMonthlyRent) * 100) : 0;

  const getStatusBadge = (status: 'paid' | 'partial' | 'unpaid', remaining: number) => {
    switch (status) {
      case 'paid':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-500 border border-emerald-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            مسدد بالكامل
          </span>
        );
      case 'partial':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-500 border border-amber-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            جزئي (متبقي {formatCurrency(remaining, currency)})
          </span>
        );
      case 'unpaid':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-500 border border-rose-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
            غير مسدد
          </span>
        );
    }
  };

  return (
    <div
      className={`rounded-2xl border shadow-lg overflow-hidden transition-colors ${themeConfig.bgCard} ${themeConfig.borderCard} ${themeConfig.textColor}`}
    >
      {/* Table Header Bar with Excel/Word/PDF Export & Density switch */}
      <div
        className={`px-5 py-3 border-b flex flex-wrap items-center justify-between gap-3 ${themeConfig.bgHeader} ${themeConfig.borderCard}`}
      >
        <div className="flex items-center gap-2">
          <FileSpreadsheet className="w-4 h-4 text-emerald-500" />
          <span className="text-xs font-bold tracking-wide">
            جدول السجل المالي التفاعلي (Excel Ledger Sheet)
          </span>
          <span className="text-[11px] text-neutral-400">({snapshots.length} سجلات)</span>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsCompact(!isCompact)}
            className={`px-2.5 py-1 text-xs rounded-lg border transition-colors cursor-pointer ${
              isDark
                ? 'border-neutral-700 bg-neutral-800/80 text-neutral-300 hover:text-white'
                : 'border-neutral-300 bg-white text-neutral-700 hover:bg-neutral-100'
            }`}
          >
            {isCompact ? 'عرض مريح' : 'عرض مضغوط (إكسل)'}
          </button>

          {onOpenBulkEditModal && (
            <button
              onClick={onOpenBulkEditModal}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold rounded-lg border transition-all active:scale-95 cursor-pointer ${
                isDark
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 hover:bg-amber-500/25'
                  : 'bg-amber-50 border-amber-300 text-amber-900 hover:bg-amber-100'
              }`}
              title="تعديل نوع الوحدات دفعة واحدة (تحديد جماعي)"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-amber-500" />
              <span>تعديل نوع الوحدات</span>
            </button>
          )}

          <button
            onClick={onExportExcel}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-bold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs transition-all active:scale-95 cursor-pointer"
            title="تصدير جدول البيانات الحالي إلى ملف Excel"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>إكسل (.xls)</span>
          </button>

          {onExportWord && (
            <button
              onClick={onExportWord}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-bold rounded-lg bg-sky-600 hover:bg-sky-500 text-white shadow-xs transition-all active:scale-95 cursor-pointer"
              title="تصدير جدول البيانات الحالي إلى ملف Word"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>وورد (.doc)</span>
            </button>
          )}

          {onOpenPdfReport && (
            <button
              onClick={onOpenPdfReport}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-bold rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 shadow-xs transition-all active:scale-95 cursor-pointer"
              title="طباعة أو حفظ تقرير PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة / PDF</span>
            </button>
          )}
        </div>
      </div>

      {/* Spreadsheet Table Container */}
      <div className="overflow-x-auto">
        <table className="w-full text-right border-collapse text-xs sm:text-sm">
          <thead>
            <tr
              className={`border-b text-xs font-bold select-none ${themeConfig.bgSubCard} ${themeConfig.borderCard}`}
            >
              <th
                className="py-3 px-4 cursor-pointer hover:text-amber-500 transition-colors"
                onClick={() => handleSort('unit')}
              >
                <div className="flex items-center gap-1.5">
                  <span>الوحدة / العقار</span>
                  <ArrowUpDown className="w-3 h-3 text-neutral-400" />
                </div>
              </th>
              <th
                className="py-3 px-4 cursor-pointer hover:text-amber-500 transition-colors"
                onClick={() => handleSort('tenant')}
              >
                <div className="flex items-center gap-1.5">
                  <span>اسم المستأجر</span>
                  <ArrowUpDown className="w-3 h-3 text-neutral-400" />
                </div>
              </th>
              <th className="py-3 px-3 text-center">التواصل</th>
              <th
                className="py-3 px-4 text-left cursor-pointer hover:text-amber-500 transition-colors"
                onClick={() => handleSort('rent')}
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>الإيجار الشهري</span>
                  <ArrowUpDown className="w-3 h-3 text-neutral-400" />
                </div>
              </th>
              <th
                className="py-3 px-4 text-left cursor-pointer hover:text-amber-500 transition-colors"
                onClick={() => handleSort('paid')}
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>المدفوع</span>
                  <ArrowUpDown className="w-3 h-3 text-neutral-400" />
                </div>
              </th>
              <th
                className="py-3 px-4 text-left cursor-pointer hover:text-amber-500 transition-colors"
                onClick={() => handleSort('remaining')}
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>المتبقي</span>
                  <ArrowUpDown className="w-3 h-3 text-neutral-400" />
                </div>
              </th>
              <th
                className="py-3 px-4 cursor-pointer hover:text-amber-500 transition-colors"
                onClick={() => handleSort('status')}
              >
                <div className="flex items-center gap-1.5">
                  <span>حالة السداد</span>
                  <ArrowUpDown className="w-3 h-3 text-neutral-400" />
                </div>
              </th>
              <th className="py-3 px-4">ضمان المحل</th>
              <th className="py-3 px-4 text-center">الإجراءات والعمليات</th>
            </tr>
          </thead>

          <tbody
            className={`divide-y ${themeConfig.borderCard}`}
          >
            {sortedSnapshots.map((snapshot, index) => {
              const {
                tenant,
                buildingName,
                monthlyRent,
                totalPaid,
                balanceRemaining,
                percentagePaid,
                status,
                monthKey,
              } = snapshot;

              const unitTag = getUnitDisplayTag(tenant.unitNumber, tenant.unitType, tenant.customUnitType);
              const typeLabel = getUnitTypeLabel(tenant.unitType, tenant.customUnitType);

              const waUrl = generateWhatsAppLink(
                tenant.phone,
                tenant.name,
                unitTag,
                buildingName,
                monthKey,
                status,
                monthlyRent,
                totalPaid,
                balanceRemaining,
                currency
              );

              return (
                <tr
                  key={tenant.id}
                  className={`transition-colors ${
                    index % 2 === 0
                      ? themeConfig.bgCard
                      : themeConfig.bgSubCard
                  }`}
                >
                  {/* Unit & Building */}
                  <td className={`${isCompact ? 'py-2 px-4' : 'py-3.5 px-4'}`}>
                    <div className="font-bold tracking-tight flex items-center gap-1.5 flex-wrap">
                      <span>{tenant.unitNumber?.trim() ? tenant.unitNumber : tenant.name}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-500 border border-amber-500/20 font-normal">
                        {typeLabel}
                      </span>
                    </div>
                    <div className="text-[11px] text-neutral-400 truncate max-w-[170px]">
                      {buildingName}
                    </div>
                  </td>

                  {/* Tenant Name */}
                  <td className={`${isCompact ? 'py-2 px-4' : 'py-3.5 px-4'}`}>
                    <div className="font-semibold">{tenant.name}</div>
                    <div className="text-[11px] text-neutral-400 font-mono" dir="ltr">
                      {tenant.phone}
                    </div>
                  </td>

                  {/* Quick Contact Buttons */}
                  <td className="py-2 px-3 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      {sanitizePhoneForCall(tenant.phone) ? (
                        <a
                          href={`tel:${sanitizePhoneForCall(tenant.phone)}`}
                          className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                            isDark
                              ? 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white'
                              : 'bg-neutral-100 border-neutral-300 text-neutral-700 hover:bg-neutral-200'
                          }`}
                          title={`اتصال هاتفياً: ${tenant.phone}`}
                        >
                          <Phone className="w-3.5 h-3.5" />
                        </a>
                      ) : (
                        <button
                          disabled
                          className="p-1.5 rounded-lg border border-neutral-800 text-neutral-600 opacity-50 cursor-not-allowed"
                          title="لا يوجد رقم هاتف"
                        >
                          <Phone className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <a
                        href={waUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-500 border border-emerald-500/30 transition-colors cursor-pointer"
                        title="مراسلة عبر واتساب"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </td>

                  {/* Monthly Rent */}
                  <td className="py-2 px-4 text-left font-mono tabular-nums font-bold">
                    {formatCurrency(monthlyRent, currency)}
                  </td>

                  {/* Paid */}
                  <td className="py-2 px-4 text-left font-mono tabular-nums font-bold text-emerald-500">
                    {formatCurrency(totalPaid, currency)}
                  </td>

                  {/* Remaining */}
                  <td className="py-2 px-4 text-left font-mono tabular-nums font-bold">
                    <span
                      className={
                        balanceRemaining > 0
                          ? 'text-rose-500 font-extrabold'
                          : 'text-neutral-400'
                      }
                    >
                      {formatCurrency(balanceRemaining, currency)}
                    </span>
                  </td>

                  {/* Status & Mini progress bar */}
                  <td className="py-2 px-4">
                    <div className="space-y-1">
                      {getStatusBadge(status, balanceRemaining)}
                      <div
                        className={`w-20 h-1 rounded-full overflow-hidden ${
                          isDark ? 'bg-neutral-800' : 'bg-neutral-200'
                        }`}
                      >
                        <div
                          className={`h-full ${
                            percentagePaid >= 100
                              ? 'bg-emerald-500'
                              : percentagePaid > 0
                              ? 'bg-amber-500'
                              : 'bg-rose-500'
                          }`}
                          style={{ width: `${percentagePaid}%` }}
                        />
                      </div>
                    </div>
                  </td>

                  {/* Commercial Deposit */}
                  <td className="py-2 px-4 text-xs font-mono tabular-nums">
                    {tenant.securityDeposit > 0 ? (
                      <span className="inline-flex items-center gap-1 text-sky-500 bg-sky-500/10 border border-sky-500/30 px-2 py-0.5 rounded-md font-semibold">
                        <Shield className="w-3 h-3 text-sky-500" />
                        {formatCurrency(tenant.securityDeposit, currency)}
                      </span>
                    ) : (
                      <span className="text-neutral-400">—</span>
                    )}
                  </td>

                  {/* Actions */}
                  <td className="py-2 px-4 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => onRecordPayment(tenant.id)}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold transition-all active:scale-95 shadow-xs whitespace-nowrap cursor-pointer"
                        title="تسجيل دفعة إيجار"
                      >
                        <PlusCircle className="w-3.5 h-3.5" />
                        <span>دفعة</span>
                      </button>

                      <button
                        onClick={() => onViewHistory(tenant.id)}
                        className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                          isDark
                            ? 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white'
                            : 'bg-neutral-100 border-neutral-300 text-neutral-700 hover:bg-neutral-200'
                        }`}
                        title="سجل الدفعات التراكمي"
                      >
                        <History className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => onEditTenant(tenant.id)}
                        className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                          isDark
                            ? 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-amber-400'
                            : 'bg-neutral-100 border-neutral-300 text-neutral-700 hover:text-amber-600'
                        }`}
                        title="تعديل بيانات الشقة والإيجار والمستأجر"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>

                      {onDeleteTenant && (
                        <button
                          onClick={() => onDeleteTenant(tenant.id)}
                          className="p-1.5 rounded-lg border border-rose-500/25 text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
                          title="حذف الشقة / المستأجر"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>

          {/* Excel-style Total Summary Row */}
          <tfoot>
            <tr
              className={`border-t-2 font-bold text-xs ${themeConfig.bgHeader} ${themeConfig.borderCard}`}
            >
              <td className="py-3 px-4">
                <span>الإجمالي العام (Total)</span>
              </td>
              <td className="py-3 px-4 text-neutral-400">
                <span>{snapshots.length} عقارات</span>
              </td>
              <td className="py-3 px-3"></td>
              <td className="py-3 px-4 text-left font-mono tabular-nums text-sm font-extrabold">
                {formatCurrency(totalMonthlyRent, currency)}
              </td>
              <td className="py-3 px-4 text-left font-mono tabular-nums text-sm font-extrabold text-emerald-500">
                {formatCurrency(totalPaid, currency)}
              </td>
              <td className="py-3 px-4 text-left font-mono tabular-nums text-sm font-extrabold text-rose-500">
                {formatCurrency(totalRemaining, currency)}
              </td>
              <td className="py-3 px-4">
                <span className="text-xs font-semibold">
                  تحصيل: {overallCollectionRate}%
                </span>
              </td>
              <td className="py-3 px-4 font-mono tabular-nums text-sky-500">
                {formatCurrency(totalDeposits, currency)}
              </td>
              <td className="py-3 px-4 text-center">
                <button
                  onClick={onExportExcel}
                  className="text-[11px] underline font-semibold text-emerald-600 hover:text-emerald-500 cursor-pointer"
                >
                  حفظ كإكسل
                </button>
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
};
