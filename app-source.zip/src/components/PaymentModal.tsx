import React, { useState, useEffect } from 'react';
import { X, Check, CreditCard, Banknote, Landmark, FileText } from 'lucide-react';
import { PaymentMethod, PaymentRecord, TenantFinancialSnapshot, ThemeMode } from '../types';
import { formatCurrency, formatMonthName, generateReceiptNumber } from '../utils/formatters';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  snapshot: TenantFinancialSnapshot | null;
  currency: string;
  onSavePayment: (payment: PaymentRecord) => void;
  onOpenReceipt: (payment: PaymentRecord, snapshot: TenantFinancialSnapshot) => void;
  theme: ThemeMode;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  snapshot,
  currency,
  onSavePayment,
  onOpenReceipt,
  theme,
}) => {
  // Hooks MUST be called unconditionally at top of component
  const [amount, setAmount] = useState<number>(350);
  const [method, setMethod] = useState<PaymentMethod>('cliq');
  const [date, setDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [referenceNumber, setReferenceNumber] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [generateReceiptNow, setGenerateReceiptNow] = useState<boolean>(true);

  useEffect(() => {
    if (snapshot) {
      setAmount(snapshot.balanceRemaining > 0 ? snapshot.balanceRemaining : snapshot.monthlyRent);
      setReferenceNumber('');
      setNotes('');
    }
  }, [snapshot]);

  if (!isOpen || !snapshot) return null;

  const { tenant, buildingName, monthlyRent, totalPaid, balanceRemaining, monthKey } = snapshot;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0) return;

    const receiptNumber = generateReceiptNumber(tenant.id, monthKey);
    const newPayment: PaymentRecord = {
      id: `p-${Date.now()}`,
      tenantId: tenant.id,
      monthKey,
      amount,
      date,
      method,
      referenceNumber: referenceNumber.trim() || undefined,
      receiptNumber,
      notes: notes.trim() || undefined,
      createdAt: new Date().toISOString(),
    };

    onSavePayment(newPayment);

    if (generateReceiptNow) {
      onOpenReceipt(newPayment, {
        ...snapshot,
        totalPaid: totalPaid + amount,
        balanceRemaining: Math.max(0, monthlyRent - (totalPaid + amount)),
        percentagePaid: Math.min(100, Math.round(((totalPaid + amount) / monthlyRent) * 100)),
        status: totalPaid + amount >= monthlyRent ? 'paid' : 'partial',
      });
    }

    onClose();
  };

  const handleShortcutAmount = (val: number) => {
    setAmount(val);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`relative w-full sm:max-w-md border-t sm:border sm:rounded-2xl rounded-t-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col transition-colors ${
          theme === 'dark'
            ? 'bg-[#151C28] border-neutral-700/80 text-white'
            : 'bg-white border-neutral-300 text-neutral-900'
        }`}
      >
        {/* Header */}
        <div
          className={`flex items-center justify-between px-6 py-4 border-b ${
            theme === 'dark' ? 'bg-[#121824] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <div>
            <span className="text-xs font-semibold text-amber-500">تسجيل دفعة إيجار</span>
            <h3 className="text-base font-extrabold tracking-tight flex items-center gap-1.5 flex-wrap">
              {tenant.unitNumber?.trim() ? (
                <>
                  <span>{tenant.unitNumber}</span>
                  <span className="text-neutral-400">·</span>
                </>
              ) : null}
              <span className="text-sm font-semibold">{tenant.name}</span>
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-700 dark:hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs overflow-y-auto">
          {/* Target Month & Current Status */}
          <div
            className={`p-3 rounded-xl border flex items-center justify-between ${
              theme === 'dark' ? 'bg-[#0F1520] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
            }`}
          >
            <div>
              <span className="text-neutral-400 block text-[10px]">استحقاق شهر:</span>
              <span className="text-xs font-bold text-amber-500">
                {formatMonthName(monthKey)}
              </span>
            </div>
            <div className="text-left">
              <span className="text-neutral-400 block text-[10px]">المتبقي المطلوب:</span>
              <span className="text-xs font-bold text-rose-500 font-mono tabular-nums">
                {formatCurrency(balanceRemaining, currency)}
              </span>
            </div>
          </div>

          {/* Amount Paid with quick shortcuts */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block font-bold text-neutral-700 dark:text-neutral-300">
                المبلغ المدفوع الآن ({currency}) <span className="text-rose-500">*</span>
              </label>
              <div className="flex items-center gap-1.5">
                {balanceRemaining > 0 && balanceRemaining !== monthlyRent && (
                  <button
                    type="button"
                    onClick={() => handleShortcutAmount(balanceRemaining)}
                    className="text-[11px] text-amber-600 dark:text-amber-400 hover:underline font-bold cursor-pointer"
                  >
                    المتبقي ({balanceRemaining})
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => handleShortcutAmount(monthlyRent)}
                  className="text-[11px] text-neutral-500 hover:underline cursor-pointer"
                >
                  كامل الإيجار ({monthlyRent})
                </button>
              </div>
            </div>

            <div className="relative">
              <input
                type="number"
                min="1"
                step="any"
                required
                value={amount || ''}
                onChange={(e) =>
                  setAmount(e.target.value === '' ? 0 : parseFloat(e.target.value))
                }
                className={`w-full py-2.5 px-3 rounded-xl border font-mono text-lg font-bold tabular-nums outline-none text-left ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
                dir="ltr"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 font-bold text-amber-500 pointer-events-none">
                {currency}
              </span>
            </div>
          </div>

          {/* Payment Method */}
          <div className="space-y-1.5">
            <label className="block font-bold text-neutral-700 dark:text-neutral-300">
              طريقة الدفع
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setMethod('cliq')}
                className={`flex items-center justify-center p-2.5 rounded-xl border font-bold gap-1.5 transition-all cursor-pointer ${
                  method === 'cliq'
                    ? 'bg-amber-500/15 border-amber-500 text-amber-600 dark:text-amber-300'
                    : theme === 'dark'
                    ? 'bg-[#0F1520] border-neutral-800 text-neutral-400'
                    : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                }`}
              >
                <CreditCard className="w-4 h-4" />
                <span>كليك (CliQ)</span>
              </button>

              <button
                type="button"
                onClick={() => setMethod('cash')}
                className={`flex items-center justify-center p-2.5 rounded-xl border font-bold gap-1.5 transition-all cursor-pointer ${
                  method === 'cash'
                    ? 'bg-amber-500/15 border-amber-500 text-amber-600 dark:text-amber-300'
                    : theme === 'dark'
                    ? 'bg-[#0F1520] border-neutral-800 text-neutral-400'
                    : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                }`}
              >
                <Banknote className="w-4 h-4" />
                <span>نقداً (كاش)</span>
              </button>

              <button
                type="button"
                onClick={() => setMethod('bank_transfer')}
                className={`flex items-center justify-center p-2.5 rounded-xl border font-bold gap-1.5 transition-all cursor-pointer ${
                  method === 'bank_transfer'
                    ? 'bg-amber-500/15 border-amber-500 text-amber-600 dark:text-amber-300'
                    : theme === 'dark'
                    ? 'bg-[#0F1520] border-neutral-800 text-neutral-400'
                    : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                }`}
              >
                <Landmark className="w-4 h-4" />
                <span>تحويل بنكي</span>
              </button>

              <button
                type="button"
                onClick={() => setMethod('cheque')}
                className={`flex items-center justify-center p-2.5 rounded-xl border font-bold gap-1.5 transition-all cursor-pointer ${
                  method === 'cheque'
                    ? 'bg-amber-500/15 border-amber-500 text-amber-600 dark:text-amber-300'
                    : theme === 'dark'
                    ? 'bg-[#0F1520] border-neutral-800 text-neutral-400'
                    : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>شيك مصرفي</span>
              </button>
            </div>
          </div>

          {/* Date & Reference */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div className="space-y-1">
              <label className="block text-neutral-500">تاريخ الدفع</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className={`w-full py-2 px-3 rounded-xl border outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
              />
            </div>

            <div className="space-y-1">
              <label className="block text-neutral-500">الرقم المرجعي (اختياري)</label>
              <input
                type="text"
                placeholder="رقم الحوالة أو الشيك"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                className={`w-full py-2 px-3 rounded-xl border outline-none ${
                  theme === 'dark'
                    ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                    : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
                }`}
              />
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-1">
            <label className="block text-neutral-500">ملاحظات إضافية (اختياري)</label>
            <input
              type="text"
              placeholder="مثال: دفعة أولى من الإيجار"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className={`w-full py-2 px-3 rounded-xl border outline-none ${
                theme === 'dark'
                  ? 'bg-[#0B0F17] border-neutral-700 text-white focus:border-amber-500'
                  : 'bg-white border-neutral-300 text-neutral-900 focus:border-amber-500'
              }`}
            />
          </div>

          {/* Instant Receipt Option */}
          <div className="pt-1">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={generateReceiptNow}
                onChange={(e) => setGenerateReceiptNow(e.target.checked)}
                className="w-4 h-4 rounded text-amber-500 focus:ring-amber-500"
              />
              <span className="text-neutral-700 dark:text-neutral-300 font-medium">
                عرض سند القبض مباشرة بعد الحفظ (للطباعة أو الإرسال عبر واتساب)
              </span>
            </label>
          </div>

          {/* Footer actions */}
          <div
            className={`pt-3 flex items-center justify-end gap-2 border-t ${
              theme === 'dark' ? 'border-neutral-800' : 'border-neutral-200'
            }`}
          >
            <button
              type="button"
              onClick={onClose}
              className={`px-4 py-2 rounded-xl border font-semibold cursor-pointer ${
                theme === 'dark'
                  ? 'border-neutral-700 text-neutral-300 hover:bg-neutral-800'
                  : 'border-neutral-300 text-neutral-700 hover:bg-neutral-100'
              }`}
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-bold shadow-md transition-all active:scale-95 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>تأكيد وتسجيل الدفعة</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
