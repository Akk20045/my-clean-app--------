import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Palette,
  ChevronDown,
  Check,
  Sparkles,
  Search,
  X,
  Shuffle,
  Sun,
  Moon,
  Crown,
  Zap,
  Coffee,
  CheckCheck,
} from 'lucide-react';
import { ThemeMode } from '../types';
import {
  THEMES,
  THEME_CATEGORIES,
  ThemeCategory,
  getThemeConfig,
  isDarkTheme,
} from '../utils/theme';

interface ThemeToggleListProps {
  currentTheme: ThemeMode;
  onThemeChange: (theme: ThemeMode) => void;
}

export const ThemeToggleList: React.FC<ThemeToggleListProps> = ({
  currentTheme,
  onThemeChange,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<ThemeCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const searchInputRef = useRef<HTMLInputElement>(null);

  const currentConfig = getThemeConfig(currentTheme);
  const isDark = isDarkTheme(currentTheme);

  // Lock body scroll and listen for Escape key when modal is open
  useEffect(() => {
    if (isOpen) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';

      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          setIsOpen(false);
        }
      };
      window.addEventListener('keydown', handleKeyDown);

      // Focus search input
      const timer = setTimeout(() => {
        searchInputRef.current?.focus();
      }, 120);

      return () => {
        document.body.style.overflow = originalOverflow;
        window.removeEventListener('keydown', handleKeyDown);
        clearTimeout(timer);
      };
    } else {
      setSearchQuery('');
    }
  }, [isOpen]);

  const allThemesList = useMemo(() => Object.values(THEMES), []);

  // Filtered themes by category and query
  const filteredThemes = useMemo(() => {
    return allThemesList.filter((t) => {
      const matchCategory =
        selectedCategory === 'all' || t.category === selectedCategory;
      const q = searchQuery.trim().toLowerCase();
      const matchSearch =
        !q ||
        t.nameAr.toLowerCase().includes(q) ||
        t.nameEn.toLowerCase().includes(q) ||
        t.tag.toLowerCase().includes(q);
      return matchCategory && matchSearch;
    });
  }, [allThemesList, selectedCategory, searchQuery]);

  // Category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<ThemeCategory, number> = {
      all: allThemesList.length,
      light: 0,
      dark: 0,
      royal: 0,
      cyber: 0,
      earth: 0,
    };
    allThemesList.forEach((t) => {
      counts[t.category] = (counts[t.category] || 0) + 1;
    });
    return counts;
  }, [allThemesList]);

  // Random theme picker
  const handleRandomTheme = () => {
    const otherThemes = allThemesList.filter((t) => t.id !== currentTheme);
    const randomIndex = Math.floor(Math.random() * otherThemes.length);
    onThemeChange(otherThemes[randomIndex].id);
  };

  const getCategoryIcon = (catId: ThemeCategory) => {
    switch (catId) {
      case 'light':
        return <Sun className="w-3.5 h-3.5 text-amber-500" />;
      case 'dark':
        return <Moon className="w-3.5 h-3.5 text-sky-400" />;
      case 'royal':
        return <Crown className="w-3.5 h-3.5 text-yellow-400" />;
      case 'cyber':
        return <Zap className="w-3.5 h-3.5 text-fuchsia-400" />;
      case 'earth':
        return <Coffee className="w-3.5 h-3.5 text-amber-600" />;
      default:
        return <Sparkles className="w-3.5 h-3.5 text-amber-500" />;
    }
  };

  return (
    <>
      {/* Trigger Button in Navigation Bar */}
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        className={`flex items-center gap-1.5 py-1.5 px-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer select-none shadow-xs active:scale-95 ${
          isDark
            ? 'bg-[#151C28] border-neutral-700 text-neutral-200 hover:border-amber-500/60 hover:bg-[#1a2333]'
            : 'bg-white border-neutral-300 text-neutral-800 hover:bg-neutral-50 hover:border-amber-500/60'
        } ${isOpen ? 'ring-2 ring-amber-500/50 border-amber-500/60' : ''}`}
        title="تغيير ثيم ومظهر النظام"
        aria-expanded={isOpen}
      >
        {/* Color preview circles */}
        <div className="flex items-center -space-x-1 rtl:space-x-reverse shrink-0">
          <span
            className="w-2.5 h-2.5 rounded-full border border-black/20 shadow-xs"
            style={{ backgroundColor: currentConfig.previewColors[0] }}
          />
          <span
            className="w-2.5 h-2.5 rounded-full border border-black/20 shadow-xs"
            style={{ backgroundColor: currentConfig.previewColors[2] }}
          />
        </div>

        <Palette className="w-3.5 h-3.5 text-amber-500 shrink-0" />
        <span className="max-w-[75px] sm:max-w-[100px] truncate">
          {currentConfig.nameAr}
        </span>
        <ChevronDown
          className={`w-3 h-3 text-neutral-400 transition-transform duration-200 shrink-0 ${
            isOpen ? 'rotate-180 text-amber-500' : ''
          }`}
        />
      </button>

      {/* Responsive Centered Modal Dialog (Prevents Any Viewport Clipping) */}
      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-xs animate-in fade-in duration-150 overflow-y-auto"
          onClick={() => setIsOpen(false)}
        >
          <div
            className={`w-full max-w-lg md:max-w-2xl lg:max-w-3xl rounded-3xl border shadow-2xl flex flex-col max-h-[90vh] overflow-hidden my-auto animate-in zoom-in-95 duration-150 ${
              isDark
                ? 'bg-[#101622] border-neutral-700/80 text-white shadow-black/90'
                : 'bg-white border-neutral-200 text-neutral-900 shadow-2xl'
            }`}
            onClick={(e) => e.stopPropagation()}
            dir="rtl"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between p-3.5 sm:p-5 border-b border-neutral-700/20 shrink-0">
              <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                <div
                  className={`p-2.5 rounded-2xl shrink-0 ${
                    isDark ? 'bg-amber-500/15 text-amber-400' : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  <Palette className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="text-sm sm:text-base font-extrabold flex items-center gap-2 flex-wrap">
                    <span className="truncate">مكتبة المظاهر والتصميم</span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold shrink-0 ${
                        isDark
                          ? 'bg-neutral-800 text-amber-400 border border-neutral-700'
                          : 'bg-amber-50 text-amber-800 border border-amber-200'
                      }`}
                    >
                      {allThemesList.length} مظهر
                    </span>
                  </div>
                  <p className="text-[11px] sm:text-xs text-neutral-400 mt-0.5 truncate">
                    المظهر النشط حالياً:{' '}
                    <span className="text-amber-500 font-bold">{currentConfig.nameAr}</span>
                    <span className="mx-1 text-neutral-500">•</span>
                    <span>{currentConfig.tag}</span>
                  </p>
                </div>
              </div>

              {/* Header Actions */}
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={handleRandomTheme}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer active:scale-95 ${
                    isDark
                      ? 'bg-neutral-800/80 border-neutral-700 text-neutral-200 hover:text-white hover:bg-neutral-700'
                      : 'bg-neutral-100 border-neutral-200 text-neutral-700 hover:text-black hover:bg-neutral-200'
                  }`}
                  title="تجربة ثيم عشوائي مفاجئ"
                >
                  <Shuffle className="w-3.5 h-3.5 text-amber-500" />
                  <span className="hidden sm:inline text-xs">ثيم عشوائي</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className={`p-2 rounded-xl border transition-colors cursor-pointer active:scale-95 ${
                    isDark
                      ? 'bg-neutral-800/90 border-neutral-700 text-neutral-400 hover:text-white hover:bg-neutral-700'
                      : 'bg-neutral-100 border-neutral-200 text-neutral-600 hover:text-black hover:bg-neutral-200'
                  }`}
                  title="إغلاق النافذة (Esc)"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Filter Section (Search + Category Tabs) */}
            <div className="p-3 sm:px-5 sm:py-3 border-b border-neutral-700/20 bg-neutral-500/5 shrink-0 space-y-2.5">
              {/* Search Box */}
              <div className="relative">
                <Search className="w-4 h-4 absolute right-3 top-2.5 text-neutral-400 pointer-events-none" />
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث بالاسم أو اللون (مثل: أزرق، كحلي، ذهبي، نيون، بارد، رمال...)"
                  className={`w-full pr-9 pl-8 py-2 rounded-xl text-xs outline-none border transition-all ${
                    isDark
                      ? 'bg-[#0B101A] border-neutral-700 text-white placeholder-neutral-500 focus:border-amber-500/60'
                      : 'bg-white border-neutral-300 text-neutral-900 placeholder-neutral-400 focus:border-amber-500'
                  }`}
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute left-2.5 top-2.5 text-neutral-400 hover:text-neutral-200 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Categories Tabs */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
                {THEME_CATEGORIES.map((cat) => {
                  const isCatActive = selectedCategory === cat.id;
                  const count = categoryCounts[cat.id];
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer border shrink-0 ${
                        isCatActive
                          ? isDark
                            ? 'bg-amber-500 text-neutral-950 border-amber-400 shadow-xs'
                            : 'bg-amber-500 text-neutral-950 border-amber-600 shadow-xs'
                          : isDark
                          ? 'bg-neutral-800/60 border-neutral-700/80 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
                          : 'bg-white border-neutral-200 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
                      }`}
                    >
                      <span>{cat.icon}</span>
                      <span>{cat.nameAr}</span>
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                          isCatActive
                            ? 'bg-black/20 text-neutral-950 font-extrabold'
                            : 'text-neutral-400'
                        }`}
                      >
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Themes Grid Body */}
            <div className="p-3 sm:p-5 overflow-y-auto flex-1 custom-scrollbar">
              {filteredThemes.length === 0 ? (
                <div className="py-12 text-center text-xs text-neutral-400">
                  <Palette className="w-8 h-8 mx-auto mb-2 opacity-30 text-amber-500" />
                  <p className="font-bold">لا توجد مظاهر مطابقة لبحثك "{searchQuery}"</p>
                  <p className="text-[11px] text-neutral-500 mt-1">
                    جرّب البحث عن لون آخر أو اختر تصنيفاً مختلفاً
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {filteredThemes.map((t) => {
                    const isSelected = currentTheme === t.id;
                    return (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => {
                          onThemeChange(t.id);
                          setIsOpen(false);
                        }}
                        className={`w-full text-right p-3 rounded-2xl border transition-all cursor-pointer group flex items-center justify-between gap-3 relative ${
                          isSelected
                            ? isDark
                              ? 'bg-amber-500/15 border-amber-500 ring-2 ring-amber-500/40 shadow-md'
                              : 'bg-amber-50 border-amber-500 ring-2 ring-amber-500/30 shadow-md'
                            : isDark
                            ? 'bg-[#151D2C]/80 border-neutral-700/60 hover:border-amber-500/50 hover:bg-[#1c273a]'
                            : 'bg-neutral-50/80 border-neutral-200 hover:border-amber-400 hover:bg-white'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          {/* 3-Color Swatch Preview */}
                          <div className="flex flex-col gap-0.5 p-1 rounded-xl bg-black/30 border border-white/10 shrink-0 shadow-inner">
                            <div className="flex items-center gap-0.5">
                              <span
                                className="w-3.5 h-3.5 rounded-md shadow-xs block"
                                style={{ backgroundColor: t.previewColors[0] }}
                              />
                              <span
                                className="w-3.5 h-3.5 rounded-md shadow-xs block"
                                style={{ backgroundColor: t.previewColors[1] }}
                              />
                            </div>
                            <span
                              className="w-full h-1.5 rounded-sm shadow-xs block"
                              style={{ backgroundColor: t.previewColors[2] }}
                            />
                          </div>

                          {/* Theme Details */}
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="font-extrabold text-xs truncate text-neutral-900 dark:text-neutral-100">
                                {t.nameAr}
                              </span>
                              {t.isDark ? (
                                <Moon className="w-2.5 h-2.5 text-sky-400 shrink-0" />
                              ) : (
                                <Sun className="w-2.5 h-2.5 text-amber-500 shrink-0" />
                              )}
                            </div>
                            <div className="text-[10px] text-neutral-400 truncate flex items-center gap-1 mt-0.5">
                              <span className="truncate">{t.tag}</span>
                            </div>
                          </div>
                        </div>

                        {/* Active Checkmark or Swatch Dot */}
                        {isSelected ? (
                          <div className="w-5 h-5 rounded-full bg-amber-500 text-neutral-950 flex items-center justify-center shrink-0 shadow-xs">
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                          </div>
                        ) : (
                          <div
                            className="w-2.5 h-2.5 rounded-full opacity-40 group-hover:opacity-100 transition-opacity shrink-0"
                            style={{ backgroundColor: t.previewColors[2] }}
                          />
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-3 sm:px-5 sm:py-3 border-t border-neutral-700/20 flex items-center justify-between text-xs text-neutral-400 bg-neutral-500/5 shrink-0">
              <span className="flex items-center gap-1.5 text-[11px] sm:text-xs">
                <CheckCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>يتم حفظ المظهر وتطبيقه على النظام فوراً</span>
              </span>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className={`px-3 py-1.5 rounded-xl border font-bold text-xs cursor-pointer transition-colors ${
                  isDark
                    ? 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white hover:bg-neutral-700'
                    : 'bg-white border-neutral-300 text-neutral-700 hover:text-black hover:bg-neutral-100'
                }`}
              >
                إغلاق النافذة
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
