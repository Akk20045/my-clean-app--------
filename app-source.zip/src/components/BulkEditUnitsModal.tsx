import React, { useState, useMemo } from 'react';
import {
  X,
  Check,
  CheckSquare,
  Square,
  Search,
  Building2,
  Store,
  Home,
  Briefcase,
  Layers,
  Sparkles,
  SlidersHorizontal,
} from 'lucide-react';
import { Building, Tenant, ThemeMode, UnitType } from '../types';
import { getUnitTypeLabel, getUnitDisplayTag } from '../utils/formatters';

interface BulkEditUnitsModalProps {
  isOpen: boolean;
  onClose: () => void;
  tenants: Tenant[];
  buildings: Building[];
  onBulkUpdateUnitType: (tenantIds: string[], newType: UnitType, customType?: string) => void;
  theme: ThemeMode;
}

export const BulkEditUnitsModal: React.FC<BulkEditUnitsModalProps> = ({
  isOpen,
  onClose,
  tenants,
  buildings,
  onBulkUpdateUnitType,
  theme,
}) => {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [targetType, setTargetType] = useState<UnitType>('commercial_shop');
  const [customTypeName, setCustomTypeName] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedBuildingId, setSelectedBuildingId] = useState<string>('all');

  // Building name lookup map
  const buildingMap = useMemo(() => {
    const map = new Map<string, string>();
    for (const b of buildings) {
      map.set(b.id, b.name);
    }
    return map;
  }, [buildings]);

  // Filtered tenants for selection list
  const filteredTenants = useMemo(() => {
    return tenants.filter((t) => {
      if (selectedBuildingId !== 'all' && t.buildingId !== selectedBuildingId) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const bName = (buildingMap.get(t.buildingId) || '').toLowerCase();
        const tName = (t.name || '').toLowerCase();
        const uNum = (t.unitNumber || '').toLowerCase();
        const uType = getUnitTypeLabel(t.unitType, t.customUnitType).toLowerCase();
        return bName.includes(q) || tName.includes(q) || uNum.includes(q) || uType.includes(q);
      }
      return true;
    });
  }, [tenants, selectedBuildingId, searchQuery, buildingMap]);

  if (!isOpen) return null;

  const toggleSelectOne = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAllFiltered = () => {
    const visibleIds = filteredTenants.map((t) => t.id);
    const allSelected = visibleIds.every((id) => selectedIds.includes(id));
    if (allSelected) {
      // Unselect only the visible ones
      setSelectedIds((prev) => prev.filter((id) => !visibleIds.includes(id)));
    } else {
      // Add all visible IDs
      setSelectedIds((prev) => Array.from(new Set([...prev, ...visibleIds])));
    }
  };

  const handleClearSelection = () => {
    setSelectedIds([]);
  };

  const isAllFilteredSelected =
    filteredTenants.length > 0 &&
    filteredTenants.every((t) => selectedIds.includes(t.id));

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedIds.length === 0) return;
    if (targetType === 'other' && !customTypeName.trim()) return;

    onBulkUpdateUnitType(
      selectedIds,
      targetType,
      targetType === 'other' ? customTypeName.trim() : undefined
    );

    // Reset & close
    setSelectedIds([]);
    onClose();
  };

  const unitTypeOptions: { type: UnitType; label: string; icon: React.ReactNode; desc: string }[] = [
    {
      type: 'apartment',
      label: 'شقة سكنية',
      icon: <Home className="w-4 h-4 text-emerald-500" />,
      desc: 'استخدام سكني عائلي',
    },
    {
      type: 'commercial_shop',
      label: 'محل تجاري',
      icon: <Store className="w-4 h-4 text-sky-500" />,
      desc: 'دكان أو متجر تجاري',
    },
    {
      type: 'office',
      label: 'مكتب أعمال',
      icon: <Briefcase className="w-4 h-4 text-indigo-500" />,
      desc: 'مقر شركة أو عيادة أو مكتب',
    },
    {
      type: 'penthouse',
      label: 'بنتهاوس',
      icon: <Building2 className="w-4 h-4 text-amber-500" />,
      desc: 'رووف أو طابق علوي مميز',
    },
    {
      type: 'villa',
      label: 'فيلا مستقلة',
      icon: <Home className="w-4 h-4 text-purple-500" />,
      desc: 'منزل أو فيلا منفصلة',
    },
    {
      type: 'other',
      label: 'أخرى (مخصص)',
      icon: <Sparkles className="w-4 h-4 text-amber-400" />,
      desc: 'مستودع، كراج، استوديو، ملحق...',
    },
  ];

  return (
    <div className="fixed inset-0 z-[75] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`relative w-full sm:max-w-3xl border-t sm:border sm:rounded-3xl rounded-t-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col transition-colors ${
          theme === 'dark'
            ? 'bg-[#121824] border-neutral-700/80 text-white'
            : 'bg-white border-neutral-300 text-neutral-900'
        }`}
      >
        {/* Header */}
        <div
          className={`flex items-center justify-between px-6 py-4 border-b ${
            theme === 'dark' ? 'bg-[#0E131E] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <div className="flex items-center gap-3">
            <div
              className={`p-2.5 rounded-2xl border ${
                theme === 'dark'
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
                  : 'bg-amber-50 border-amber-200 text-amber-700'
              }`}
            >
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight">
                تعديل نوع الوحدات (تحديد جماعي)
              </h3>
              <p className="text-xs text-neutral-400">
                حدد الوحدات المراد تعديلها، ثم اختر النوع الجديد (شقة، محل تجاري، أو نوع آخر مخصص)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-700 dark:hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 space-y-5 overflow-y-auto flex-1 text-xs">
          {/* Section 1: Choose Target Unit Type */}
          <div
            className={`p-4 rounded-2xl border space-y-3 ${
              theme === 'dark'
                ? 'bg-[#151C28] border-neutral-800'
                : 'bg-neutral-50/80 border-neutral-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <label className="font-extrabold text-sm flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-amber-500 text-neutral-950 font-black flex items-center justify-center text-xs">
                  1
                </span>
                <span>اختر نوع الوحدة الجديد المراد تطبيقه:</span>
              </label>
              <span className="text-[11px] text-neutral-400">
                النوع الحالي المختار:{' '}
                <strong className="text-amber-500">
                  {targetType === 'other'
                    ? customTypeName.trim() || 'نوع مخصص'
                    : getUnitTypeLabel(targetType)}
                </strong>
              </span>
            </div>

            {/* Type Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {unitTypeOptions.map((opt) => {
                const isSelected = targetType === opt.type;
                return (
                  <button
                    key={opt.type}
                    type="button"
                    onClick={() => setTargetType(opt.type)}
                    className={`flex flex-col items-start p-3 rounded-xl border text-right transition-all cursor-pointer ${
                      isSelected
                        ? theme === 'dark'
                          ? 'bg-amber-500/15 border-amber-500 text-white shadow-xs scale-[1.01]'
                          : 'bg-amber-50 border-amber-400 text-amber-950 shadow-xs scale-[1.01]'
                        : theme === 'dark'
                        ? 'bg-[#0E131E] border-neutral-800 text-neutral-300 hover:border-neutral-700'
                        : 'bg-white border-neutral-200 text-neutral-700 hover:border-neutral-300'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full mb-1">
                      <div className="flex items-center gap-2 font-bold text-xs">
                        {opt.icon}
                        <span>{opt.label}</span>
                      </div>
                      {isSelected && (
                        <span className="w-4 h-4 rounded-full bg-amber-500 text-neutral-950 flex items-center justify-center text-[10px]">
                          ✓
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-neutral-400 leading-tight">
                      {opt.desc}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Custom Unit Type Name Field when 'other' is chosen */}
            {targetType === 'other' && (
              <div className="pt-2 animate-in fade-in zoom-in-95 duration-150 space-y-1.5">
                <label className="block font-bold text-amber-500 text-xs">
                  اكتب اسم نوع الوحدة المخصص (الي بدك اياه): <span className="text-rose-500">*</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    autoFocus
                    placeholder="مثال: مستودع، كراج، استوديو، ملحق، معرض تجاري، صالة، مخزن..."
                    value={customTypeName}
                    onChange={(e) => setCustomTypeName(e.target.value)}
                    className={`flex-1 py-2.5 px-3 rounded-xl border text-xs outline-none transition-colors ${
                      theme === 'dark'
                        ? 'bg-[#0E131E] border-amber-500/60 text-white focus:border-amber-400'
                        : 'bg-white border-amber-400 text-neutral-900 focus:border-amber-500'
                    }`}
                  />
                  {customTypeName && (
                    <button
                      type="button"
                      onClick={() => setCustomTypeName('')}
                      className="px-2.5 py-1 text-xs text-neutral-400 hover:text-neutral-200"
                    >
                      مسح
                    </button>
                  )}
                </div>
                {/* Suggestions pill tags */}
                <div className="flex items-center gap-1.5 flex-wrap pt-1">
                  <span className="text-[10px] text-neutral-400">اقتراحات سريعة:</span>
                  {['مستودع', 'كراج', 'استوديو', 'ملحق', 'صالة عرض', 'مخزن أرضي'].map((sug) => (
                    <button
                      key={sug}
                      type="button"
                      onClick={() => setCustomTypeName(sug)}
                      className={`text-[10px] px-2 py-0.5 rounded-lg border transition-colors cursor-pointer ${
                        customTypeName === sug
                          ? 'bg-amber-500 text-neutral-950 font-bold border-amber-500'
                          : theme === 'dark'
                          ? 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white'
                          : 'bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-100'
                      }`}
                    >
                      + {sug}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Section 2: Select Units */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <label className="font-extrabold text-sm flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-amber-500 text-neutral-950 font-black flex items-center justify-center text-xs">
                  2
                </span>
                <span>حدد الوحدات التي ترغب بتغييرها:</span>
              </label>

              {/* Selection Counter & Quick Select */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSelectAllFiltered}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    isAllFilteredSelected
                      ? 'bg-amber-500 text-neutral-950 border-amber-500'
                      : theme === 'dark'
                      ? 'bg-neutral-800 border-neutral-700 text-neutral-200 hover:text-white'
                      : 'bg-neutral-100 border-neutral-300 text-neutral-800 hover:bg-neutral-200'
                  }`}
                >
                  {isAllFilteredSelected ? (
                    <CheckSquare className="w-3.5 h-3.5" />
                  ) : (
                    <Square className="w-3.5 h-3.5" />
                  )}
                  <span>{isAllFilteredSelected ? 'إلغاء تحديد الكل' : 'تحديد الكل'}</span>
                </button>

                {selectedIds.length > 0 && (
                  <button
                    type="button"
                    onClick={handleClearSelection}
                    className="text-[11px] text-neutral-400 hover:text-rose-400 transition-colors cursor-pointer"
                  >
                    تفريغ التحديد
                  </button>
                )}
              </div>
            </div>

            {/* Filter by building and search input */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-400 pointer-events-none" />
                <input
                  type="text"
                  placeholder="بحث باسم المستأجر أو رقم الوحدة..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`w-full pr-9 pl-3 py-2 rounded-xl border text-xs outline-none transition-colors ${
                    theme === 'dark'
                      ? 'bg-[#0E131E] border-neutral-700 text-white focus:border-amber-500'
                      : 'bg-white border-neutral-200 text-neutral-900 focus:border-amber-500'
                  }`}
                />
              </div>

              {buildings.length > 1 && (
                <select
                  value={selectedBuildingId}
                  onChange={(e) => setSelectedBuildingId(e.target.value)}
                  className={`py-2 px-3 rounded-xl border text-xs outline-none cursor-pointer ${
                    theme === 'dark'
                      ? 'bg-[#0E131E] border-neutral-700 text-white focus:border-amber-500'
                      : 'bg-white border-neutral-200 text-neutral-900 focus:border-amber-500'
                  }`}
                >
                  <option value="all">جميع العمارات ({buildings.length})</option>
                  {buildings.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              )}
            </div>

            {/* Units Selection List */}
            <div
              className={`rounded-2xl border divide-y overflow-hidden max-h-72 overflow-y-auto ${
                theme === 'dark'
                  ? 'bg-[#0E131E] border-neutral-800 divide-neutral-800'
                  : 'bg-white border-neutral-200 divide-neutral-100'
              }`}
            >
              {filteredTenants.length === 0 ? (
                <div className="p-8 text-center text-neutral-400">
                  لا توجد وحدات مطابقة للبحث أو التصفية الحالية
                </div>
              ) : (
                filteredTenants.map((t) => {
                  const isChecked = selectedIds.includes(t.id);
                  const bName = buildingMap.get(t.buildingId) || 'عمارة';
                  const unitTag = getUnitDisplayTag(t.unitNumber, t.unitType, t.customUnitType);
                  const currentTypeLabel = getUnitTypeLabel(t.unitType, t.customUnitType);

                  return (
                    <div
                      key={t.id}
                      onClick={() => toggleSelectOne(t.id)}
                      className={`flex items-center justify-between p-3 cursor-pointer transition-colors ${
                        isChecked
                          ? theme === 'dark'
                            ? 'bg-amber-500/10'
                            : 'bg-amber-50/80'
                          : theme === 'dark'
                          ? 'hover:bg-neutral-800/40'
                          : 'hover:bg-neutral-50'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-colors shrink-0 ${
                            isChecked
                              ? 'bg-amber-500 border-amber-500 text-neutral-950 font-bold'
                              : theme === 'dark'
                              ? 'border-neutral-700 bg-neutral-900'
                              : 'border-neutral-300 bg-white'
                          }`}
                        >
                          {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>

                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs truncate">
                              {unitTag}
                            </span>
                            <span className="text-[10px] text-neutral-400 truncate">
                              ({bName})
                            </span>
                          </div>
                          <div className="text-[11px] text-neutral-400 truncate">
                            المستأجر: <strong className="text-neutral-300">{t.name}</strong>
                          </div>
                        </div>
                      </div>

                      {/* Current unit type badge */}
                      <div className="shrink-0 flex items-center gap-2">
                        <span
                          className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                            t.unitType === 'commercial_shop'
                              ? 'bg-sky-500/10 text-sky-500 border-sky-500/30'
                              : t.unitType === 'office'
                              ? 'bg-indigo-500/10 text-indigo-500 border-indigo-500/30'
                              : t.unitType === 'other'
                              ? 'bg-purple-500/10 text-purple-400 border-purple-500/30'
                              : 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30'
                          }`}
                        >
                          {currentTypeLabel}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Footer with Apply button */}
        <div
          className={`flex items-center justify-between px-6 py-4 border-t gap-3 ${
            theme === 'dark' ? 'bg-[#0E131E] border-neutral-800' : 'bg-neutral-50 border-neutral-200'
          }`}
        >
          <div className="text-xs">
            <span className="text-neutral-400">الوحدات المحددة: </span>
            <span className="font-black text-amber-500 text-sm">{selectedIds.length}</span>
            <span className="text-neutral-400"> من أصل {tenants.length}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className={`px-4 py-2 rounded-xl border font-semibold text-xs transition-colors cursor-pointer ${
                theme === 'dark'
                  ? 'border-neutral-700 hover:bg-neutral-800 text-neutral-300'
                  : 'border-neutral-300 hover:bg-neutral-100 text-neutral-700'
              }`}
            >
              إلغاء
            </button>

            <button
              type="button"
              onClick={handleApply}
              disabled={
                selectedIds.length === 0 ||
                (targetType === 'other' && !customTypeName.trim())
              }
              className={`flex items-center gap-1.5 px-5 py-2.5 rounded-xl font-extrabold text-xs shadow-md transition-all active:scale-95 cursor-pointer ${
                selectedIds.length === 0 ||
                (targetType === 'other' && !customTypeName.trim())
                  ? 'bg-neutral-700/50 text-neutral-500 cursor-not-allowed opacity-60'
                  : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950'
              }`}
            >
              <Check className="w-4 h-4 stroke-[2.5]" />
              <span>
                تطبيق التعديل على ({selectedIds.length}){' '}
                {selectedIds.length === 1 ? 'وحدة' : 'وحدات'}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
