export type UnitType =
  | 'apartment'
  | 'commercial_shop'
  | 'office'
  | 'penthouse'
  | 'villa'
  | 'other'
  | string;

export type PaymentMethod = 'cash' | 'cliq' | 'bank_transfer' | 'cheque';

export type DepositStatus = 'held' | 'returned' | 'partially_deducted';

export interface Building {
  id: string;
  name: string;
  location: string;
  notes?: string;
}

export interface Tenant {
  id: string;
  buildingId: string;
  unitNumber?: string; // Optional! (e.g., "شقة 104", "محل رقم 2", or empty "")
  unitType: UnitType;
  customUnitType?: string; // If 'other', user specifies custom name (e.g., مستودع, كراج, استوديو, ملحق...)
  name: string;
  phone: string;
  email?: string;
  monthlyRent: number;
  currency: string; // e.g., 'JOD'
  leaseStart?: string; // YYYY-MM-DD (optional)
  leaseEnd?: string; // YYYY-MM-DD (optional)
  securityDeposit: number; // e.g., 1000 JOD
  depositStatus?: DepositStatus;
  depositNotes?: string;
  notes?: string;
}

export interface PaymentRecord {
  id: string;
  tenantId: string;
  monthKey: string; // 'YYYY-MM', e.g., '2026-09'
  amount: number;
  date: string; // YYYY-MM-DD
  method: PaymentMethod;
  referenceNumber?: string;
  receiptNumber: string;
  notes?: string;
  createdAt: string;
}

export type MonthStatus = 'paid' | 'partial' | 'unpaid';

export interface TenantFinancialSnapshot {
  tenant: Tenant;
  buildingName: string;
  monthKey: string;
  monthlyRent: number;
  totalPaid: number;
  balanceRemaining: number;
  percentagePaid: number;
  status: MonthStatus;
  payments: PaymentRecord[];
}

export type ViewMode = 'cards' | 'table';

export type ThemeMode =
  // ☀️ النهاري والفاتح (Light & Crisp - الموسعة)
  | 'light'
  | 'light-blue'
  | 'cream'
  | 'lavender'
  | 'mint-light'
  | 'rose-gold'
  | 'pastel-yellow'
  | 'peach-soft'
  | 'sage-light'
  | 'turquoise-soft'
  | 'orchid-soft'
  | 'blossom-pink'
  | 'warm-sand'
  | 'coral-soft'
  | 'arctic-ice'
  | 'olive-light'
  | 'amethyst-light'
  | 'lemon-crisp'
  // 🌙 الليلي والتنفيذي (Executive Dark)
  | 'dark'
  | 'cool'
  | 'navy'
  | 'graphite'
  | 'nordic'
  | 'carbon'
  // 👑 الملكي والفاخر (Royal & Luxe)
  | 'amber'
  | 'emerald'
  | 'crimson'
  | 'amethyst'
  | 'bronze'
  | 'sapphire'
  // ⚡ النيون والتقني (Cyber & Tech)
  | 'cyberpunk'
  | 'matrix'
  | 'solar'
  | 'electric-violet'
  // ☕ الطبيعي والأرضي (Earthy & Nature)
  | 'mocha'
  | 'olive'
  | 'ocean'
  | 'sunset';

export type FontFamily =
  | 'readex'
  | 'cairo'
  | 'tajawal'
  | 'jakarta'
  | 'almarai'
  | 'noto'
  | 'alexandria'
  | 'ibm'
  | 'amiri'
  | 'changa';

export type FilterStatus = 'all' | 'paid' | 'partial' | 'unpaid';

export type FilterUnitType = 'all' | 'residential' | 'commercial';
