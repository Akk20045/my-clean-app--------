import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  getDocs,
  getDoc,
  serverTimestamp,
} from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from './index';
import { Building, PaymentRecord, Tenant } from '../types';

export interface WorkspaceData {
  id: string;
  name: string;
  ownerId: string;
  ownerEmail: string;
  sharedEmails: string[];
  createdAt?: string;
  updatedAt?: string;
}

// 1. Workspace / Team Management
export async function getOrCreateWorkspace(userUid: string, userEmail: string, displayName?: string): Promise<WorkspaceData> {
  const path = `workspaces/${userUid}`;
  try {
    const docRef = doc(db, 'workspaces', userUid);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      const data = snap.data() as WorkspaceData;
      return data;
    }

    const newWorkspace: WorkspaceData = {
      id: userUid,
      name: displayName ? `محفظة ${displayName}` : 'محفظتي العقارية',
      ownerId: userUid,
      ownerEmail: userEmail,
      sharedEmails: [userEmail],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await setDoc(docRef, newWorkspace);
    return newWorkspace;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function addSharedEmailToWorkspace(
  workspaceOwnerId: string,
  newEmail: string,
  currentSharedEmails: string[]
): Promise<string[]> {
  const path = `workspaces/${workspaceOwnerId}`;
  const cleanEmail = newEmail.trim().toLowerCase();
  if (!cleanEmail || currentSharedEmails.includes(cleanEmail)) {
    return currentSharedEmails;
  }
  if (currentSharedEmails.length >= 20) {
    throw new Error('الحد الأقصى للحسابات المشاركة هو 20 حساب');
  }

  const updatedEmails = [...currentSharedEmails, cleanEmail];

  try {
    await setDoc(
      doc(db, 'workspaces', workspaceOwnerId),
      {
        sharedEmails: updatedEmails,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );

    // Update sharedEmails on all existing buildings, tenants, payments of this owner so rules allow query
    const buildingsQuery = query(collection(db, 'buildings'), where('ownerId', '==', workspaceOwnerId));
    const bSnaps = await getDocs(buildingsQuery);
    for (const bDoc of bSnaps.docs) {
      await setDoc(doc(db, 'buildings', bDoc.id), { sharedEmails: updatedEmails }, { merge: true });
    }

    const tenantsQuery = query(collection(db, 'tenants'), where('ownerId', '==', workspaceOwnerId));
    const tSnaps = await getDocs(tenantsQuery);
    for (const tDoc of tSnaps.docs) {
      await setDoc(doc(db, 'tenants', tDoc.id), { sharedEmails: updatedEmails }, { merge: true });
    }

    const paymentsQuery = query(collection(db, 'payments'), where('ownerId', '==', workspaceOwnerId));
    const pSnaps = await getDocs(paymentsQuery);
    for (const pDoc of pSnaps.docs) {
      await setDoc(doc(db, 'payments', pDoc.id), { sharedEmails: updatedEmails }, { merge: true });
    }

    return updatedEmails;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function removeSharedEmailFromWorkspace(
  workspaceOwnerId: string,
  emailToRemove: string,
  currentSharedEmails: string[]
): Promise<string[]> {
  const path = `workspaces/${workspaceOwnerId}`;
  const updatedEmails = currentSharedEmails.filter((e) => e !== emailToRemove);

  try {
    await setDoc(
      doc(db, 'workspaces', workspaceOwnerId),
      {
        sharedEmails: updatedEmails,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );

    // Propagate removal
    const buildingsQuery = query(collection(db, 'buildings'), where('ownerId', '==', workspaceOwnerId));
    const bSnaps = await getDocs(buildingsQuery);
    for (const bDoc of bSnaps.docs) {
      await setDoc(doc(db, 'buildings', bDoc.id), { sharedEmails: updatedEmails }, { merge: true });
    }

    const tenantsQuery = query(collection(db, 'tenants'), where('ownerId', '==', workspaceOwnerId));
    const tSnaps = await getDocs(tenantsQuery);
    for (const tDoc of tSnaps.docs) {
      await setDoc(doc(db, 'tenants', tDoc.id), { sharedEmails: updatedEmails }, { merge: true });
    }

    const paymentsQuery = query(collection(db, 'payments'), where('ownerId', '==', workspaceOwnerId));
    const pSnaps = await getDocs(paymentsQuery);
    for (const pDoc of pSnaps.docs) {
      await setDoc(doc(db, 'payments', pDoc.id), { sharedEmails: updatedEmails }, { merge: true });
    }

    return updatedEmails;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// 2. Real-time Subscribers for Buildings, Tenants, Payments
export function subscribeToWorkspaceData(
  targetOwnerId: string,
  userEmail: string,
  onData: (data: { buildings: Building[]; tenants: Tenant[]; payments: PaymentRecord[] }) => void
) {
  let currentBuildings: Building[] = [];
  let currentTenants: Tenant[] = [];
  let currentPayments: PaymentRecord[] = [];

  const bPath = 'buildings';
  const tPath = 'tenants';
  const pPath = 'payments';

  const bQuery = query(collection(db, 'buildings'), where('ownerId', '==', targetOwnerId));
  const tQuery = query(collection(db, 'tenants'), where('ownerId', '==', targetOwnerId));
  const pQuery = query(collection(db, 'payments'), where('ownerId', '==', targetOwnerId));

  const unsubB = onSnapshot(
    bQuery,
    (snap) => {
      currentBuildings = snap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          id: d.id,
          name: d.name,
          location: d.location || '',
          notes: d.notes || '',
        };
      });
      onData({ buildings: currentBuildings, tenants: currentTenants, payments: currentPayments });
    },
    (err) => {
      if (err.code === 'unavailable' || (typeof navigator !== 'undefined' && !navigator.onLine)) {
        console.info('Firestore operates in offline mode for buildings.');
        return;
      }
      handleFirestoreError(err, OperationType.LIST, bPath);
    }
  );

  const unsubT = onSnapshot(
    tQuery,
    (snap) => {
      currentTenants = snap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          id: d.id,
          buildingId: d.buildingId,
          unitNumber: d.unitNumber || '',
          unitType: d.unitType || 'apartment',
          customUnitType: d.customUnitType,
          name: d.name,
          phone: d.phone || '',
          email: d.email,
          monthlyRent: Number(d.monthlyRent) || 0,
          currency: d.currency || 'JOD',
          leaseStart: d.leaseStart,
          leaseEnd: d.leaseEnd,
          securityDeposit: Number(d.securityDeposit) || 0,
          depositStatus: d.depositStatus,
          depositNotes: d.depositNotes,
          notes: d.notes,
        };
      });
      onData({ buildings: currentBuildings, tenants: currentTenants, payments: currentPayments });
    },
    (err) => {
      if (err.code === 'unavailable' || (typeof navigator !== 'undefined' && !navigator.onLine)) {
        console.info('Firestore operates in offline mode for tenants.');
        return;
      }
      handleFirestoreError(err, OperationType.LIST, tPath);
    }
  );

  const unsubP = onSnapshot(
    pQuery,
    (snap) => {
      currentPayments = snap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          id: d.id,
          tenantId: d.tenantId,
          monthKey: d.monthKey,
          amount: Number(d.amount) || 0,
          date: d.date || '',
          method: d.method || 'cash',
          referenceNumber: d.referenceNumber,
          receiptNumber: d.receiptNumber,
          notes: d.notes,
          createdAt: d.createdAt || new Date().toISOString(),
        };
      });
      onData({ buildings: currentBuildings, tenants: currentTenants, payments: currentPayments });
    },
    (err) => {
      if (err.code === 'unavailable' || (typeof navigator !== 'undefined' && !navigator.onLine)) {
        console.info('Firestore operates in offline mode for payments.');
        return;
      }
      handleFirestoreError(err, OperationType.LIST, pPath);
    }
  );

  return () => {
    unsubB();
    unsubT();
    unsubP();
  };
}

// 3. Finding Workspaces Shared With the Current User's Email
export function subscribeToAccessibleWorkspaces(
  userEmail: string,
  userUid: string,
  onWorkspaces: (workspaces: WorkspaceData[]) => void
) {
  const wPath = 'workspaces';
  const cleanEmail = userEmail.trim().toLowerCase();

  const q = query(collection(db, 'workspaces'), where('sharedEmails', 'array-contains', cleanEmail));

  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as WorkspaceData);
      onWorkspaces(list);
    },
    (err) => handleFirestoreError(err, OperationType.LIST, wPath)
  );
}

// 4. Save/Update/Delete Operations (Real-time Cloud Sync)
export async function saveBuildingToCloud(
  building: Building,
  ownerId: string,
  sharedEmails: string[]
): Promise<void> {
  const path = `buildings/${building.id}`;
  try {
    const data: Record<string, any> = {
      id: building.id,
      name: building.name,
      ownerId,
      sharedEmails,
      updatedAt: new Date().toISOString(),
    };
    if (building.location) data.location = building.location;
    if (building.notes) data.notes = building.notes;

    // Check if exists to preserve createdAt or set it (safely catching offline errors)
    const docRef = doc(db, 'buildings', building.id);
    try {
      const snap = await getDoc(docRef);
      if (snap.exists() && snap.data()?.createdAt) {
        data.createdAt = snap.data().createdAt;
      } else {
        data.createdAt = new Date().toISOString();
      }
    } catch {
      // In offline mode, getDoc might fail; initialize createdAt locally
      data.createdAt = new Date().toISOString();
    }
    await setDoc(docRef, data, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function deleteBuildingFromCloud(buildingId: string): Promise<void> {
  const path = `buildings/${buildingId}`;
  try {
    await deleteDoc(doc(db, 'buildings', buildingId));
  } catch (err) {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      console.info('Queued building delete in local offline cache.');
      return;
    }
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function saveTenantToCloud(
  tenant: Tenant,
  ownerId: string,
  sharedEmails: string[]
): Promise<void> {
  const path = `tenants/${tenant.id}`;
  try {
    const data: Record<string, any> = {
      id: tenant.id,
      buildingId: tenant.buildingId,
      name: tenant.name,
      monthlyRent: tenant.monthlyRent,
      ownerId,
      sharedEmails,
      updatedAt: new Date().toISOString(),
    };
    if (tenant.unitNumber) data.unitNumber = tenant.unitNumber;
    if (tenant.unitType) data.unitType = tenant.unitType;
    if (tenant.customUnitType) data.customUnitType = tenant.customUnitType;
    if (tenant.phone) data.phone = tenant.phone;
    if (tenant.email) data.email = tenant.email;
    if (tenant.currency) data.currency = tenant.currency;
    if (tenant.leaseStart) data.leaseStart = tenant.leaseStart;
    if (tenant.leaseEnd) data.leaseEnd = tenant.leaseEnd;
    if (tenant.securityDeposit !== undefined) data.securityDeposit = tenant.securityDeposit;
    if (tenant.depositStatus) data.depositStatus = tenant.depositStatus;
    if (tenant.depositNotes) data.depositNotes = tenant.depositNotes;
    if (tenant.notes) data.notes = tenant.notes;

    const docRef = doc(db, 'tenants', tenant.id);
    try {
      const snap = await getDoc(docRef);
      if (snap.exists() && snap.data()?.createdAt) {
        data.createdAt = snap.data().createdAt;
      } else {
        data.createdAt = new Date().toISOString();
      }
    } catch {
      data.createdAt = new Date().toISOString();
    }
    await setDoc(docRef, data, { merge: true });
  } catch (err) {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      console.info('Saved tenant to local offline cache.');
      return;
    }
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function deleteTenantFromCloud(tenantId: string): Promise<void> {
  const path = `tenants/${tenantId}`;
  try {
    await deleteDoc(doc(db, 'tenants', tenantId));
  } catch (err) {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      console.info('Queued tenant delete in local offline cache.');
      return;
    }
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function savePaymentToCloud(
  payment: PaymentRecord,
  ownerId: string,
  sharedEmails: string[]
): Promise<void> {
  const path = `payments/${payment.id}`;
  try {
    const data: Record<string, any> = {
      id: payment.id,
      tenantId: payment.tenantId,
      monthKey: payment.monthKey,
      amount: payment.amount,
      receiptNumber: payment.receiptNumber,
      ownerId,
      sharedEmails,
      updatedAt: new Date().toISOString(),
    };
    if (payment.date) data.date = payment.date;
    if (payment.method) data.method = payment.method;
    if (payment.referenceNumber) data.referenceNumber = payment.referenceNumber;
    if (payment.notes) data.notes = payment.notes;

    const docRef = doc(db, 'payments', payment.id);
    try {
      const snap = await getDoc(docRef);
      if (snap.exists() && snap.data()?.createdAt) {
        data.createdAt = snap.data().createdAt;
      } else {
        data.createdAt = payment.createdAt || new Date().toISOString();
      }
    } catch {
      data.createdAt = payment.createdAt || new Date().toISOString();
    }
    await setDoc(docRef, data, { merge: true });
  } catch (err) {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      console.info('Saved payment to local offline cache.');
      return;
    }
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function deletePaymentFromCloud(paymentId: string): Promise<void> {
  const path = `payments/${paymentId}`;
  try {
    await deleteDoc(doc(db, 'payments', paymentId));
  } catch (err) {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      console.info('Queued payment delete in local offline cache.');
      return;
    }
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// 5. Bulk Cloud Migration: Upload all local data to Firestore (Push)
export async function syncLocalDataToCloud(
  localBuildings: Building[],
  localTenants: Tenant[],
  localPayments: PaymentRecord[],
  ownerId: string,
  sharedEmails: string[]
): Promise<{ buildingsCount: number; tenantsCount: number; paymentsCount: number }> {
  for (const b of localBuildings) {
    await saveBuildingToCloud(b, ownerId, sharedEmails);
  }
  for (const t of localTenants) {
    await saveTenantToCloud(t, ownerId, sharedEmails);
  }
  for (const p of localPayments) {
    await savePaymentToCloud(p, ownerId, sharedEmails);
  }
  return {
    buildingsCount: localBuildings.length,
    tenantsCount: localTenants.length,
    paymentsCount: localPayments.length,
  };
}

// 6. Pull / Fetch Cloud Snapshot on Demand (Without aggressive background overwrites)
export async function fetchWorkspaceDataFromCloud(
  targetOwnerId: string
): Promise<{ buildings: Building[]; tenants: Tenant[]; payments: PaymentRecord[] }> {
  const bQuery = query(collection(db, 'buildings'), where('ownerId', '==', targetOwnerId));
  const tQuery = query(collection(db, 'tenants'), where('ownerId', '==', targetOwnerId));
  const pQuery = query(collection(db, 'payments'), where('ownerId', '==', targetOwnerId));

  const [bSnap, tSnap, pSnap] = await Promise.all([
    getDocs(bQuery),
    getDocs(tQuery),
    getDocs(pQuery),
  ]);

  const buildings: Building[] = bSnap.docs.map((docSnap) => {
    const d = docSnap.data();
    return {
      id: d.id,
      name: d.name,
      location: d.location || '',
      notes: d.notes || '',
    };
  });

  const tenants: Tenant[] = tSnap.docs.map((docSnap) => {
    const d = docSnap.data();
    return {
      id: d.id,
      buildingId: d.buildingId,
      unitNumber: d.unitNumber || '',
      unitType: d.unitType || 'apartment',
      customUnitType: d.customUnitType,
      name: d.name,
      phone: d.phone || '',
      email: d.email,
      monthlyRent: Number(d.monthlyRent) || 0,
      currency: d.currency || 'JOD',
      leaseStart: d.leaseStart,
      leaseEnd: d.leaseEnd,
      securityDeposit: Number(d.securityDeposit) || 0,
      depositStatus: d.depositStatus,
      depositNotes: d.depositNotes,
      notes: d.notes,
    };
  });

  const payments: PaymentRecord[] = pSnap.docs.map((docSnap) => {
    const d = docSnap.data();
    return {
      id: d.id,
      tenantId: d.tenantId,
      monthKey: d.monthKey,
      amount: Number(d.amount) || 0,
      date: d.date || '',
      method: d.method || 'cash',
      referenceNumber: d.referenceNumber,
      receiptNumber: d.receiptNumber,
      notes: d.notes,
      createdAt: d.createdAt || new Date().toISOString(),
    };
  });

  return { buildings, tenants, payments };
}

// 7. Explicit One-Way Snapshot Sharing (Send to another account without linking data)
export interface SharedUpdatePackage {
  id: string;
  senderUid: string;
  senderEmail: string;
  recipientEmail: string;
  note?: string;
  status: 'pending' | 'applied';
  buildingsCount: number;
  tenantsCount: number;
  paymentsCount: number;
  payload: {
    buildings: Building[];
    tenants: Tenant[];
    payments: PaymentRecord[];
  };
  createdAt: string;
  updatedAt?: string;
}

export async function sendPortfolioUpdateToAccount(
  senderUid: string,
  senderEmail: string,
  recipientEmail: string,
  note: string,
  buildings: Building[],
  tenants: Tenant[],
  payments: PaymentRecord[]
): Promise<string> {
  const cleanRecipient = recipientEmail.trim().toLowerCase();
  const shareId = `update_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const docRef = doc(db, 'shared_updates', shareId);

  const data: Record<string, any> = {
    id: shareId,
    senderUid,
    senderEmail,
    recipientEmail: cleanRecipient,
    status: 'pending',
    buildingsCount: buildings.length,
    tenantsCount: tenants.length,
    paymentsCount: payments.length,
    payload: {
      buildings,
      tenants,
      payments,
    },
    createdAt: new Date().toISOString(),
  };
  if (note.trim()) {
    data.note = note.trim();
  }

  await setDoc(docRef, data);
  return shareId;
}

export function subscribeToIncomingUpdates(
  userEmail: string,
  onUpdates: (updates: SharedUpdatePackage[]) => void
) {
  const cleanEmail = userEmail.trim().toLowerCase();
  const q = query(
    collection(db, 'shared_updates'),
    where('recipientEmail', '==', cleanEmail)
  );

  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as SharedUpdatePackage);
      // Sort newest first
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      onUpdates(list);
    },
    (err) => {
      console.info('Incoming updates listener offline or info:', err);
    }
  );
}

export async function markSharedUpdateApplied(updateId: string): Promise<void> {
  const docRef = doc(db, 'shared_updates', updateId);
  await setDoc(docRef, { status: 'applied', updatedAt: new Date().toISOString() }, { merge: true });
}

export async function deleteSharedUpdate(updateId: string): Promise<void> {
  const docRef = doc(db, 'shared_updates', updateId);
  await deleteDoc(docRef);
}

// 8. User Independent Portfolio Cloud Persistence (Personal Cloud Storage)
export async function saveUserPortfolioToCloud(
  userId: string,
  userEmail: string,
  buildings: Building[],
  tenants: Tenant[],
  payments: PaymentRecord[],
  currency: string
): Promise<void> {
  const path = `user_portfolios/${userId}`;
  try {
    const docRef = doc(db, 'user_portfolios', userId);
    await setDoc(
      docRef,
      {
        id: userId,
        userId,
        userEmail,
        buildings,
        tenants,
        payments,
        currency,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (err) {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      console.info('Saved portfolio to local offline cache.');
      return;
    }
    console.warn('Silent portfolio save warning:', err);
  }
}

export async function fetchUserPortfolioFromCloud(
  userId: string
): Promise<{ buildings: Building[]; tenants: Tenant[]; payments: PaymentRecord[]; currency?: string } | null> {
  try {
    const docRef = doc(db, 'user_portfolios', userId);
    const snap = await getDoc(docRef);
    if (!snap.exists()) {
      return null;
    }
    const data = snap.data();
    return {
      buildings: Array.isArray(data.buildings) ? data.buildings : [],
      tenants: Array.isArray(data.tenants) ? data.tenants : [],
      payments: Array.isArray(data.payments) ? data.payments : [],
      currency: typeof data.currency === 'string' ? data.currency : undefined,
    };
  } catch (err) {
    console.warn('Fetch user portfolio warning:', err);
    return null;
  }
}

