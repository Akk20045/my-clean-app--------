import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { auth, signInWithGoogle, logOut } from '../firebase';
import {
  getOrCreateWorkspace,
  subscribeToAccessibleWorkspaces,
  addSharedEmailToWorkspace,
  removeSharedEmailFromWorkspace,
  WorkspaceData,
} from '../firebase/firestoreService';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  activeWorkspace: WorkspaceData | null;
  accessibleWorkspaces: WorkspaceData[];
  isOwner: boolean;
  signIn: () => Promise<void>;
  signOut: () => Promise<void>;
  switchWorkspace: (workspace: WorkspaceData) => void;
  inviteEmail: (email: string) => Promise<void>;
  removeEmail: (email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [activeWorkspace, setActiveWorkspace] = useState<WorkspaceData | null>(null);
  const [accessibleWorkspaces, setAccessibleWorkspaces] = useState<WorkspaceData[]>([]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser && currentUser.email) {
        try {
          const ws = await getOrCreateWorkspace(currentUser.uid, currentUser.email, currentUser.displayName || undefined);
          setActiveWorkspace(ws);
        } catch (err) {
          console.error('Error initializing workspace', err);
        }
      } else {
        setActiveWorkspace(null);
        setAccessibleWorkspaces([]);
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Listen to workspaces accessible to the user
  useEffect(() => {
    if (!user || !user.email) return;

    const unsub = subscribeToAccessibleWorkspaces(user.email, user.uid, (workspaces) => {
      setAccessibleWorkspaces(workspaces);
      // If current active workspace is updated, reflect changes
      setActiveWorkspace((prev) => {
        if (!prev) {
          const defaultWs = workspaces.find((w) => w.ownerId === user.uid) || workspaces[0] || null;
          return defaultWs;
        }
        const updated = workspaces.find((w) => w.id === prev.id);
        return updated || prev;
      });
    });

    return () => unsub();
  }, [user]);

  const handleSignIn = async () => {
    try {
      await signInWithGoogle();
    } catch (error) {
      console.error('Google Sign In error:', error);
      throw error;
    }
  };

  const handleSignOut = async () => {
    try {
      await logOut();
      setActiveWorkspace(null);
      setAccessibleWorkspaces([]);
    } catch (error) {
      console.error('Sign Out error:', error);
    }
  };

  const switchWorkspace = (workspace: WorkspaceData) => {
    setActiveWorkspace(workspace);
  };

  const inviteEmail = async (email: string) => {
    if (!activeWorkspace || !user) return;
    const currentEmails = activeWorkspace.sharedEmails || [activeWorkspace.ownerEmail];
    const newEmails = await addSharedEmailToWorkspace(activeWorkspace.id, email, currentEmails);
    setActiveWorkspace({ ...activeWorkspace, sharedEmails: newEmails });
  };

  const removeEmail = async (email: string) => {
    if (!activeWorkspace || !user) return;
    const currentEmails = activeWorkspace.sharedEmails || [activeWorkspace.ownerEmail];
    const newEmails = await removeSharedEmailFromWorkspace(activeWorkspace.id, email, currentEmails);
    setActiveWorkspace({ ...activeWorkspace, sharedEmails: newEmails });
  };

  const isOwner = Boolean(user && activeWorkspace && activeWorkspace.ownerId === user.uid);

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        activeWorkspace,
        accessibleWorkspaces,
        isOwner,
        signIn: handleSignIn,
        signOut: handleSignOut,
        switchWorkspace,
        inviteEmail,
        removeEmail,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
