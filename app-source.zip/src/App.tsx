/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import {
  Building,
  FilterStatus,
  FilterUnitType,
  FontFamily,
  PaymentRecord,
  Tenant,
  TenantFinancialSnapshot,
  ThemeMode,
  UnitType,
  ViewMode,
} from './types';
import {
  clearAllData,
  exportDataAsJSON,
  getTenantSnapshot,
  loadActiveMonth,
  loadBuildings,
  loadCurrency,
  loadDemoData,
  loadFont,
  loadPayments,
  loadTenants,
  loadTheme,
  saveActiveMonth,
  saveBuildings,
  saveCurrency,
  saveFont,
  savePayments,
  saveTenants,
  saveTheme,
} from './utils/storage';
import { exportToExcel, exportToWord } from './utils/exportUtils';
import { Header } from './components/Header';
import { MonthPicker } from './components/MonthPicker';
import { FinancialOverview } from './components/FinancialOverview';
import { CollectionAnalyticsChart } from './components/CollectionAnalyticsChart';
import { FilterBar } from './components/FilterBar';
import { BuildingSection } from './components/BuildingSection';
import { ExecutiveTable } from './components/ExecutiveTable';
import { PaymentModal } from './components/PaymentModal';
import { ReceiptModal } from './components/ReceiptModal';
import { ReportModal } from './components/ReportModal';
import { TenantHistoryModal } from './components/TenantHistoryModal';
import { AddTenantModal } from './components/AddTenantModal';
import { AddBuildingModal } from './components/AddBuildingModal';
import { EditBuildingModal } from './components/EditBuildingModal';
import { EditTenantModal } from './components/EditTenantModal';
import { EditPaymentModal } from './components/EditPaymentModal';
import { BulkEditUnitsModal } from './components/BulkEditUnitsModal';
import { ConfirmModal } from './components/ConfirmModal';
import { SharePortfolioModal } from './components/SharePortfolioModal';
import { OfflineBanner } from './components/OfflineBanner';
import { useAuth } from './context/AuthContext';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import {
  saveUserPortfolioToCloud,
  fetchUserPortfolioFromCloud,
  subscribeToIncomingUpdates,
} from './firebase/firestoreService';
import { Building2, Plus, Sparkles, SearchX, Trash2, Smartphone, Cloud, RefreshCw, X, CheckCircle2 } from 'lucide-react';
import { formatCurrency, getUnitTypeLabel } from './utils/formatters';
import { getThemeConfig, isDarkTheme } from './utils/theme';

interface ConfirmActionState {
  isOpen: boolean;
  title: string;
  message: string;
  confirmText?: string;
  requireInputText?: string;
  onConfirm: () => void;
}

export default function App() {
  // Auth state
  const { user, signIn } = useAuth();
  const { isOnline, wasOffline, clearWasOffline } = useOnlineStatus();
  const [isShareModalOpen, setIsShareModalOpen] = useState<boolean>(false);
  const [syncSuccessMsg, setSyncSuccessMsg] = useState<string | null>(null);
  const [pendingUpdatesCount, setPendingUpdatesCount] = useState<number>(0);

  // Persistence state
  const [buildings, setBuildings] = useState<Building[]>(() => loadBuildings());
  const [tenants, setTenants] = useState<Tenant[]>(() => loadTenants());
  const [payments, setPayments] = useState<PaymentRecord[]>(() => loadPayments());
  const [currency, setCurrency] = useState<string>(() => loadCurrency());
  const [activeMonthKey, setActiveMonthKey] = useState<string>(() => loadActiveMonth());
  const [theme, setTheme] = useState<ThemeMode>(() => loadTheme());
  const [font, setFont] = useState<FontFamily>(() => loadFont());

  // UI state
  const [viewMode, setViewMode] = useState<ViewMode>('cards');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<FilterStatus>('all');
  const [unitTypeFilter, setUnitTypeFilter] = useState<FilterUnitType>('all');
  const [selectedBuildingId, setSelectedBuildingId] = useState<string>('all');

  // Modals state
  const [paymentModalTenantId, setPaymentModalTenantId] = useState<string | null>(null);
  const [historyModalTenantId, setHistoryModalTenantId] = useState<string | null>(null);
  const [isAddBuildingOpen, setIsAddBuildingOpen] = useState<boolean>(false);
  const [isAddTenantOpen, setIsAddTenantOpen] = useState<boolean>(false);
  const [targetBuildingIdForTenant, setTargetBuildingIdForTenant] = useState<string | undefined>(undefined);

  // Edit Modals state
  const [editBuildingId, setEditBuildingId] = useState<string | null>(null);
  const [editTenantId, setEditTenantId] = useState<string | null>(null);
  const [editPaymentRecord, setEditPaymentRecord] = useState<PaymentRecord | null>(null);

  // Receipt & Report modal state
  const [receiptPayment, setReceiptPayment] = useState<PaymentRecord | null>(null);
  const [receiptSnapshot, setReceiptSnapshot] = useState<TenantFinancialSnapshot | null>(null);
  const [isReceiptOpen, setIsReceiptOpen] = useState<boolean>(false);
  const [isReportOpen, setIsReportOpen] = useState<boolean>(false);
  const [isBulkEditOpen, setIsBulkEditOpen] = useState<boolean>(false);

  // In-App Confirm Dialog state
  const [confirmDialog, setConfirmDialog] = useState<ConfirmActionState>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  // Sync state changes with LocalStorage
  useEffect(() => {
    saveBuildings(buildings);
  }, [buildings]);

  useEffect(() => {
    saveTenants(tenants);
  }, [tenants]);

  useEffect(() => {
    savePayments(payments);
  }, [payments]);

  // 1. Subscribe to incoming updates sent to this user
  useEffect(() => {
    if (!user || !user.email) {
      setPendingUpdatesCount(0);
      return;
    }
    const unsub = subscribeToIncomingUpdates(user.email, (updates) => {
      const pending = updates.filter((u) => u.status === 'pending').length;
      setPendingUpdatesCount(pending);
    });
    return () => unsub();
  }, [user?.email]);

  // 2. Load account portfolio when user logs in (or persist existing local data to account)
  useEffect(() => {
    if (!user) return;
    const hasLocal = buildings.length > 0 || tenants.length > 0 || payments.length > 0;
    if (!hasLocal) {
      fetchUserPortfolioFromCloud(user.uid)
        .then((cloudData) => {
          if (cloudData && (cloudData.buildings.length > 0 || cloudData.tenants.length > 0 || cloudData.payments.length > 0)) {
            setBuildings(cloudData.buildings);
            setTenants(cloudData.tenants);
            setPayments(cloudData.payments);
            saveBuildings(cloudData.buildings);
            saveTenants(cloudData.tenants);
            savePayments(cloudData.payments);
            if (cloudData.currency) {
              setCurrency(cloudData.currency);
              saveCurrency(cloudData.currency);
            }
            setSyncSuccessMsg('تم استرجاع بيانات محفظتك المحفوظة على حسابك بنجاح!');
            setTimeout(() => setSyncSuccessMsg(null), 5000);
          }
        })
        .catch((err) => console.warn('Silent cloud portfolio fetch warning:', err));
    } else {
      // Quietly save existing data to user's personal cloud backup
      saveUserPortfolioToCloud(user.uid, user.email || '', buildings, tenants, payments, currency)
        .catch((e) => console.warn('Silent cloud portfolio sync warning:', e));
    }
  }, [user?.uid]);

  // 3. Auto-sync any offline modifications when internet connection is restored
  useEffect(() => {
    if (isOnline && wasOffline && user && user.uid) {
      persistUserPortfolio(buildings, tenants, payments);
      setSyncSuccessMsg('تمت مزامنة كافة التعديلات والإضافات التي تمت دون اتصال مع نسختك السحابية تلقائياً!');
      const timer = setTimeout(() => {
        setSyncSuccessMsg(null);
        clearWasOffline();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [isOnline, wasOffline, user?.uid, buildings, tenants, payments, clearWasOffline]);

  // 4. Helper to persist user's portfolio silently without any page reload or modal interference
  const persistUserPortfolio = (
    updatedB: Building[],
    updatedT: Tenant[],
    updatedP: PaymentRecord[]
  ) => {
    if (user && user.uid) {
      saveUserPortfolioToCloud(
        user.uid,
        user.email || '',
        updatedB,
        updatedT,
        updatedP,
        currency
      ).catch((e) => console.warn('Silent portfolio save warning:', e));
    }
  };

  // 4. Apply incoming update package from a partner
  const handleApplyIncomingUpdate = (incomingData: {
    buildings: Building[];
    tenants: Tenant[];
    payments: PaymentRecord[];
  }) => {
    setBuildings(incomingData.buildings);
    setTenants(incomingData.tenants);
    setPayments(incomingData.payments);
    saveBuildings(incomingData.buildings);
    saveTenants(incomingData.tenants);
    savePayments(incomingData.payments);
    persistUserPortfolio(incomingData.buildings, incomingData.tenants, incomingData.payments);
    setSyncSuccessMsg('تم تطبيق واستيراد التحديث بنجاح! أنت الآن مستقل بالكامل في التعديل والحذف دون التأثير على حساب الشريك.');
    setTimeout(() => setSyncSuccessMsg(null), 7000);
  };

  const handleCurrencyChange = (newCurr: string) => {
    setCurrency(newCurr);
    saveCurrency(newCurr);
  };

  const handleMonthChange = (newMonthKey: string) => {
    setActiveMonthKey(newMonthKey);
    saveActiveMonth(newMonthKey);
  };

  const handleToggleTheme = () => {
    const nextTheme: ThemeMode = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    saveTheme(nextTheme);
  };

  const handleThemeChange = (newTheme: ThemeMode) => {
    setTheme(newTheme);
    saveTheme(newTheme);
  };

  const handleFontChange = (newFont: FontFamily) => {
    setFont(newFont);
    saveFont(newFont);
  };

  // Compute live snapshots for all tenants for current activeMonthKey
  const allSnapshots = useMemo<TenantFinancialSnapshot[]>(() => {
    return tenants.map((tenant) => getTenantSnapshot(tenant, activeMonthKey, payments, buildings));
  }, [tenants, activeMonthKey, payments, buildings]);

  // Aggregate KPI metrics
  const financialTotals = useMemo(() => {
    let totalExpectedRent = 0;
    let totalCollected = 0;
    let totalRemaining = 0;
    let totalSecurityDeposits = 0;
    let paidCount = 0;
    let partialCount = 0;
    let unpaidCount = 0;

    for (const snap of allSnapshots) {
      totalExpectedRent += snap.monthlyRent;
      totalCollected += snap.totalPaid;
      totalRemaining += snap.balanceRemaining;
      totalSecurityDeposits += snap.tenant.securityDeposit || 0;

      if (snap.status === 'paid') paidCount++;
      else if (snap.status === 'partial') partialCount++;
      else unpaidCount++;
    }

    return {
      totalExpectedRent,
      totalCollected,
      totalRemaining,
      totalSecurityDeposits,
      paidCount,
      partialCount,
      unpaidCount,
      totalTenants: allSnapshots.length,
    };
  }, [allSnapshots]);

  // Filtered snapshots based on user controls
  const filteredSnapshots = useMemo(() => {
    return allSnapshots.filter((snap) => {
      // 1. Building filter
      if (selectedBuildingId !== 'all' && snap.tenant.buildingId !== selectedBuildingId) {
        return false;
      }

      // 2. Status filter
      if (statusFilter !== 'all' && snap.status !== statusFilter) {
        return false;
      }

      // 3. Unit type filter
      if (unitTypeFilter === 'residential') {
        if (snap.tenant.unitType === 'commercial_shop' || snap.tenant.unitType === 'office') {
          return false;
        }
      } else if (unitTypeFilter === 'commercial') {
        if (snap.tenant.unitType !== 'commercial_shop' && snap.tenant.unitType !== 'office') {
          return false;
        }
      }

      // 4. Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchName = snap.tenant.name.toLowerCase().includes(query);
        const matchUnit = (snap.tenant.unitNumber || '').toLowerCase().includes(query);
        const matchBuilding = snap.buildingName.toLowerCase().includes(query);
        const matchPhone = snap.tenant.phone.includes(query);
        const matchType = getUnitTypeLabel(snap.tenant.unitType, snap.tenant.customUnitType)
          .toLowerCase()
          .includes(query);
        if (!matchName && !matchUnit && !matchBuilding && !matchPhone && !matchType) {
          return false;
        }
      }

      return true;
    });
  }, [allSnapshots, selectedBuildingId, statusFilter, unitTypeFilter, searchQuery]);

  // Key fix: When a building is selected, ONLY show that specific building!
  // When filters or search are active, ONLY show buildings that have matching units!
  const visibleBuildings = useMemo(() => {
    if (selectedBuildingId !== 'all') {
      return buildings.filter((b) => b.id === selectedBuildingId);
    }
    if (searchQuery.trim() || statusFilter !== 'all' || unitTypeFilter !== 'all') {
      const buildingIdsWithSnapshots = new Set(filteredSnapshots.map((s) => s.tenant.buildingId));
      return buildings.filter((b) => buildingIdsWithSnapshots.has(b.id));
    }
    return buildings;
  }, [buildings, selectedBuildingId, searchQuery, statusFilter, unitTypeFilter, filteredSnapshots]);

  const selectedBuildingName = useMemo(() => {
    if (selectedBuildingId === 'all') return undefined;
    const b = buildings.find((item) => item.id === selectedBuildingId);
    return b ? b.name : undefined;
  }, [selectedBuildingId, buildings]);

  // Handlers for payments
  const handleRecordPaymentClick = (tenantId: string) => {
    setPaymentModalTenantId(tenantId);
  };

  const handleSavePayment = (payment: PaymentRecord) => {
    setPayments((prev) => {
      const updated = [payment, ...prev];
      savePayments(updated);
      persistUserPortfolio(buildings, tenants, updated);
      return updated;
    });
  };

  const handleUpdatePayment = (updatedPayment: PaymentRecord) => {
    setPayments((prev) => {
      const updated = prev.map((p) => (p.id === updatedPayment.id ? updatedPayment : p));
      savePayments(updated);
      persistUserPortfolio(buildings, tenants, updated);
      return updated;
    });
  };

  // Delete payment with confirmation
  const requestDeletePayment = (paymentId: string) => {
    const payment = payments.find((p) => p.id === paymentId);
    const amountStr = payment ? formatCurrency(payment.amount, currency) : '';
    setConfirmDialog({
      isOpen: true,
      title: 'حذف دفعة إيجار',
      message: `هل أنت متأكد من رغبتك في حذف سجل هذه الدفعة ${amountStr ? `بقيمة (${amountStr})` : ''} نهائياً؟`,
      confirmText: 'نعم، احذف الدفعة',
      onConfirm: () => {
        setPayments((prev) => {
          const updated = prev.filter((p) => p.id !== paymentId);
          savePayments(updated);
          persistUserPortfolio(buildings, tenants, updated);
          return updated;
        });
      },
    });
  };

  const handleOpenReceiptFromPayment = (payment: PaymentRecord, snapshot: TenantFinancialSnapshot) => {
    setReceiptPayment(payment);
    setReceiptSnapshot(snapshot);
    setIsReceiptOpen(true);
  };

  const handleViewReceiptFromHistory = (payment: PaymentRecord) => {
    const tenant = tenants.find((t) => t.id === payment.tenantId);
    if (!tenant) return;
    const snap = getTenantSnapshot(tenant, payment.monthKey, payments, buildings);
    setReceiptPayment(payment);
    setReceiptSnapshot(snap);
    setIsReceiptOpen(true);
  };

  // Building & Tenant creation and update handlers
  const handleSaveNewBuilding = (newBuilding: Building) => {
    setBuildings((prev) => {
      const updated = [...prev, newBuilding];
      saveBuildings(updated);
      persistUserPortfolio(updated, tenants, payments);
      return updated;
    });
  };

  const handleUpdateBuilding = (updatedBuilding: Building) => {
    setBuildings((prev) => {
      const updated = prev.map((b) => (b.id === updatedBuilding.id ? updatedBuilding : b));
      saveBuildings(updated);
      persistUserPortfolio(updated, tenants, payments);
      return updated;
    });
  };

  // Delete building with confirmation
  const requestDeleteBuilding = (buildingId: string) => {
    const b = buildings.find((item) => item.id === buildingId);
    const buildingUnitsCount = tenants.filter((t) => t.buildingId === buildingId).length;
    const buildingName = b ? b.name : 'العمارة';

    const message =
      buildingUnitsCount > 0
        ? `تحذير: عمارة (${buildingName}) تحتوي على (${buildingUnitsCount}) شقق/وحدات مسجلة. هل أنت متأكد من حذف العمارة وكافة الشقق والدفعات التابعة لها نهائياً؟`
        : `هل أنت متأكد من حذف (${buildingName}) نهائياً من سجل العقارات؟`;

    setConfirmDialog({
      isOpen: true,
      title: 'حذف العمارة بالكامل',
      message,
      confirmText: 'نعم، احذف العمارة',
      onConfirm: () => {
        const updatedBuildings = buildings.filter((item) => item.id !== buildingId);
        const tenantIdsInBuilding = tenants.filter((t) => t.buildingId === buildingId).map((t) => t.id);
        const updatedTenants = tenants.filter((t) => t.buildingId !== buildingId);
        const updatedPayments = payments.filter((p) => !tenantIdsInBuilding.includes(p.tenantId));

        setBuildings(updatedBuildings);
        saveBuildings(updatedBuildings);

        setTenants(updatedTenants);
        saveTenants(updatedTenants);

        setPayments(updatedPayments);
        savePayments(updatedPayments);

        if (selectedBuildingId === buildingId) {
          setSelectedBuildingId('all');
        }

        persistUserPortfolio(updatedBuildings, updatedTenants, updatedPayments);
      },
    });
  };

  const handleOpenAddTenant = (buildingId?: string) => {
    setTargetBuildingIdForTenant(buildingId);
    setIsAddTenantOpen(true);
  };

  const handleSaveNewTenant = (newTenant: Tenant, newBuilding?: Building) => {
    let nextBuildings = buildings;
    if (newBuilding) {
      nextBuildings = [...buildings, newBuilding];
      setBuildings(nextBuildings);
      saveBuildings(nextBuildings);
    }
    setTenants((prev) => {
      const updated = [newTenant, ...prev];
      saveTenants(updated);
      persistUserPortfolio(nextBuildings, updated, payments);
      return updated;
    });
  };

  const handleUpdateTenant = (updatedTenant: Tenant) => {
    setTenants((prev) => {
      const updated = prev.map((t) => (t.id === updatedTenant.id ? updatedTenant : t));
      saveTenants(updated);
      persistUserPortfolio(buildings, updated, payments);
      return updated;
    });
  };

  const handleBulkUpdateUnitType = (
    tenantIds: string[],
    newType: UnitType,
    customType?: string
  ) => {
    setTenants((prev) => {
      const updated = prev.map((t) => {
        if (tenantIds.includes(t.id)) {
          return {
            ...t,
            unitType: newType,
            customUnitType: newType === 'other' ? customType?.trim() : undefined,
          };
        }
        return t;
      });
      saveTenants(updated);
      persistUserPortfolio(buildings, updated, payments);
      return updated;
    });
  };

  // Delete tenant with confirmation
  const requestDeleteTenant = (tenantId: string) => {
    const t = tenants.find((item) => item.id === tenantId);
    const tenantLabel = t
      ? t.unitNumber?.trim()
        ? `الوحدة (${t.unitNumber}) والمستأجر (${t.name})`
        : `المستأجر (${t.name})`
      : 'المستأجر';

    setConfirmDialog({
      isOpen: true,
      title: 'حذف الشقة والمستأجر',
      message: `هل أنت متأكد من رغبتك في حذف ${tenantLabel} وجميع سجلات الدفعات التابعة له نهائياً؟`,
      confirmText: 'نعم، احذف الشقة',
      onConfirm: () => {
        const updatedTenants = tenants.filter((item) => item.id !== tenantId);
        const updatedPayments = payments.filter((p) => p.tenantId !== tenantId);
        setTenants(updatedTenants);
        saveTenants(updatedTenants);
        setPayments(updatedPayments);
        savePayments(updatedPayments);
        persistUserPortfolio(buildings, updatedTenants, updatedPayments);
      },
    });
  };


  // Demo data and clear actions
  const handleLoadDemo = () => {
    const demo = loadDemoData();
    setBuildings(demo.buildings);
    setTenants(demo.tenants);
    setPayments(demo.payments);
    setActiveMonthKey('2026-09');
  };

  const requestClearAll = () => {
    setConfirmDialog({
      isOpen: true,
      title: 'تفريغ السجل بالكامل',
      message: 'تحذير أمني هام: أنت على وشك تفريغ كافة بيانات العمارات والشقق وسجلات التحصيل والبدء من الصفر تماماً. لضمان عدم حدوث الحذف بالخطأ، يجب كتابة العبارة التأكيدية أدناه لمتابعة التفريغ.',
      confirmText: 'نعم، فرغ السجل بالكامل',
      requireInputText: 'اريد احذف هذا المشروع كاملا',
      onConfirm: () => {
        const cleared = clearAllData();
        setBuildings(cleared.buildings);
        setTenants(cleared.tenants);
        setPayments(cleared.payments);
        persistUserPortfolio(cleared.buildings, cleared.tenants, cleared.payments);
      },
    });
  };

  // Export actions (Excel, Word, PDF)
  const handleExportExcel = () => {
    exportToExcel(filteredSnapshots, activeMonthKey, currency, selectedBuildingName);
  };

  const handleExportWord = () => {
    exportToWord(filteredSnapshots, activeMonthKey, currency, selectedBuildingName);
  };

  const handleOpenPdfReport = () => {
    setIsReportOpen(true);
  };

  const activePaymentModalSnapshot = useMemo(() => {
    if (!paymentModalTenantId) return null;
    return allSnapshots.find((s) => s.tenant.id === paymentModalTenantId) || null;
  }, [paymentModalTenantId, allSnapshots]);

  const activeHistoryModalSnapshot = useMemo(() => {
    if (!historyModalTenantId) return null;
    return allSnapshots.find((s) => s.tenant.id === historyModalTenantId) || null;
  }, [historyModalTenantId, allSnapshots]);

  const activeTenantHistoricalPayments = useMemo(() => {
    if (!historyModalTenantId) return [];
    return payments.filter((p) => p.tenantId === historyModalTenantId);
  }, [historyModalTenantId, payments]);

  // Edit objects
  const editingBuilding = useMemo(() => {
    if (!editBuildingId) return null;
    return buildings.find((b) => b.id === editBuildingId) || null;
  }, [editBuildingId, buildings]);

  const editingBuildingUnitCount = useMemo(() => {
    if (!editBuildingId) return 0;
    return tenants.filter((t) => t.buildingId === editBuildingId).length;
  }, [editBuildingId, tenants]);

  const editingTenant = useMemo(() => {
    if (!editTenantId) return null;
    return tenants.find((t) => t.id === editTenantId) || null;
  }, [editTenantId, tenants]);

  const editingPaymentTenantInfo = useMemo(() => {
    if (!editPaymentRecord) return { tenantName: '', unitNumber: '' };
    const t = tenants.find((item) => item.id === editPaymentRecord.tenantId);
    return {
      tenantName: t ? t.name : 'مستأجر',
      unitNumber: t ? t.unitNumber : '',
    };
  }, [editPaymentRecord, tenants]);

  // Font class
  const fontClass =
    font === 'cairo'
      ? 'font-cairo'
      : font === 'tajawal'
      ? 'font-tajawal'
      : font === 'almarai'
      ? 'font-almarai'
      : font === 'noto'
      ? 'font-noto'
      : font === 'alexandria'
      ? 'font-alexandria'
      : font === 'ibm'
      ? 'font-ibm'
      : font === 'amiri'
      ? 'font-amiri'
      : font === 'changa'
      ? 'font-changa'
      : font === 'jakarta'
      ? 'font-jakarta'
      : 'font-readex';

  const themeConfig = getThemeConfig(theme);
  const isDark = isDarkTheme(theme);

  return (
    <div
      data-theme={theme}
      className={`min-h-screen transition-colors duration-200 flex flex-col antialiased ${fontClass} ${themeConfig.bgMain} ${themeConfig.textColor}`}
    >
      {/* 0. Offline Alert Banner & Reconnection Toast */}
      <OfflineBanner
        isOnline={isOnline}
        wasOffline={wasOffline}
        onClearWasOffline={clearWasOffline}
        theme={theme}
      />

      {/* 1. Executive Top Bar with Export dropdown, + إضافة عمارة, + إضافة شقة */}
      <Header
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        currency={currency}
        onCurrencyChange={handleCurrencyChange}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        onThemeChange={handleThemeChange}
        font={font}
        onFontChange={handleFontChange}
        onOpenAddBuildingModal={() => setIsAddBuildingOpen(true)}
        onOpenAddModal={() => handleOpenAddTenant(undefined)}
        onOpenBulkEditModal={() => setIsBulkEditOpen(true)}
        onExportExcel={handleExportExcel}
        onExportWord={handleExportWord}
        onOpenPdfReport={handleOpenPdfReport}
        onExportJSON={exportDataAsJSON}
        onLoadDemoData={handleLoadDemo}
        onClearAll={requestClearAll}
        tenantsCount={tenants.length}
        buildingsCount={buildings.length}
        onOpenShareModal={() => setIsShareModalOpen(true)}
        pendingReceivedCount={pendingUpdatesCount}
        isOnline={isOnline}
      />

      {/* Action Notification */}
      {syncSuccessMsg && (
        <div className="bg-emerald-500 text-neutral-950 font-bold px-4 py-2.5 text-xs text-center flex items-center justify-center gap-2 shadow-md animate-in fade-in">
          <CheckCircle2 className="w-4 h-4" />
          <span>{syncSuccessMsg}</span>
          <button
            onClick={() => setSyncSuccessMsg(null)}
            className="mr-3 cursor-pointer p-0.5 hover:bg-black/10 rounded"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 2. Month & Year Carousel / Picker Navigation */}
      <MonthPicker
        activeMonthKey={activeMonthKey}
        onMonthChange={handleMonthChange}
        theme={theme}
      />


      {/* Main Workspace Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 lg:px-8 py-6 space-y-6">
        {/* Empty State when no buildings exist yet */}
        {buildings.length === 0 ? (
          <div
            className={`p-8 sm:p-14 text-center rounded-3xl border shadow-xl space-y-6 max-w-2xl mx-auto my-6 transition-colors ${
              isDark
                ? `${themeConfig.bgCard} ${themeConfig.borderCard} text-white`
                : 'bg-white border-neutral-200 text-neutral-900 shadow-sm'
            }`}
          >
            <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-500 mx-auto flex items-center justify-center shadow-md">
              <Building2 className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
                ابدأ بإضافة أول عمارة أو مجمع عقاري
              </h2>
              <p className="text-xs sm:text-sm text-neutral-400 max-w-md mx-auto leading-relaxed">
                النظام جاهز وفارغ تماماً. يمكنك البدء بتسجيل اسم وموقع العمارة، ثم إضافة الشقق والمحلات
                والمستأجرين وتعديل وحذف كل شيء بحرية كاملة مع الحفظ التلقائي الفوري وتصدير إكسل ووورد وPDF.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setIsAddBuildingOpen(true)}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-extrabold text-xs shadow-lg transition-all active:scale-95 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ إضافة أول عمارة الآن</span>
              </button>

              <button
                onClick={handleLoadDemo}
                className={`w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-3 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                  isDark
                    ? 'bg-neutral-800/80 hover:bg-neutral-700 text-neutral-200 border-neutral-700'
                    : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-800 border-neutral-300'
                }`}
              >
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>تحميل بيانات تجريبية للمعاينة</span>
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* 3. Financial Overview KPIs */}
            <FinancialOverview
              totalExpectedRent={financialTotals.totalExpectedRent}
              totalCollected={financialTotals.totalCollected}
              totalRemaining={financialTotals.totalRemaining}
              totalSecurityDeposits={financialTotals.totalSecurityDeposits}
              currency={currency}
              paidCount={financialTotals.paidCount}
              partialCount={financialTotals.partialCount}
              unpaidCount={financialTotals.unpaidCount}
              totalTenants={financialTotals.totalTenants}
              theme={theme}
            />

            {/* 3.5. Collection Analytics Chart (Recharts) */}
            <CollectionAnalyticsChart
              totalCollected={financialTotals.totalCollected}
              totalRemaining={financialTotals.totalRemaining}
              totalExpectedRent={financialTotals.totalExpectedRent}
              currency={currency}
              activeMonthKey={activeMonthKey}
              theme={theme}
              buildings={buildings}
              tenants={tenants}
              snapshots={allSnapshots}
            />

            {/* 4. Search and Filter Bar */}
            <FilterBar
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              statusFilter={statusFilter}
              onStatusFilterChange={setStatusFilter}
              unitTypeFilter={unitTypeFilter}
              onUnitTypeFilterChange={setUnitTypeFilter}
              selectedBuildingId={selectedBuildingId}
              onBuildingSelect={setSelectedBuildingId}
              buildings={buildings}
              totalFilteredCount={filteredSnapshots.length}
              theme={theme}
            />

            {/* 5. Main Content: Buildings Section (Boxes) vs Excel-style Table */}
            {visibleBuildings.length === 0 ? (
              <div
                className={`p-12 text-center rounded-2xl border space-y-3 ${
                  isDark
                    ? `${themeConfig.bgCard} ${themeConfig.borderCard} text-white`
                    : 'bg-white border-neutral-200 text-neutral-900 shadow-xs'
                }`}
              >
                <SearchX className="w-12 h-12 mx-auto text-neutral-400" />
                <h3 className="text-base font-bold">لا توجد عقارات مطابقة للفلتر المحدد</h3>
                <p className="text-xs text-neutral-400 max-w-md mx-auto">
                  جرب تغيير خيار العمارة المحددة أو مسح كلمات البحث وفلاتر السداد.
                </p>
                <button
                  onClick={() => {
                    setSelectedBuildingId('all');
                    setSearchQuery('');
                    setStatusFilter('all');
                    setUnitTypeFilter('all');
                  }}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs shadow-sm transition-all cursor-pointer inline-block"
                >
                  عرض كافة العمارات والوحدات
                </button>
              </div>
            ) : viewMode === 'cards' ? (
              /* Buildings Sections with nested apartments (Boxes) */
              <div className="space-y-8">
                {visibleBuildings.map((building) => {
                  const buildingSnapshots = filteredSnapshots.filter(
                    (s) => s.tenant.buildingId === building.id
                  );
                  return (
                    <BuildingSection
                      key={building.id}
                      building={building}
                      snapshots={buildingSnapshots}
                      currency={currency}
                      onRecordPayment={handleRecordPaymentClick}
                      onViewHistory={(tId) => setHistoryModalTenantId(tId)}
                      onEditTenant={(tId) => setEditTenantId(tId)}
                      onDeleteTenant={requestDeleteTenant}
                      onAddUnitToBuilding={handleOpenAddTenant}
                      onEditBuilding={(bId) => setEditBuildingId(bId)}
                      onDeleteBuilding={requestDeleteBuilding}
                      theme={theme}
                    />
                  );
                })}
              </div>
            ) : (
              /* Excel-Style Smart Table Ledger */
              <ExecutiveTable
                snapshots={filteredSnapshots}
                currency={currency}
                onRecordPayment={handleRecordPaymentClick}
                onViewHistory={(tId) => setHistoryModalTenantId(tId)}
                onEditTenant={(tId) => setEditTenantId(tId)}
                onDeleteTenant={requestDeleteTenant}
                onOpenBulkEditModal={() => setIsBulkEditOpen(true)}
                onExportExcel={handleExportExcel}
                onExportWord={handleExportWord}
                onOpenPdfReport={handleOpenPdfReport}
                theme={theme}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer
        className={`border-t py-6 px-4 text-center text-xs transition-colors ${
          isDark
            ? `${themeConfig.borderCard} ${themeConfig.bgCard} text-neutral-400`
            : 'border-neutral-200 bg-white text-neutral-500 shadow-xs'
        }`}
      >
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-amber-500 text-sm">تحصيل</span>
            <span className="font-semibold text-neutral-400">| نظام إدارة وتحصيل الإيجارات والعقارات</span>
          </div>

          <div className="flex items-center gap-4">
            {buildings.length > 0 && (
              <button
                onClick={requestClearAll}
                className="flex items-center gap-1 text-rose-500 hover:text-rose-400 text-xs font-semibold cursor-pointer"
                title="تفريغ كافة البيانات"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>تفريغ السجل بالكامل</span>
              </button>
            )}
            <div>جميع الحقوق محفوظة © {new Date().getFullYear()}</div>
          </div>
        </div>
      </footer>

      {/* Add New Building Modal */}
      <AddBuildingModal
        isOpen={isAddBuildingOpen}
        onClose={() => setIsAddBuildingOpen(false)}
        onSaveBuilding={handleSaveNewBuilding}
        theme={theme}
      />

      {/* Add New Tenant / Apartment Modal */}
      <AddTenantModal
        isOpen={isAddTenantOpen}
        onClose={() => {
          setIsAddTenantOpen(false);
          setTargetBuildingIdForTenant(undefined);
        }}
        buildings={buildings}
        currency={currency}
        initialBuildingId={targetBuildingIdForTenant}
        onSaveTenant={handleSaveNewTenant}
        onOpenAddBuilding={() => setIsAddBuildingOpen(true)}
        theme={theme}
      />

      {/* Edit Building Modal */}
      <EditBuildingModal
        isOpen={!!editBuildingId}
        onClose={() => setEditBuildingId(null)}
        building={editingBuilding}
        onUpdateBuilding={handleUpdateBuilding}
        onDeleteBuilding={requestDeleteBuilding}
        unitCount={editingBuildingUnitCount}
        theme={theme}
      />

      {/* Edit Tenant / Apartment Modal */}
      <EditTenantModal
        isOpen={!!editTenantId}
        onClose={() => setEditTenantId(null)}
        tenant={editingTenant}
        buildings={buildings}
        currency={currency}
        onUpdateTenant={handleUpdateTenant}
        onDeleteTenant={requestDeleteTenant}
        theme={theme}
      />

      {/* Printable Report & PDF Modal */}
      <ReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        snapshots={filteredSnapshots}
        monthKey={activeMonthKey}
        currency={currency}
        selectedBuildingName={selectedBuildingName}
        theme={theme}
      />

      {/* Payment Recording Modal */}
      <PaymentModal
        isOpen={!!paymentModalTenantId}
        onClose={() => setPaymentModalTenantId(null)}
        snapshot={activePaymentModalSnapshot}
        currency={currency}
        onSavePayment={handleSavePayment}
        onOpenReceipt={handleOpenReceiptFromPayment}
        theme={theme}
      />

      {/* Tenant Historical Payments Audit Trail */}
      <TenantHistoryModal
        isOpen={!!historyModalTenantId}
        onClose={() => setHistoryModalTenantId(null)}
        snapshot={activeHistoryModalSnapshot}
        allTenantPayments={activeTenantHistoricalPayments}
        currency={currency}
        onViewReceipt={handleViewReceiptFromHistory}
        onEditPayment={(payment) => setEditPaymentRecord(payment)}
        onDeletePayment={requestDeletePayment}
        theme={theme}
      />

      {/* Edit Payment Record Modal (Can be opened from TenantHistoryModal) */}
      <EditPaymentModal
        isOpen={!!editPaymentRecord}
        onClose={() => setEditPaymentRecord(null)}
        payment={editPaymentRecord}
        tenantName={editingPaymentTenantInfo.tenantName}
        unitNumber={editingPaymentTenantInfo.unitNumber}
        currency={currency}
        onUpdatePayment={handleUpdatePayment}
        theme={theme}
      />

      {/* Payment Receipt Voucher Modal (Can be opened from PaymentModal or TenantHistoryModal) */}
      <ReceiptModal
        isOpen={isReceiptOpen}
        onClose={() => setIsReceiptOpen(false)}
        payment={receiptPayment}
        snapshot={receiptSnapshot}
        currency={currency}
        theme={theme}
      />

      {/* Bulk Edit Units / Types Modal */}
      <BulkEditUnitsModal
        isOpen={isBulkEditOpen}
        onClose={() => setIsBulkEditOpen(false)}
        tenants={tenants}
        buildings={buildings}
        onBulkUpdateUnitType={handleBulkUpdateUnitType}
        theme={theme}
      />

      {/* Custom Confirmation Dialog (Non-blocking in iframe, always on topmost layer) */}
      <ConfirmModal
        isOpen={confirmDialog.isOpen}
        onClose={() => setConfirmDialog((prev) => ({ ...prev, isOpen: false }))}
        onConfirm={confirmDialog.onConfirm}
        title={confirmDialog.title}
        message={confirmDialog.message}
        confirmText={confirmDialog.confirmText}
        requireInputText={confirmDialog.requireInputText}
        theme={theme}
      />

      {/* Multi-Account & Portfolio Sharing Modal */}
      <SharePortfolioModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        theme={theme}
        buildings={buildings}
        tenants={tenants}
        payments={payments}
        onApplyUpdate={handleApplyIncomingUpdate}
      />
    </div>
  );
}
