import fs from 'fs';
import sharp from 'sharp';

async function generateIcons() {
  const svgBuffer = fs.readFileSync('./public/icon.svg');

  // Apple touch icon (180x180)
  await sharp(svgBuffer)
    .resize(180, 180)
    .png()
    .toFile('./public/apple-touch-icon.png');

  // PWA 192x192
  await sharp(svgBuffer)
    .resize(192, 192)
    .png()
    .toFile('./public/pwa-192x192.png');

  // PWA 512x512
  await sharp(svgBuffer)
    .resize(512, 512)
    .png()
    .toFile('./public/pwa-512x512.png');

  // PWA maskable 512x512
  await sharp(svgBuffer)
    .resize(512, 512)
    .png()
    .toFile('./public/pwa-maskable-512x512.png');

  // Favicon (32x32)
  await sharp(svgBuffer)
    .resize(32, 32)
    .png()
    .toFile('./public/favicon.png');

  console.log('Successfully generated all PWA & iOS PNG icons!');
}

generateIcons().catch(console.error);
